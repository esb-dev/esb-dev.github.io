package usg.lernkarten.data.dao.sqlite;

import android.content.Context;
import android.test.AndroidTestCase;
import android.test.RenamingDelegatingContext;

import java.util.ArrayList;
import java.util.List;

import usg.lernkarten.data.Answer;
import usg.lernkarten.data.Deck;
import usg.lernkarten.data.Flashcard;
import usg.lernkarten.data.Picture;

/**
 * Created by christian on 23.09.15.
 */
public class AnswerSQLiteTest extends AndroidTestCase{

    private AnswerSQLiteDAO answerDao;
    private PictureSQLiteDAO picDao;
    private DeckSQLiteDAO deckDao;
    private FlashcardSQLiteDAO fDao;
    private Flashcard f;

    @Override
    public void setUp() throws Exception {
        super.setUp();
        Context ctx = new RenamingDelegatingContext(getContext(), "test_");
        List<Long> ids = new ArrayList<>();
        answerDao = new AnswerSQLiteDAO(ctx);
        picDao = new PictureSQLiteDAO(ctx);
        deckDao = new DeckSQLiteDAO(ctx);
        fDao = new FlashcardSQLiteDAO(ctx);
        Picture p = new Picture();
        picDao.persist(p);
        Deck d = new Deck();
        d.setPicture(p);
        deckDao.persist(d);
        f = new Flashcard();
        f.setDeck(d);
        fDao.persist(f);
        Answer a = new Answer();
        a.setAnswer("TestAnswer");
        a.setAnswerCorrect(false);
        a.setFlashcard(f);
        ids.add(answerDao.persist(a));
    }

    @Override
    public void tearDown() throws Exception {
        for(Deck d : deckDao.findAll()){
            deckDao.delete(d);
        }
        for(Flashcard f : fDao.findAll()){
            fDao.delete(f);
        }
        for(Deck d : deckDao.findAll()){
            deckDao.delete(d);
        }
        super.tearDown();
    }

    public void testPersist() throws Exception {
        Picture p = new Picture();
        picDao.persist(p);
        Deck d = new Deck();
        d.setPicture(p);
        deckDao.persist(d);
        Flashcard f = new Flashcard();
        f.setDeck(d);
        fDao.persist(f);
        Answer a = new Answer();
        a.setAnswer("TestAnswer");
        a.setAnswerCorrect(false);
        a.setFlashcard(f);
        Long id = answerDao.persist(a);
        assertNotNull(id);
        Answer a2 = answerDao.findById(id.intValue());
        assertEquals(a.getAnswer(),a2.getAnswer());
        assertEquals(a.getAnswerCorrect(),a2.getAnswerCorrect());
        assertEquals(a.getId(),a2.getId());
    }

    private void testFindByFlashcard() throws Exception {
        List<Answer> answers = answerDao.findAllByFlashcard(f);
        assertEquals(answers.size(),1);
    }

    private void test() throws Exception {
        assertEquals(answerDao.findAll().size(),1);
    }
    private void testFindById() throws Exception {
        Picture p = new Picture();
        picDao.persist(p);
        Deck d = new Deck();
        d.setPicture(p);
        deckDao.persist(d);
        Flashcard f = new Flashcard();
        f.setDeck(d);
        fDao.persist(f);
        Answer a = new Answer();
        a.setAnswer("TestAnswer");
        a.setAnswerCorrect(false);
        a.setFlashcard(f);
        Long id = answerDao.persist(a);
        Answer a1 = answerDao.findById(id.intValue());
        assertEquals(a.getAnswer(),a1.getAnswer());
        assertEquals(a.getAnswerCorrect(),a1.getAnswerCorrect());
        assertEquals(a.getId(),a1.getId());
    }

    private void testDelete() throws Exception {
        Picture p = new Picture();
        picDao.persist(p);
        Deck d = new Deck();
        d.setPicture(p);
        deckDao.persist(d);
        Flashcard f = new Flashcard();
        f.setDeck(d);
        fDao.persist(f);
        Answer a = new Answer();
        a.setAnswer("TestAnswer");
        a.setAnswerCorrect(false);
        a.setFlashcard(f);
        Long id = answerDao.persist(a);
        assertNotNull(answerDao.findById(id.intValue()));
        answerDao.delete(a);
        assertNull(answerDao.findById(id.intValue()));
    }

    private void testUpdate() throws Exception {
        Picture p = new Picture();
        picDao.persist(p);
        Deck d = new Deck();
        d.setPicture(p);
        deckDao.persist(d);
        Flashcard f = new Flashcard();
        f.setDeck(d);
        fDao.persist(f);
        Answer a = new Answer();
        a.setAnswer("TestAnswer");
        a.setAnswerCorrect(false);
        a.setFlashcard(f);
        Long id = answerDao.persist(a);
        assertNotNull(answerDao.findById(id.intValue()));
        a.setAnswerCorrect(true);
        a.setAnswer("TestAnswer2");
        answerDao.update(a);
        Answer a2 = answerDao.findById(id.intValue());
        assertEquals(a2.getAnswer(), "TestAnswer2");
        assertTrue(a2.getAnswerCorrect());
    }

    private void testFindAll(){
        assertEquals(answerDao.findAll().size(),1);
    }
}
