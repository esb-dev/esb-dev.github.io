package usg.lernkarten.data.dao.sqlite;

import android.content.Context;
import android.test.AndroidTestCase;
import android.test.RenamingDelegatingContext;

import java.util.Date;
import java.util.List;

import usg.lernkarten.data.Deck;
import usg.lernkarten.data.Flashcard;
import usg.lernkarten.data.Picture;

/**
 * Created by christian on 24.09.15.
 */
public class FlashcardSQLiteTest extends AndroidTestCase {

    private FlashcardSQLiteDAO flashcardDao;
    private DeckSQLiteDAO deckDao;
    private PictureSQLiteDAO picDAO;

    @Override
    public void setUp() throws Exception {
        super.setUp();
        Context ctx = new RenamingDelegatingContext(getContext(), "test_");
        flashcardDao = new FlashcardSQLiteDAO(ctx);
        deckDao = new DeckSQLiteDAO(ctx);
        picDAO  = new PictureSQLiteDAO(ctx);
    }

    @Override
    public void tearDown() throws Exception {
        for(Deck d : deckDao.findAll()){
            deckDao.delete(d);
        }
        for(Flashcard f : flashcardDao.findAll()){
            flashcardDao.delete(f);
        }
        for(Deck d : deckDao.findAll()){
            deckDao.delete(d);
        }
        super.tearDown();
    }

    public void testPersist() throws Exception {
        Date d = new Date();
        Long date = d.getTime();
        Picture pic = new Picture();
        pic.setName("Test");
        pic.setMimeType("JPG");
        pic.setSize("200");
        assertNotNull(picDAO.persist(pic));
        Deck deck = new Deck();
        deck.setName("TestDeck");
        deck.setPicture(pic);
        assertNotNull(deckDao.persist(deck));
        Flashcard f = new Flashcard();
        f.setLastCorrect(date);
        f.setLastPlayed(date);
        f.setNumberOfCorrect(3);
        f.setNumberOfWrong(2);
        f.setQuestion("TestQuestion");
        f.setDeck(deck);
        f.addPicture(pic);
        assertNotNull(flashcardDao.persist(f));
    }

    public void testUpdate() throws Exception {
        Date d = new Date();
        Long date = d.getTime();
        Picture pic = new Picture();
        pic.setName("Test");
        pic.setMimeType("JPG");
        pic.setSize("200");
        assertNotNull(picDAO.persist(pic));
        Deck deck = new Deck();
        deck.setName("TestDeck");
        deck.setPicture(pic);
        assertNotNull(deckDao.persist(deck));
        Flashcard f = new Flashcard();
        f.setLastCorrect(date);
        f.setLastPlayed(date);
        f.setNumberOfCorrect(3);
        f.setNumberOfWrong(2);
        f.setQuestion("TestQuestion");
        f.setDeck(deck);
        f.addPicture(pic);
        Long fId = flashcardDao.persist(f);
        assertNotNull(fId);
        f.setLastCorrect(0L);
        f.setLastPlayed(0L);
        f.setQuestion("TestQuestion2");
        f.setNumberOfCorrect(5);
        f.setNumberOfWrong(6);
        flashcardDao.update(f);
        Flashcard f2 = flashcardDao.findById(fId.intValue());
        assertEquals(f2.getLastCorrect(),Long.valueOf(0));
        assertEquals(f2.getLastPlayed(),Long.valueOf(0));
        assertEquals((int)f2.getNumberOfCorrect(),5);
        assertEquals((int)f2.getNumberOfWrong(),6);
        assertEquals(f2.getQuestion(),"TestQuestion2");
    }

    private void testFindAll() throws Exception {
        Date d = new Date();
        Long date = d.getTime();
        Picture pic = new Picture();
        pic.setName("Test");
        pic.setMimeType("JPG");
        pic.setSize("200");
        assertNotNull(picDAO.persist(pic));
        Deck deck = new Deck();
        deck.setName("TestDeck");
        deck.setPicture(pic);
        assertNotNull(deckDao.persist(deck));
        Flashcard f = new Flashcard();
        f.setLastCorrect(date);
        f.setLastPlayed(date);
        f.setNumberOfCorrect(3);
        f.setNumberOfWrong(2);
        f.setQuestion("TestQuestion");
        f.setDeck(deck);
        f.addPicture(pic);
        assertNotNull(flashcardDao.persist(f));
        assertEquals(flashcardDao.findAll().size(),1);
    }

    private void testFindById() throws Exception {
        Date d = new Date();
        Long date = d.getTime();
        Picture pic = new Picture();
        pic.setName("Test");
        pic.setMimeType("JPG");
        pic.setSize("200");
        assertNotNull(picDAO.persist(pic));
        Deck deck = new Deck();
        deck.setName("TestDeck");
        deck.setPicture(pic);
        assertNotNull(deckDao.persist(deck));
        Flashcard f = new Flashcard();
        f.setLastCorrect(date);
        f.setLastPlayed(date);
        f.setNumberOfCorrect(3);
        f.setNumberOfWrong(2);
        f.setQuestion("TestQuestion");
        f.setDeck(deck);
        f.addPicture(pic);
        Long fId = flashcardDao.persist(f);
        assertNotNull(fId);
        Flashcard f2 = flashcardDao.findById(fId.intValue());
        assertNotNull(f2);
        assertEquals(f.getNumberOfCorrect(), f2.getNumberOfCorrect());
        assertEquals(f.getQuestion(), f2.getQuestion());
        assertEquals(f.getLastPlayed(), f2.getLastPlayed());
        assertEquals(f.getLastCorrect(), f2.getLastCorrect());
        assertEquals(f.getId(),f2.getId());
    }

    private void testFindByDeck() throws Exception {
        Date d = new Date();
        Long date = d.getTime();
        Picture pic = new Picture();
        pic.setName("Test");
        pic.setMimeType("JPG");
        pic.setSize("200");
        assertNotNull(picDAO.persist(pic));
        Deck deck = new Deck();
        deck.setName("TestDeck");
        deck.setPicture(pic);
        assertNotNull(deckDao.persist(deck));
        Flashcard f = new Flashcard();
        f.setLastCorrect(date);
        f.setLastPlayed(date);
        f.setNumberOfCorrect(3);
        f.setNumberOfWrong(2);
        f.setQuestion("TestQuestion");
        f.setDeck(deck);
        f.addPicture(pic);
        Long fId = flashcardDao.persist(f);
        assertNotNull(fId);
        List<Flashcard> flashcards = flashcardDao.findByDeck(deck);
        assertEquals(flashcards.size(),1);
    }

    private void testFindByDeckWithAnswer() throws Exception {
        Date d = new Date();
        Long date = d.getTime();
        Picture pic = new Picture();
        pic.setName("Test");
        pic.setMimeType("JPG");
        pic.setSize("200");
        assertNotNull(picDAO.persist(pic));
        Deck deck = new Deck();
        deck.setName("TestDeck");
        deck.setPicture(pic);
        assertNotNull(deckDao.persist(deck));
        Flashcard f = new Flashcard();
        f.setLastCorrect(date);
        f.setLastPlayed(date);
        f.setNumberOfCorrect(3);
        f.setNumberOfWrong(2);
        f.setQuestion("TestQuestion");
        f.setDeck(deck);
        f.addPicture(pic);
        Long fId = flashcardDao.persist(f);
        assertNotNull(fId);
        List<Flashcard> flashcards = flashcardDao.findByDeckWithAnswer(deck);
        assertEquals(flashcards.size(),1);
    }

    private void testDelete() throws Exception {
        Date d = new Date();
        Long date = d.getTime();
        Picture pic = new Picture();
        pic.setName("Test");
        pic.setMimeType("JPG");
        pic.setSize("200");
        assertNotNull(picDAO.persist(pic));
        Deck deck = new Deck();
        deck.setName("TestDeck");
        deck.setPicture(pic);
        assertNotNull(deckDao.persist(deck));
        Flashcard f = new Flashcard();
        f.setLastCorrect(date);
        f.setLastPlayed(date);
        f.setNumberOfCorrect(3);
        f.setNumberOfWrong(2);
        f.setQuestion("TestQuestion");
        f.setDeck(deck);
        f.addPicture(pic);
        Long fId = flashcardDao.persist(f);
        assertNotNull(fId);
        assertNotNull(flashcardDao.findById(fId.intValue()));
        flashcardDao.delete(f);
        assertNull(flashcardDao.findById(fId.intValue()));
    }
}
