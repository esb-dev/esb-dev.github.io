package usg.lernkarten.data.dao.sqlite;

import android.content.Context;
import android.test.AndroidTestCase;
import android.test.RenamingDelegatingContext;

import java.util.ArrayList;
import java.util.List;

import usg.lernkarten.data.Picture;

/**
 * Created by christian on 23.09.15.
 */
public class PictureSQLiteTest extends AndroidTestCase {

   private PictureSQLiteDAO picDAO;
    private List<Long> ids;
    @Override
    public void setUp() throws Exception {
        super.setUp();
        Context ctx = new RenamingDelegatingContext(getContext(), "test_");
        picDAO  = new PictureSQLiteDAO(ctx);
        ids = new ArrayList<>();
        Picture pic = new Picture();
        pic.setName("Test");
        pic.setMimeType("JPG");
        pic.setSize("100");
        ids.add(picDAO.persist(pic));
        Picture pic2 = new Picture();
        pic2.setName("Test2");
        pic2.setMimeType("JPG");
        pic2.setSize("200");
        ids.add(picDAO.persist(pic));
        Picture pic3 = new Picture();
        pic3.setName("Test3");
        pic3.setMimeType("JPG");
        pic3.setSize("300");
        ids.add(picDAO.persist(pic));
    }

    @Override
    public void tearDown() throws Exception {
        super.tearDown();
        List<Picture> pics = picDAO.findAll();
        for(Picture p : pics){
            picDAO.delete(p);
        }
    }

    public void testPersist() throws Exception {
        Picture pic = new Picture();
        pic.setName("Test");
        pic.setMimeType("JPG");
        pic.setSize("200");
        assertNotNull(picDAO.persist(pic));

    }
    public void testFindAll() throws Exception {
        List<Picture> pics = picDAO.findAll();
        assertEquals(pics.size(), 3);
    }

    public void TestFindById() throws Exception {
        for(Long id : ids){
            assertNotNull(picDAO.findById(id.intValue()));
        }
    }

    public void TestDelete() throws Exception {
        Picture pic = new Picture();
        pic.setName("TestDelete");
        pic.setMimeType("JPG");
        pic.setSize("200");
        Long id = picDAO.persist(pic);
        assertNotNull(picDAO.findById(id.intValue()));
        picDAO.delete(pic);
        assertNull(picDAO.findById(id.intValue()));
    }

    public void TestUpdate() throws Exception {
        Picture pic = new Picture();
        pic.setName("TestUpdate");
        pic.setMimeType("JPG");
        pic.setSize("200");
        Long id = picDAO.persist(pic);
        assertNotNull(picDAO.findById(id.intValue()));
        pic.setName("TestUpdate2");
        pic.setSize("300");
        pic.setMimeType("GIF");
        picDAO.update(pic);
        Picture pic2 = picDAO.findById(id.intValue());
        assertEquals(pic2.getName(),"TestUpdate2");
        assertEquals(pic2.getSize(),"300");
        assertEquals(pic2.getMimeType(),"GIF");
    }
}
