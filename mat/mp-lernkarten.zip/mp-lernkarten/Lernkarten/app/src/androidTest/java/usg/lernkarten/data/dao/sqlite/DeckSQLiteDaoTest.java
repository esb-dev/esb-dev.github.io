package usg.lernkarten.data.dao.sqlite;

import android.content.Context;
import android.test.AndroidTestCase;
import android.test.RenamingDelegatingContext;

import java.util.Date;

import usg.lernkarten.data.Deck;
import usg.lernkarten.data.Flashcard;
import usg.lernkarten.data.Picture;

/**
 * Created by christian on 24.09.15.
 */
public class DeckSQLiteDaoTest extends AndroidTestCase {

    private DeckSQLiteDAO deckDao;
    private PictureSQLiteDAO picDao;
    private FlashcardSQLiteDAO flashcardDao;

    @Override
    public void setUp() throws Exception {
        super.setUp();
        Context ctx = new RenamingDelegatingContext(getContext(), "test_");
        deckDao = new DeckSQLiteDAO(ctx);
        picDao = new PictureSQLiteDAO(ctx);
        flashcardDao = new FlashcardSQLiteDAO(ctx);
    }

    @Override
    public void tearDown() throws Exception {
        for (Flashcard f : flashcardDao.findAll()){
            flashcardDao.delete(f);
        }
        for(Deck d : deckDao.findAll()){
            deckDao.delete(d);
        }
        for(Picture p : picDao.findAll()){
            picDao.delete(p);
        }
        super.tearDown();
    }

    public void testPersist() throws Exception {
        Picture p = new Picture();
        picDao.persist(p);
        Deck d = new Deck();
        d.setName("TestDeck");
        d.setDescription("TestDeck1");
        d.setPicture(p);
        assertNotNull(deckDao.persist(d));
    }

    public void testUpdate() throws Exception {
        Picture p = new Picture();
        picDao.persist(p);
        Deck d = new Deck();
        d.setName("TestDeck");
        d.setDescription("TestDeck1");
        d.setPicture(p);
        Long dId = deckDao.persist(d);
        assertNotNull(dId);
        d.setName("TestDeck2");
        d.setDescription("TestDeck3");
        deckDao.update(d);
        Deck d2 = deckDao.findById(dId.intValue());
        assertEquals(d2.getName(), "TestDeck2");
        assertEquals(d2.getDescription(), "TestDeck3");
        assertEquals(d2.getId().longValue(), (long) dId);
    }

    public void testDelete() throws Exception {
        Picture p = new Picture();
        picDao.persist(p);
        Deck d = new Deck();
        d.setName("TestDeck");
        d.setDescription("TestDeck1");
        d.setPicture(p);
        Long dId = deckDao.persist(d);
        assertNotNull(dId);
        assertNotNull(deckDao.findById(dId.intValue()));
        deckDao.delete(d);
        assertNull(deckDao.findById(dId.intValue()));
    }

    public void testFindAll() throws Exception {
        Picture p = new Picture();
        picDao.persist(p);
        Deck d = new Deck();
        d.setName("TestDeck");
        d.setDescription("TestDeck1");
        d.setPicture(p);
        Long dId = deckDao.persist(d);
        assertNotNull(dId);
        assertEquals(deckDao.findAll().size(), 1);
    }

    public void testFindById() throws Exception {
        Picture p = new Picture();
        picDao.persist(p);
        Deck d = new Deck();
        d.setName("TestDeck");
        d.setDescription("TestDeck1");
        d.setPicture(p);
        Long dId = deckDao.persist(d);
        assertNotNull(dId);
        assertNotNull(deckDao.findById(dId.intValue()));
    }

    public void testFindByName() throws Exception {
        Picture p = new Picture();
        picDao.persist(p);
        Deck d = new Deck();
        d.setName("TestDeck");
        d.setDescription("TestDeck1");
        d.setPicture(p);
        Long dId = deckDao.persist(d);
        assertNotNull(dId);
        assertNotNull(deckDao.findByName("TestDeck"));
    }

    public void testgetLastPlayed() throws Exception {
        Date da = new Date();
        Long date = da.getTime();
        Picture p = new Picture();
        picDao.persist(p);
        Deck d = new Deck();
        d.setName("TestDeck");
        d.setDescription("TestDeck1");
        d.setPicture(p);
        Long dId = deckDao.persist(d);
        assertNotNull(dId);
        Flashcard f = new Flashcard();
        f.setLastCorrect(date);
        f.setLastPlayed(date);
        f.setNumberOfCorrect(3);
        f.setNumberOfWrong(2);
        f.setQuestion("TestQuestion");
        f.setDeck(d);
        f.addPicture(p);
        assertNotNull(flashcardDao.persist(f));
        assertEquals(deckDao.getLastPlayed(d),date);
    }
}
