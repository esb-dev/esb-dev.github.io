/**
 * Musterprojekt Softwaretechnik
 * Copyright (c) 2015 by Institut für SoftwareArchitektur, TH Mittelhessen.
 * Lizenz Creative Commons CC BY-NC-SA 3.0
 *
 */
package usg.lernkarten.flashcard;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.SearchView;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.GridView;
import android.widget.ListView;
import android.widget.TextView;

import com.gc.materialdesign.views.ButtonFloat;

import usg.lernkarten.R;
import usg.lernkarten.data.Deck;
import usg.lernkarten.data.dao.AppFactory;
import usg.lernkarten.data.dao.DeckDAO;
import usg.lernkarten.data.dao.FlashcardDAO;

/**
 *  This class represents the fragment of all flashcards for a certain deck.
 */
public class FlashcardListFragment extends Fragment implements SearchView.OnQueryTextListener {

    private View rootView;

    private ListView mListView;

    private GridView mGridView;

    private Integer deckId;

    private Deck deck;

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        if(getArguments() != null) {
            deckId = getArguments().getInt("deck");
        }

        DeckDAO deckDAO = AppFactory.get(this.getActivity()).getDeckDAO();
        deck = deckDAO.findById(deckId);
        FlashcardDAO flashcardDAO = AppFactory.get(this.getActivity().getApplicationContext()).getFlashcardDAO();

        TextView mAddFlashcardHint = (TextView) rootView.findViewById(R.id.button_add_flashcard_hint);

        FlashcardListAdapter mAdapter;
        if(mGridView == null) {
            mAdapter = new FlashcardListAdapter(this.getActivity(), flashcardDAO.findByDeck(deck), mListView);
            mListView.setAdapter(mAdapter);
            mListView.setTextFilterEnabled(true);
        } else {
            mAdapter = new FlashcardListAdapter(this.getActivity(), flashcardDAO.findByDeck(deck), mGridView);
            mGridView.setAdapter(mAdapter);
        }

        if (mAdapter.getCount() > 0) {
            mAddFlashcardHint.setVisibility(View.GONE);
        }

        ButtonFloat buttonAdd = (ButtonFloat) rootView.findViewById(R.id.button_add_flashcard);
        buttonAdd.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {

                //New card intent
                Intent intent = new Intent(v.getContext(), EditFlashcardActivity.class);
                intent.putExtra("deck", deck.getId());
                intent.putExtra("flashcard", -1);

                startActivity(intent);
            }
        });
    }

    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        rootView = inflater.inflate(R.layout.flashcard_list_fragment, container, false);
        mListView = (ListView) rootView.findViewById(R.id.show_cards_listview);
        mGridView = (GridView) rootView.findViewById(R.id.show_cards_gridview);

        return rootView;
    }

    @Override
    public boolean onQueryTextSubmit(String query) {
        return false;
    }

    @Override
    public boolean onQueryTextChange(String newText) {
        if (TextUtils.isEmpty(newText)) {
            mListView.clearTextFilter();
        } else {
            mListView.setFilterText(newText);
        }
        return true;
    }
}
