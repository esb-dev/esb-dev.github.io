/**
 * Musterprojekt Softwaretechnik
 * Copyright (c) 2015 by Institut für SoftwareArchitektur, TH Mittelhessen.
 * Lizenz Creative Commons CC BY-NC-SA 3.0
 *
 */
package usg.lernkarten.data.db;

import android.content.ContentValues;

import usg.lernkarten.data.Answer;

/**
 * Class that contains constants and helper-methods for the answer table.
 */
public final class AnswerDB {

    public final static String TABLE_NAME = "answer";
    public final static String ID = "_id";
    public final static String ANSWER_ANSWER = "answer";
    public final static String ANSWER_CORRECT = "answer_correct";
    public final static String ANSWER_FLASHCARD_ID = "flashcard_id";

    /**
     * Not intended for instantiation.
     */
    private AnswerDB() {
    }

    public static ContentValues createContentValue(Answer answer) {
        ContentValues cv = new ContentValues();

        cv.put(ANSWER_ANSWER, answer.getAnswer());
        cv.put(ANSWER_CORRECT, answer.getAnswerCorrect() ? 1 : 0);
        cv.put(ANSWER_FLASHCARD_ID, answer.getFlashcard().getId());

        return cv;
    }

}