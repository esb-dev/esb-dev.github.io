package usg.lernkarten.update;


import android.app.Service;
import android.content.Intent;
import android.os.Binder;
import android.os.IBinder;
import android.support.annotation.Nullable;

import usg.lernkarten.R;

public class UpdateService extends Service {


    /**
     * Class for clients to access.  Because we know this service always
     * runs in the same process as its clients, we don't need to deal with
     * IPC.
     */
    public class LocalBinder extends Binder {
        UpdateService getService() {
            return UpdateService.this;
        }
    }

    // This is the object that receives interactions from clients.
    private final IBinder mBinder = new LocalBinder();

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return mBinder;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {

        final UpdateTask updateTask = new UpdateTask(getApplicationContext(), null);
        updateTask.execute(getString(R.string.url_import_url));

        return START_NOT_STICKY;
    }
}
