/**
 * Musterprojekt Softwaretechnik
 * Copyright (c) 2015 by Institut für SoftwareArchitektur, TH Mittelhessen.
 * Lizenz Creative Commons CC BY-NC-SA 3.0
 */
package usg.lernkarten.flashcard.answer;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.view.ViewPager;
import android.support.v7.app.ActionBarActivity;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;

import java.util.List;

import usg.lernkarten.R;
import usg.lernkarten.data.Answer;
import usg.lernkarten.data.Deck;
import usg.lernkarten.data.Flashcard;
import usg.lernkarten.data.dao.AppFactory;
import usg.lernkarten.data.dao.DeckDAO;
import usg.lernkarten.data.dao.FlashcardDAO;
import usg.lernkarten.flashcard.EditFlashcardActivity;
import usg.lernkarten.flashcard.answer.AnswerPagerAdapter;

/**
 *  This class represents an activity to edit answers for a flashcard.
 */
public class EditAnswerActivity extends AppCompatActivity {

    private AnswerPagerAdapter mAnswerPagerAdapter;
    private ViewPager mViewPager;

    private Flashcard flashcard;
    private Deck deck;

    private List<Answer> answerList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.edit_answer_activity);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar_main);
        toolbar.setNavigationIcon(R.drawable.ic_clear_white_24dp);

        setSupportActionBar(toolbar);
        getSupportActionBar().setHomeAsUpIndicator(R.drawable.ic_clear_white_24dp);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowTitleEnabled(false);

        DeckDAO ddao = AppFactory.get(this).getDeckDAO();
        FlashcardDAO fdao = AppFactory.get(this).getFlashcardDAO();

        Intent intent = getIntent();

        Integer flashcardId = intent.getIntExtra("flashcard", -1);
        flashcard = fdao.findById(flashcardId);

        Integer deckId = intent.getIntExtra("deck", -1);
        deck = ddao.findById(deckId);

        answerList = AppFactory.get(this).getAnswerDAO().findAllByFlashcard(flashcard);
        if (answerList.isEmpty()) {
            Answer a = new Answer();
            a.setFlashcard(flashcard);
            answerList.add(a);
        }

        mViewPager = (ViewPager) findViewById(R.id.pager);
        mAnswerPagerAdapter = new AnswerPagerAdapter(getSupportFragmentManager(), answerList);
        mViewPager.setAdapter(mAnswerPagerAdapter);

    }

    /**
     *  Adds an answer to the Viewpager and Answers-list for this flashcard.
     *
     *  @param a    Answer to be added.
     */
    public void addAnswer(Answer a) {
        answerList.add(a);
        mAnswerPagerAdapter.notifyDataSetChanged();
        mViewPager.setCurrentItem(answerList.size() - 1);
    }

    /**
     *  Removes an answer from the Viewpager and Answers-list for this flashcard.
     *
     *  @param a    Answer to be removed.
     */
    public void removeAnswer(Answer a) {
        answerList.remove(a);

        if (answerList.isEmpty()) {
            Intent intent = new Intent(this, EditFlashcardActivity.class);

            intent.putExtra("deck", deck.getId());
            intent.putExtra("flashcard", flashcard.getId());

            startActivity(intent);
            finish();
        }

        mAnswerPagerAdapter.notifyDataSetChanged();
        mViewPager.setCurrentItem(0);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_edit_flashcard, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        return false;
    }
}