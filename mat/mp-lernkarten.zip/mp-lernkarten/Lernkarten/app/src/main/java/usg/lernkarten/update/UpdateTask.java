package usg.lernkarten.update;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.PowerManager;
import android.preference.PreferenceManager;
import android.widget.Toast;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import usg.lernkarten.util.ImportUtil;

/**
 * This class representy a async task to import decks and flashcards from a web resource
 */
public class UpdateTask extends AsyncTask<String, Integer, String> {

    private final Context context;
    private PowerManager.WakeLock mWakeLock;
    private final ProgressDialog mProgressDialog;

    private final ImportUtil importUtil;

    private boolean updateExecuted = false;

    public UpdateTask(Context context, ProgressDialog progressDialog) {
        this.context = context;
        this.mProgressDialog = progressDialog;
        this.importUtil = ImportUtil.get(context);
    }

    @Override
    protected String doInBackground(String... sUrl) {
        InputStream input = null;
        HttpURLConnection connection = null;
        try {
            URL url = new URL(sUrl[0]);
            connection = (HttpURLConnection) url.openConnection();
            connection.setConnectTimeout(5000);


            long currentModified = connection.getLastModified();

            SharedPreferences sharedPref = PreferenceManager.getDefaultSharedPreferences(context);
            long lastModified = sharedPref.getLong("lastModified", 0);

            if (currentModified > lastModified || currentModified == 0) {
                connection.connect();

                if (connection.getResponseCode() != HttpURLConnection.HTTP_OK) {
                    return "Server returned HTTP " + connection.getResponseCode()
                            + " " + connection.getResponseMessage();
                }
                input = connection.getInputStream();

                SharedPreferences.Editor editor = sharedPref.edit();
                editor.putLong("lastModified", new java.util.Date().getTime());
                editor.apply();

                importUtil.readJsonStream(input);
                updateExecuted = true;
            }

        } catch (Exception e) {
            e.printStackTrace();
            return e.toString();
        } finally {
            try {
                if (input != null)
                    input.close();
            } catch (IOException ignored) {
            }

            if (connection != null)
                connection.disconnect();
        }
        return null;
    }

    @Override
    protected void onPreExecute() {
        super.onPreExecute();

        PowerManager pm = (PowerManager) context.getSystemService(Context.POWER_SERVICE);
        mWakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK,
                getClass().getName());
        mWakeLock.acquire();

        if(mProgressDialog != null) {
            mProgressDialog.show();
        }

    }

    @Override
    protected void onProgressUpdate(Integer... progress) {
        super.onProgressUpdate(progress);

        if(mProgressDialog != null) {
            mProgressDialog.setIndeterminate(false);
            mProgressDialog.setMax(100);
            mProgressDialog.setProgress(progress[0]);
        }
    }

    @Override
    protected void onPostExecute(String result) {
        mWakeLock.release();
        if(mProgressDialog != null) {
            mProgressDialog.dismiss();
        }
        if (result != null)
            Toast.makeText(context, "Fehler beim Herunterladen: " + result, Toast.LENGTH_LONG).show();
        else {
            context.sendBroadcast(new Intent("usg.lernkarten.FLASHCARDS_UPDATED"));
            if(updateExecuted) {
                Toast.makeText(context, "Datei erfolgreich importiert.", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(context, "Keine neuen Daten vorhanden.", Toast.LENGTH_SHORT).show();
            }
        }

    }
}
