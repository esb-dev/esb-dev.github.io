/**
 * Musterprojekt Softwaretechnik
 * Copyright (c) 2015 by Institut für SoftwareArchitektur, TH Mittelhessen.
 * Lizenz Creative Commons CC BY-NC-SA 3.0
 *
 */
package usg.lernkarten.data.db;

import android.content.ContentValues;

import usg.lernkarten.data.Flashcard;

/**
 * Class that contains constants and helper-methods for the flashcard table.
 */
public final class FlashcardDB {

    public static final String TABLE_NAME = "flashcard";

    public static final String ID = "_id";
    public static final String FLASHCARD_QUESTION = "question";
    public static final String FLASHCARD_NUMBER_OF_CORRECT = "number_of_correct";
    public static final String FLASHCARD_NUMBER_OF_WRONG = "number_of_wrong";
    public static final String FLASHCARD_LAST_CORRECT = "last_correct";
    public static final String FLASHCARD_LAST_PLAYED = "last_played";
    public static final String FLASHCARD_DECK_ID = "deck_id";

    /**
     * Not intended for instantiation.
     */
    private FlashcardDB() {
    }

    public static ContentValues createContentValue(Flashcard flashcard) {
        ContentValues cv = new ContentValues();

        cv.put(FLASHCARD_QUESTION, flashcard.getQuestion());
        cv.put(FLASHCARD_NUMBER_OF_CORRECT, flashcard.getNumberOfCorrect());
        cv.put(FLASHCARD_NUMBER_OF_WRONG, flashcard.getNumberOfWrong());
        cv.put(FLASHCARD_LAST_CORRECT, flashcard.getLastCorrect());
        cv.put(FLASHCARD_LAST_PLAYED, flashcard.getLastPlayed());
        cv.put(FLASHCARD_DECK_ID, flashcard.getDeck().getId());

        return cv;
    }

}
