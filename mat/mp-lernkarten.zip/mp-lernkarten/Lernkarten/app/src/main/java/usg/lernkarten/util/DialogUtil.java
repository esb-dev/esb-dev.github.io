/**
 * Musterprojekt Softwaretechnik
 * Copyright (c) 2015 by Institut für SoftwareArchitektur, TH Mittelhessen.
 * Lizenz Creative Commons CC BY-NC-SA 3.0
 *
 */
package usg.lernkarten.util;


import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.v4.app.Fragment;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListAdapter;
import android.widget.TextView;

import usg.lernkarten.flashcard.answer.EditAnswerActivity;
import usg.lernkarten.flashcard.EditFlashcardActivity;
import usg.lernkarten.R;
import usg.lernkarten.flashcard.FlashcardListActivity;
import usg.lernkarten.data.Answer;
import usg.lernkarten.data.Deck;
import usg.lernkarten.data.Flashcard;

/**
 * This class offers several methods to show dialogs to the user.
 */
public class DialogUtil {


    public static class Item {

        public final String text;
        public final Integer icon;

        public Item(String text, Integer icon) {
            this.text = text;
            this.icon = icon;
        }

        @Override
        public String toString() {
            return text;
        }
    }

    /**
     * Shows a dialog that offers to take or to select a picture
     *
     * @param ctx   Context
     */
    public static void showPhotoDialog(final Context ctx) {

        final Item[] items = {
                new Item(ctx.getString(R.string.picture_take_picture), R.drawable.ic_camera_enhance_black_24dp),
                new Item(ctx.getString(R.string.picture_add_picture), R.drawable.flashcard)
        };

        ListAdapter adapter = new ArrayAdapter<Item>(
                ((Activity) ctx),
                android.R.layout.select_dialog_item,
                android.R.id.text1,
                items) {
            public View getView(int position, View convertView, ViewGroup parent) {

                View v = super.getView(position, convertView, parent);
                TextView tv = (TextView) v.findViewById(android.R.id.text1);

                tv.setCompoundDrawablesWithIntrinsicBounds(items[position].icon, 0, 0, 0);

                int dp5 = (int) (5 * ctx.getResources().getDisplayMetrics().density + 0.5f);
                tv.setCompoundDrawablePadding(dp5);

                return v;
            }
        };

        new AlertDialog.Builder(ctx).setAdapter(adapter, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                switch (which) {
                    case 0:
                        //take a picture
                        Intent i = new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
                        ((Activity) ctx).startActivityForResult(i, PictureUtil.CAPTURE_CAMERA_ACTIVITY_REQUEST_CODE);
                        break;
                    case 1:
                        //add a picture from gallery
                        Intent intent = new Intent();
                        intent.setType("image/*");
                        intent.setAction(Intent.ACTION_GET_CONTENT);
                        ((Activity) ctx).startActivityForResult(Intent.createChooser(intent, "Select Picture"),
                                PictureUtil.CAPTURE_GALLERY_ACTIVITY_REQUEST_CODE);
                        break;
                }
            }
        }).show();
    }

    /**
     * Shows a dialog that offers to take or to select a picture
     *
     * @param ctx   Fragment
     */
    public static void showPhotoDialog(final Fragment ctx) {

        final Item[] items = {
                new Item(ctx.getString(R.string.picture_take_picture), R.drawable.ic_camera_enhance_black_24dp),
                new Item(ctx.getString(R.string.picture_add_picture), R.drawable.flashcard)
        };

        ListAdapter adapter = new ArrayAdapter<Item>(
                ctx.getActivity(),
                android.R.layout.select_dialog_item,
                android.R.id.text1,
                items) {
            public View getView(int position, View convertView, ViewGroup parent) {

                View v = super.getView(position, convertView, parent);
                TextView tv = (TextView) v.findViewById(android.R.id.text1);

                tv.setCompoundDrawablesWithIntrinsicBounds(items[position].icon, 0, 0, 0);

                int dp5 = (int) (5 * ctx.getResources().getDisplayMetrics().density + 0.5f);
                tv.setCompoundDrawablePadding(dp5);

                return v;
            }
        };

        new AlertDialog.Builder(ctx.getActivity()).setAdapter(adapter, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                switch(which) {
                    case 0:
                        //take a picture
                        Intent i = new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
                        ctx.startActivityForResult(i, PictureUtil.CAPTURE_CAMERA_ACTIVITY_REQUEST_CODE);
                        break;
                    case 1:
                        //add a picture from gallery
                        Intent intent = new Intent();
                        intent.setType("image/*");
                        intent.setAction(Intent.ACTION_GET_CONTENT);
                        ctx.startActivityForResult(Intent.createChooser(intent, "Select Picture"),
                                PictureUtil.CAPTURE_GALLERY_ACTIVITY_REQUEST_CODE);
                        break;
                }
            }
        }).show();
    }

    /**
     * Shows a dialog to add an answer to a flashcard or to go back to the flashcard edit screen
     *
     * @param ctx       Context
     * @param deck      Deck
     * @param flashcard Flashcard
     */
    public static void showFlashcardDialog(final Context ctx, final Deck deck, final Flashcard flashcard) {
        final Item[] items = {
                new Item(ctx.getString(R.string.back), R.drawable.ic_keyboard_arrow_left_black_24dp),
                new Item(ctx.getString(R.string.answer_add_answer), R.drawable.ic_add_black_24dp)
        };

        ListAdapter adapter = new ArrayAdapter<Item>(
                ctx,
                android.R.layout.select_dialog_item,
                android.R.id.text1,
                items) {
            public View getView(int position, View convertView, ViewGroup parent) {

                View v = super.getView(position, convertView, parent);
                TextView tv = (TextView) v.findViewById(android.R.id.text1);

                tv.setCompoundDrawablesWithIntrinsicBounds(items[position].icon, 0, 0, 0);

                int dp5 = (int) (5 * ctx.getResources().getDisplayMetrics().density + 0.5f);
                tv.setCompoundDrawablePadding(dp5);

                return v;
            }
        };

        new AlertDialog.Builder(ctx).setAdapter(adapter, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Intent intent;
                switch(which) {
                    case 0:
                        //back to list of flashcard
                        intent = new Intent(ctx, FlashcardListActivity.class);
                        intent.putExtra("deck", deck.getId());
                        ctx.startActivity(intent);
                        break;
                    case 1:
                        //add an answer
                        intent = new Intent(ctx, EditAnswerActivity.class);
                        intent.putExtra("deck", deck.getId());
                        intent.putExtra("flashcard", flashcard.getId());
                        ctx.startActivity(intent);
                        break;
                }

                ((Activity) ctx).finish();
            }
        }).show();
    }

    /**
     * Shows a dialog to add another answer to a flashcard or to go back to the flashcard edit screen
     *
     * @param ctx       Context
     * @param deck      Deck
     * @param flashcard Flashcard
     */
    public static void showAnswerDialog(final Context ctx, final Deck deck, final Flashcard flashcard) {
        final Item[] items = {
                new Item(ctx.getString(R.string.back), R.drawable.ic_keyboard_arrow_left_black_24dp),
                new Item(ctx.getString(R.string.answer_add_answer_dialog), R.drawable.ic_add_black_24dp)
        };

        ListAdapter adapter = new ArrayAdapter<Item>(
                ctx,
                android.R.layout.select_dialog_item,
                android.R.id.text1,
                items) {
            public View getView(int position, View convertView, ViewGroup parent) {

                View v = super.getView(position, convertView, parent);
                TextView tv = (TextView) v.findViewById(android.R.id.text1);

                tv.setCompoundDrawablesWithIntrinsicBounds(items[position].icon, 0, 0, 0);

                int dp5 = (int) (5 * ctx.getResources().getDisplayMetrics().density + 0.5f);
                tv.setCompoundDrawablePadding(dp5);

                return v;
            }
        };

        new AlertDialog.Builder(ctx).setAdapter(adapter, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Intent intent;
                switch(which) {
                    case 0:
                        //back to flashcard
                        intent = new Intent(ctx, EditFlashcardActivity.class);

                        intent.putExtra("deck", deck.getId());
                        intent.putExtra("flashcard", flashcard.getId());

                        ctx.startActivity(intent);

                        ((Activity) ctx).finish();

                        break;
                    case 1:
                        //add an answer
                        Answer a = new Answer();
                        a.setFlashcard(flashcard);
                        ((EditAnswerActivity) ctx).addAnswer(a);

                        break;
                }
            }
        }).show();
    }

}
