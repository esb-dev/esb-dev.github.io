/**
 * Musterprojekt Softwaretechnik
 * Copyright (c) 2015 by Institut für SoftwareArchitektur, TH Mittelhessen.
 * Lizenz Creative Commons CC BY-NC-SA 3.0
 *
 */
package usg.lernkarten.flashcard;

import android.app.SearchManager;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.view.MenuItemCompat;
import android.support.v7.app.ActionBarActivity;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.SearchView;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Filter;
import android.widget.ListView;
import android.widget.TextView;

import com.gc.materialdesign.views.ButtonFloat;

import java.util.List;

import usg.lernkarten.MainActivity;
import usg.lernkarten.R;
import usg.lernkarten.data.Deck;
import usg.lernkarten.data.Flashcard;
import usg.lernkarten.data.dao.AppFactory;
import usg.lernkarten.data.dao.DeckDAO;
import usg.lernkarten.data.dao.FlashcardDAO;

/**
 *  This class represents the Activity that shows the list of all flashcards of a certain deck.
 */
public class FlashcardListActivity extends AppCompatActivity implements SearchView.OnQueryTextListener {

    private ListView mListView;
    private Filter filter;
    private Deck deck;
    private List<Flashcard> mFlashcards;
    private TextView mAddFlashcardHint;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.show_flashcards_activity);

        setTitle(getString(R.string.app_name));

        /**
         *  Support Actionbar to get Material Design Actionbar on Android < 5.
         */
        Toolbar toolbar = (Toolbar) findViewById(R.id.flashcard_actionbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        mListView = (ListView) findViewById(R.id.show_cards_listview);
        mAddFlashcardHint = (TextView) findViewById(R.id.button_add_flashcard_hint);

        // Get Deck-ID of selected deck.
        int deckId = getIntent().getExtras().getInt("deck");
        DeckDAO deckdao = AppFactory.get(this).getDeckDAO();
        deck = deckdao.findById(deckId);

        FlashcardDAO flashcardDAO = AppFactory.get(this).getFlashcardDAO();

        mFlashcards = flashcardDAO.findByDeck(deck);

        FlashcardListAdapter mAdapter = new FlashcardListAdapter(this, mFlashcards, mListView);
        mListView.setAdapter(mAdapter);

        filter = mAdapter.getFilter();
        mListView.setTextFilterEnabled(false);

        ButtonFloat buttonAdd = (ButtonFloat) findViewById(R.id.button_add_flashcard);
        buttonAdd.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {

                // New Card Intent
                Intent intent = new Intent(v.getContext(), EditFlashcardActivity.class);
                intent.putExtra("deck", deck.getId());
                intent.putExtra("flashcard", -1);

                startActivity(intent);

            }
        });


    }

    @Override
    protected void onStart() {
        super.onStart();

        if(mFlashcards.size() > 0) {
            mAddFlashcardHint.setVisibility(View.GONE);
        }

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_show_flashcards, menu);

        SearchManager searchManager =
                (SearchManager) getSystemService(Context.SEARCH_SERVICE);

        MenuItem searchItem = menu.findItem(R.id.show_flashcards_search);
        SearchView searchView = (SearchView) MenuItemCompat.getActionView(searchItem);

        searchView.setSearchableInfo(
                searchManager.getSearchableInfo(getComponentName()));
        searchView.setSubmitButtonEnabled(true);
        searchView.setOnQueryTextListener(this);

        return super.onCreateOptionsMenu(menu);
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                Intent intent = new Intent(this, MainActivity.class);
                startActivity(intent);
                finish();
                break;
        }

        return super.onOptionsItemSelected(item);
    }


    @Override
    public boolean onQueryTextSubmit(String query) {
        return false;
    }

    @Override
    public boolean onQueryTextChange(String newText) {
        filter.filter(newText);
        return true;
    }
}
