/**
 * Musterprojekt Softwaretechnik
 * Copyright (c) 2015 by Institut für SoftwareArchitektur, TH Mittelhessen.
 * Lizenz Creative Commons CC BY-NC-SA 3.0
 */
package usg.lernkarten.util;

import android.content.Context;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.provider.MediaStore;
import android.provider.OpenableColumns;
import android.util.Base64;
import android.webkit.MimeTypeMap;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;

import usg.lernkarten.R;
import usg.lernkarten.data.Picture;

/**
 * This class offers methods to handle pictures in the app.
 */
public class PictureUtil {

    public static final int CAPTURE_CAMERA_ACTIVITY_REQUEST_CODE = 100;
    public static final int CAPTURE_GALLERY_ACTIVITY_REQUEST_CODE = 200;

    /**
     * Saves the given picture to the internal storage.
     *
     * @param ctx         Contex - used to access the storage.
     * @param bitmapImage the image
     * @param picture     the picture entity used to store information about the image.
     * @return path of the saved image
     */
    public static String savePictureToInternalStorage(Context ctx, Bitmap bitmapImage, Picture picture) {
        Bitmap.CompressFormat format;
        switch (ctx.getString(R.string.import_image_file_type_png).toUpperCase()) {
            case "JPEG":
                format = Bitmap.CompressFormat.JPEG;
                break;
            case "PNG":
                format = Bitmap.CompressFormat.PNG;
                break;
            default:
                format = Bitmap.CompressFormat.JPEG;
                break;
        }
        File file = new File(ctx.getApplicationContext().getFilesDir(), picture.getId() + "." + getFileExtensionAsString(ctx));
        FileOutputStream fos;

        try {
            fos = new FileOutputStream(file);
            bitmapImage.compress(format, 100, fos);
            fos.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        Uri uri = Uri.fromFile(file);

        picture.setMimeType(getMimeType(uri.toString()));
        if (String.valueOf(picture.getSize()).isEmpty()) {
            picture.setSize(String.valueOf(file.length()));
        }

        return file.getAbsolutePath();
    }

    /**
     * Returns the Bitmap object for a certain Data-URI
     *
     * @param ctx     Context - used to access the internal storage
     * @param uri     The Data-Uri that contains the image
     * @param picture The picture object for metadata
     * @return Bitmap for the given Data-URI
     */
    public static Bitmap getBitmapFromDataURI(Context ctx, Uri uri, Picture picture) {
        try {
            Bitmap image = MediaStore.Images.Media.getBitmap(ctx.getApplicationContext().getContentResolver(), uri);
            Cursor cursor = ctx.getContentResolver()
                    .query(uri, null, null, null, null, null);

            try {
                if (cursor != null && cursor.moveToFirst()) {

                    // Note it's called "Display Name".  This is
                    // provider-specific, and might not necessarily be the file name.
                    String displayName = cursor.getString(
                            cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME));
                    picture.setName(displayName.replaceFirst("[.][^.]+$", ""));

                    int sizeIndex = cursor.getColumnIndex(OpenableColumns.SIZE);

                    // If the size is unknown, the value stored is null.  But since an
                    // int can't be null in Java, the behavior is implementation-specific,
                    // which is just a fancy term for "unpredictable".  So as
                    // a rule, check if it's null before assigning to an int.  This will
                    // happen often:  The storage API allows for remote files, whose
                    // size might not be locally known.
                    String size;
                    if (!cursor.isNull(sizeIndex)) {
                        // Technically the column stores an int, but cursor.getString()
                        // will do the conversion automatically.
                        size = cursor.getString(sizeIndex);
                    } else {
                        size = "Unknown";
                    }
                    picture.setSize(size);
                }
            } finally {
                if (cursor != null) cursor.close();
            }
            return image;
        } catch (Exception e) {
            return BitmapFactory.decodeResource(ctx.getResources(), R.drawable.deck);
        }

    }

    /**
     * Returns the Bitmap object for a certain Data-URI
     *
     * @param ctx Context - used to access the internal storage
     * @param uri The Data-Uri that contains the image
     * @return Bitmap for the given Data-URI
     */
    public static Bitmap getBitmapFromDataURI(Context ctx, Uri uri) {
        try {
            return MediaStore.Images.Media.getBitmap(ctx.getApplicationContext().getContentResolver(), uri);
        } catch (Exception e) {
            return BitmapFactory.decodeResource(ctx.getResources(), R.drawable.deck);
        }

    }

    /**
     * Gets the Bitmap for a given picture object
     *
     * @param ctx     Context - used to access the internal storage
     * @param picture picture-object that contains the needed metadata
     * @return Bitmap for the given picture
     */
    public static Bitmap getBitmapFromPicture(Context ctx, Picture picture) {
        try {
            File mypath = new File(ctx.getApplicationContext().getFilesDir(), picture.getId() + "." + getFileExtensionAsString(ctx));
            return BitmapFactory.decodeStream(new FileInputStream(mypath));
        } catch (Exception e) {
            return BitmapFactory.decodeResource(ctx.getResources(), R.drawable.deck);
        }

    }

    /**
     * Returns the Mime-Type for a given url
     *
     * @param url
     * @return Mime-Type for the given url
     */
    private static String getMimeType(String url) {
        String type = null;
        String extension = MimeTypeMap.getFileExtensionFromUrl(url);
        if (extension != null) {
            MimeTypeMap mime = MimeTypeMap.getSingleton();
            type = mime.getMimeTypeFromExtension(extension);
        }
        return type;
    }


    private static String getFileExtensionAsString(Context ctx) {
        String fileExtension;

        switch (ctx.getString(R.string.import_image_file_type_png).toUpperCase()) {
            case "JPEG":
                fileExtension = "jpeg";
                break;
            case "PNG":
                fileExtension = "png";
                break;
            default:
                fileExtension = "jpeg";
        }

        return fileExtension;
    }
}
