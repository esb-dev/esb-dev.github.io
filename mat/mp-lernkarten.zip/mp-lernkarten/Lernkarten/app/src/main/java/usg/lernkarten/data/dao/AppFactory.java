/**
 * Musterprojekt Softwaretechnik
 * Copyright (c) 2015 by Institut für SoftwareArchitektur, TH Mittelhessen.
 * Lizenz Creative Commons CC BY-NC-SA 3.0
 *
 */
package usg.lernkarten.data.dao;

import android.content.Context;
import usg.lernkarten.data.dao.sqlite.AnswerSQLiteDAO;
import usg.lernkarten.data.dao.sqlite.DeckSQLiteDAO;
import usg.lernkarten.data.dao.sqlite.FlashcardSQLiteDAO;
import usg.lernkarten.data.dao.sqlite.PictureSQLiteDAO;

/**
 * This class offers fabric methods to access the concrete dao-objects.
 */
public class AppFactory {

    private static AppFactory daoFactory = null;

    private AnswerDAO answerDAO;
    private DeckDAO deckDAO;
    private FlashcardDAO flashcardDAO;
    private PictureDAO pictureDAO;

    private Context ctx;

    /**
     * No further instantiation, singeton
     */
    private AppFactory() {

    }

    public static AppFactory get(Context ctx) {
        if(daoFactory == null) {
            daoFactory = new AppFactory();
            daoFactory.ctx = ctx.getApplicationContext();
        }

        return daoFactory;
    }

    public AnswerDAO getAnswerDAO() {
        if(answerDAO == null) {
            answerDAO = new AnswerSQLiteDAO(ctx);
        }

        return answerDAO;
    }

    public DeckDAO getDeckDAO() {
        if(deckDAO == null) {
            deckDAO = new DeckSQLiteDAO(ctx);
        }

        return deckDAO;
    }

    public FlashcardDAO getFlashcardDAO() {
        if(flashcardDAO == null) {
            flashcardDAO = new FlashcardSQLiteDAO(ctx);
        }

        return flashcardDAO;
    }

    public PictureDAO getPictureDAO() {
        if(pictureDAO == null) {
            pictureDAO = new PictureSQLiteDAO(ctx);
        }

        return pictureDAO;
    }

}
