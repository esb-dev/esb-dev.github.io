/**
 * Musterprojekt Softwaretechnik
 * Copyright (c) 2015 by Institut für SoftwareArchitektur, TH Mittelhessen.
 * Lizenz Creative Commons CC BY-NC-SA 3.0
 */
package usg.lernkarten.deck;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import usg.lernkarten.R;
import usg.lernkarten.data.Deck;
import usg.lernkarten.data.Picture;
import usg.lernkarten.data.dao.AppFactory;
import usg.lernkarten.data.dao.DeckDAO;
import usg.lernkarten.data.dao.PictureDAO;
import usg.lernkarten.util.PictureUtil;

/**
 * This class represents a dialog to create or edit a deck.
 */
public class EditDeckDialog extends android.support.v4.app.DialogFragment {

    //Request-Codes if come back from camera or gallery activity
    private static final int CAPTURE_CAMERA_ACTIVITY_REQUEST_CODE = 100;
    private static final int CAPTURE_GALLERY_ACTIVITY_REQUEST_CODE = 200;

    private View dialogView;
    private OnDialogClickedListener callback;

    private EditText name;
    private EditText description;

    private Deck deck;

    private ImageView image;


    private AlertDialog.Builder builder;

    public interface OnDialogClickedListener {
        void onDialogClicked();
    }

    public void setOnDialogClickedListener(OnDialogClickedListener l) {
        callback = l;
    }


    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        builder = new AlertDialog.Builder(getActivity());
        LayoutInflater inflater = getActivity().getLayoutInflater();

        dialogView = inflater.inflate(R.layout.new_deck_dialog, null);
        name = (EditText) dialogView.findViewById(R.id.new_deck_dialog_deck_name);
        description = (EditText) dialogView.findViewById(R.id.new_deck_dialog_deck_description);
        image = (ImageView) dialogView.findViewById(R.id.add_photo_image_view);

        Toolbar dialogToolbar = (Toolbar) dialogView.findViewById(R.id.deck_toolbar);
        dialogToolbar.setTitle(getString(R.string.deck_new_deck_popup_title));
        if (dialogToolbar != null) {
            dialogToolbar.inflateMenu(R.menu.menu_new_deck_dialog);
            dialogToolbar.setOnMenuItemClickListener(new Toolbar.OnMenuItemClickListener() {
                @Override
                public boolean onMenuItemClick(MenuItem menuItem) {
                    switch (menuItem.getItemId()) {
                        case R.id.deck_add_picture_camera:
                            Intent i = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                            startActivityForResult(i, CAPTURE_CAMERA_ACTIVITY_REQUEST_CODE);
                            return true;
                        case R.id.deck_add_picture_gallery:

                            Intent intent = new Intent();
                            intent.setType("image/*");
                            intent.setAction(Intent.ACTION_GET_CONTENT);
                            startActivityForResult(Intent.createChooser(intent, "Select Picture"),
                                    CAPTURE_GALLERY_ACTIVITY_REQUEST_CODE);
                            return true;
                    }
                    return true;
                }
            });
        }

        builder.setView(dialogView)
                .setPositiveButton(R.string.save, null)
                .setNegativeButton(R.string.cancel, null);


        if (getArguments() != null) {
            //edit deck
            Integer deckId = getArguments().getInt("id");
            deck = AppFactory.get(getActivity()).getDeckDAO().findById(deckId);

            if (deck == null) {
                deck = new Deck();
            }

            this.name.setText(deck.getName());
            this.description.setText(deck.getDescription());
            image.setImageBitmap(PictureUtil.getBitmapFromPicture(getActivity(), deck.getPicture()));

        } else {
            //create new deck
            deck = new Deck();
        }

        final AlertDialog dialog = builder.create();
        dialog.setOnShowListener(new DialogInterface.OnShowListener() {
            @Override
            public void onShow(DialogInterface dialogInterface) {
                Button positive = dialog.getButton(AlertDialog.BUTTON_POSITIVE);
                positive.setOnClickListener(new View.OnClickListener() {

                    @Override
                    public void onClick(View view) {
                        if (saveData()) { //don't dismiss dialog if there are validation errors
                            callback.onDialogClicked();
                            dialog.dismiss();
                        }
                    }

                });

                Button negative = dialog.getButton(AlertDialog.BUTTON_NEGATIVE);
                negative.setOnClickListener(new View.OnClickListener() {

                    @Override
                    public void onClick(View view) {
                        callback.onDialogClicked();
                        dialog.dismiss();
                    }

                });
            }
        });

        return dialog;
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        switch (requestCode) {
            case CAPTURE_CAMERA_ACTIVITY_REQUEST_CODE:
                if (resultCode == Activity.RESULT_OK) {
                    try {
                        Bundle extras = data.getExtras();
                        Bitmap image = (Bitmap) extras.get("data");

                        ImageView imageView = (ImageView) dialogView.findViewById(R.id.add_photo_image_view);
                        imageView.setImageBitmap(image);
                    } catch (Exception e) {
                        Toast.makeText(getActivity().getApplicationContext(), getString(R.string.picture_take_picture_camera_error),
                                Toast.LENGTH_LONG).show();
                    }
                }
                break;
            case CAPTURE_GALLERY_ACTIVITY_REQUEST_CODE:
                if (resultCode == Activity.RESULT_OK) {
                    Uri selectedImage = data.getData();
                    Bitmap image = PictureUtil.getBitmapFromDataURI(getActivity().getApplicationContext(), selectedImage);
                    ImageView imageView = (ImageView) dialogView.findViewById(R.id.add_photo_image_view);
                    imageView.setImageBitmap(image);
                }
                break;
            default:
                //do nothing
        }
    }

    /**
     * Saves or updates the deck in db.
     */
    private boolean saveData() {

        if (name.getText().toString().length() > 0 && description.getText().toString().length() > 0) {
            Picture pic = deck.getPicture();
            PictureDAO picDAO = AppFactory.get(getActivity().getApplicationContext()).getPictureDAO();

            Bitmap old = PictureUtil.getBitmapFromPicture(getActivity().getApplicationContext(), pic);
            Bitmap bitmap = ((BitmapDrawable) image.getDrawable()).getBitmap();
            if (pic == null || !old.sameAs(bitmap)) {
                pic = new Picture();
                pic.setName(getResources().getString(R.string.deck_new_deck_image_name));
                picDAO.persist(pic);
                PictureUtil.savePictureToInternalStorage(getActivity().getApplicationContext(), bitmap, pic);
                picDAO.update(pic);
            }

            deck.setName(name.getText().toString());
            deck.setDescription(description.getText().toString());
            deck.setPicture(pic);
            DeckDAO deckDAO = AppFactory.get(getActivity().getApplicationContext()).getDeckDAO();

            if (deck.getId() == null) {
                deckDAO.persist(deck);
            } else {
                deckDAO.update(deck);
            }

            return true;

        } else {
            if (name.getText().toString().length() < 1) {
                Toast.makeText(getActivity(), "Bitte den Titel ausfüllen.", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(getContext(), "Bitte eine Beschreibung eingeben.", Toast.LENGTH_SHORT).show();
            }

            return false;
        }

    }
}
