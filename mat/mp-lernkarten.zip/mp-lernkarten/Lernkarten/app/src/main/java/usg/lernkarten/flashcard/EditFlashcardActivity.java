/**
 * Musterprojekt Softwaretechnik
 * Copyright (c) 2015 by Institut für SoftwareArchitektur, TH Mittelhessen.
 * Lizenz Creative Commons CC BY-NC-SA 3.0
 *
 */
package usg.lernkarten.flashcard;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.v7.app.ActionBarActivity;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import java.util.List;

import usg.lernkarten.MainActivity;
import usg.lernkarten.R;
import usg.lernkarten.data.Deck;
import usg.lernkarten.data.Flashcard;
import usg.lernkarten.data.Picture;
import usg.lernkarten.data.dao.AppFactory;
import usg.lernkarten.data.dao.DeckDAO;
import usg.lernkarten.data.dao.FlashcardDAO;
import usg.lernkarten.data.dao.PictureDAO;
import usg.lernkarten.util.DialogUtil;
import usg.lernkarten.util.PictureUtil;

/**
 *  This class represents an activity to edit a flashcard.
 */
public class EditFlashcardActivity extends AppCompatActivity {

    private ArrayAdapter<Picture> mAdapter;
    private EditText mFlashcardQuestion;

    private Integer flashcardId;

    private Flashcard flashcard;
    private Deck deck;

    private FlashcardDAO fdao;

    private Activity activity;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        activity = this;

        setContentView(R.layout.edit_flashcard_activity);

        Toolbar cardToolbar = (Toolbar) findViewById(R.id.card_toolbar);
        cardToolbar.setTitle(getString(R.string.flashcard_front_title));
        if (cardToolbar != null) {
            cardToolbar.inflateMenu(R.menu.menu_edit_flashcard_card);
            cardToolbar.setOnMenuItemClickListener(new Toolbar.OnMenuItemClickListener() {
                @Override
                public boolean onMenuItemClick(MenuItem menuItem) {
                    switch (menuItem.getItemId()) {
                        case R.id.flashcard_add_picture:
                            DialogUtil.showPhotoDialog(activity);
                            return true;
                    }
                    return true;
                }
            });
        }

        //SupportActionbar to support material design on Android < 5
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar_main);
        toolbar.setNavigationIcon(R.drawable.ic_clear_white_24dp);
        setSupportActionBar(toolbar);
        getSupportActionBar().setHomeAsUpIndicator(R.drawable.ic_clear_white_24dp);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowTitleEnabled(false);

        ListView mListView = (ListView) findViewById(R.id.pictureListView);
        mFlashcardQuestion = (EditText) findViewById(R.id.flashcard_question);
        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(this);

        DeckDAO ddao = AppFactory.get(this).getDeckDAO();
        fdao = AppFactory.get(this).getFlashcardDAO();

        Intent intent = getIntent();

        flashcardId = intent.getIntExtra("flashcard", -1);
        Integer deckId = intent.getIntExtra("deck", -1);

        deck = ddao.findById(deckId);

        if(flashcardId > -1) {
            flashcard = fdao.findById(flashcardId);
            mFlashcardQuestion.setText(flashcard.getQuestion());
        } else {
            flashcard = new Flashcard();
            flashcard.setDeck(deck);
        }

        List<Picture> pictureList = flashcard.getPictures();
        mAdapter = new PictureListAdapter(this, pictureList);

        mListView.setAdapter(mAdapter);

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_edit_flashcard, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        Intent intent;

        switch (item.getItemId()) {
            case R.id.action_edit_flashcard_save:

                //validation
                if(mFlashcardQuestion.getText().toString().trim().isEmpty()) {
                    mFlashcardQuestion.setError(getString(R.string.form_field_required));
                    return true;
                }

                //save changes
                flashcard.setQuestion(mFlashcardQuestion.getText().toString());

                if(flashcardId < 0) {
                    //new flashcard
                    fdao.persist(flashcard);
                } else {
                    //existing flashcard
                    fdao.update(flashcard);
                }

                DialogUtil.showFlashcardDialog(this, deck, flashcard);

                return true;
            case android.R.id.home:
                //discard changes
                SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
                if (prefs.getBoolean("tablet", false)) {
                    intent = new Intent(this, MainActivity.class);
                } else {
                    intent = new Intent(this, FlashcardListActivity.class);
                    intent.putExtra("deck", deck.getId());
                }
                startActivity(intent);
                this.finish();

                return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        switch (requestCode){
            case PictureUtil.CAPTURE_CAMERA_ACTIVITY_REQUEST_CODE:
                if (resultCode == Activity.RESULT_OK) {
                    try {
                        Bundle extras = data.getExtras();
                        Bitmap image = (Bitmap) extras.get("data");

                        Picture picture = new Picture();
                        picture.setName(getString(R.string.picture_photo_camera));

                        savePicture(image, picture);
                    }catch (Exception e){
                        Toast.makeText(getApplicationContext(), getString(R.string.picture_take_picture_camera_error),
                                Toast.LENGTH_LONG).show();
                    }
                }
                break;
            case PictureUtil.CAPTURE_GALLERY_ACTIVITY_REQUEST_CODE:
                if (resultCode == Activity.RESULT_OK) {
                    Uri selectedImage = data.getData();
                    Picture picture = new Picture();
                    Bitmap image = PictureUtil.getBitmapFromDataURI(this, selectedImage, picture);

                    savePicture(image, picture);
                }
                break;
            default:
                //do nothing
        }
    }

    private void savePicture(Bitmap image, Picture picture) {
        PictureDAO pdao = AppFactory.get(this).getPictureDAO();

        pdao.persist(picture);

        PictureUtil.savePictureToInternalStorage(this, image, picture);
        pdao.update(picture);

        flashcard.addPicture(picture);

        mAdapter.notifyDataSetChanged();
    }

}
