/**
 * Musterprojekt Softwaretechnik
 * Copyright (c) 2015 by Institut für SoftwareArchitektur, TH Mittelhessen.
 * Lizenz Creative Commons CC BY-NC-SA 3.0
 *
 */
package usg.lernkarten.data.dao.sqlite;

import static usg.lernkarten.data.db.DeckDB.*;
import static usg.lernkarten.data.db.FlashcardDB.FLASHCARD_LAST_PLAYED;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;

import usg.lernkarten.data.Deck;
import usg.lernkarten.data.Flashcard;
import usg.lernkarten.data.dao.DeckDAO;
import usg.lernkarten.data.dao.FlashcardDAO;
import usg.lernkarten.data.db.DeckDB;
import usg.lernkarten.data.db.FlashcardDB;
import usg.lernkarten.data.db.util.MySQLiteOpenHelper;

/**
 * Concrete Data-Access Class to access the data from a SQLite-DB
 */
public class DeckSQLiteDAO implements DeckDAO {

    private final MySQLiteOpenHelper mySQLiteOpenHelper;
    private final Context context;

    public DeckSQLiteDAO(Context ctx) {
        this.context = ctx;
        mySQLiteOpenHelper = new MySQLiteOpenHelper(ctx);
    }

    @Override
    public List<Deck> findAll() {
        List<Deck> result = new ArrayList<>();

        SQLiteDatabase db = mySQLiteOpenHelper.getReadableDatabase();
        String[] projection = {ID, DECK_NAME, DECK_DESCRIPTION, DECK_PICTURE_ID};

        Cursor c = db.query(TABLE_NAME, projection, null, null, null, null, null);

        while(c.moveToNext()) {
            Deck d = new Deck();
            d.setId(c.getInt(0));
            d.setName(c.getString(1));
            d.setDescription(c.getString(2));
            d.setPicture(new PictureSQLiteDAO(context).findById(c.getInt(3)));

            result.add(d);
        }

        c.close();
        db.close();

        return result;
    }

    @Override
    public Deck findByName(String name) {
        Deck d = null;

        SQLiteDatabase db = mySQLiteOpenHelper.getReadableDatabase();
        String[] projection = {ID, DECK_NAME, DECK_DESCRIPTION, DECK_PICTURE_ID};

        Cursor c = db.query(TABLE_NAME, projection, DECK_NAME + "=" + "'" + name + "'", null, null, null, null);

        if(c.moveToNext()) {
            d = new Deck();
            d.setId(c.getInt(0));
            d.setName(c.getString(1));
            d.setDescription(c.getString(2));
            d.setPicture(new PictureSQLiteDAO(context).findById(c.getInt(3)));
        }

        c.close();
        db.close();

        return d;
    }

    @Override
    public Deck findById(Integer id) {
        Deck d = null;

        SQLiteDatabase db = mySQLiteOpenHelper.getReadableDatabase();
        String[] projection = {ID, DECK_NAME, DECK_DESCRIPTION, DECK_PICTURE_ID};

        Cursor c = db.query(TABLE_NAME, projection, ID + "=" + id, null, null, null, null);

        if(c.moveToNext()) {
            d = new Deck();
            d.setId(c.getInt(0));
            d.setName(c.getString(1));
            d.setDescription(c.getString(2));
            d.setPicture(new PictureSQLiteDAO(context).findById(c.getInt(3)));
        }

        c.close();
        db.close();

        return d;
    }

    public Long getLastPlayed(Deck deck) {

        SQLiteDatabase db = mySQLiteOpenHelper.getReadableDatabase();
        final String query = "SELECT MAX(" + FLASHCARD_LAST_PLAYED + ") FROM " + FlashcardDB.TABLE_NAME + " f WHERE f." + FlashcardDB.FLASHCARD_DECK_ID + " =?;";
        Cursor c = db.rawQuery(query, new String[]{String.valueOf(deck.getId())});

        Long lastPlayed = 0L;
        while(c.moveToNext()) {
            Log.d("CMOVE", "TPONEXT");
            lastPlayed = c.getLong(0);
        }

        c.close();
        db.close();

        return lastPlayed;
    }

    @Override
    public Long persist(Deck deck) {
        SQLiteDatabase db = mySQLiteOpenHelper.getWritableDatabase();
        ContentValues cv = DeckDB.createContentValue(deck);
        long id = db.insert(TABLE_NAME, null, cv);
        deck.setId((int) id);

        db.close();
        return id;
    }

    @Override
    public void update(Deck deck) {
        SQLiteDatabase db = mySQLiteOpenHelper.getWritableDatabase();
        ContentValues cv = DeckDB.createContentValue(deck);
        String[] whereArgs = { "" + deck.getId() };
        db.update(TABLE_NAME, cv, ID + "=?", whereArgs);

        db.close();
    }

    @Override
    public void delete(Deck deck) {
        FlashcardDAO fdao = new FlashcardSQLiteDAO(context);

        List<Flashcard> flashcards = fdao.findByDeck(deck);
        for(Flashcard f : flashcards) {
            fdao.delete(f);
        }

        SQLiteDatabase db = mySQLiteOpenHelper.getWritableDatabase();
        String[] whereArgs = { "" + deck.getId() };
        db.delete(TABLE_NAME, ID + "=?", whereArgs);

        db.close();
    }

}
