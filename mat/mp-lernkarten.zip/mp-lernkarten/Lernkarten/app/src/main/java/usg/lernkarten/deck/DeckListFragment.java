/**
 * Musterprojekt Softwaretechnik
 * Copyright (c) 2015 by Institut für SoftwareArchitektur, TH Mittelhessen.
 * Lizenz Creative Commons CC BY-NC-SA 3.0
 */
package usg.lernkarten.deck;

import android.annotation.TargetApi;
import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.SearchView;
import android.text.TextUtils;
import android.util.Log;
import android.view.ActionMode;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Filter;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.gc.materialdesign.views.ButtonFloat;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import usg.lernkarten.data.dao.AppFactory;
import usg.lernkarten.data.dao.DeckDAO;
import usg.lernkarten.flashcard.EmptyFlashcardsFragment;
import usg.lernkarten.flashcard.FlashcardListFragment;
import usg.lernkarten.MainActivity;
import usg.lernkarten.util.PictureUtil;
import usg.lernkarten.R;
import usg.lernkarten.flashcard.FlashcardListActivity;
import usg.lernkarten.data.Deck;
import usg.lernkarten.learnmode.FlashcardLearnActivity;

/**
 * The fragment that shows the list of all or filtered decks.
 */
public class DeckListFragment extends Fragment implements SearchView.OnQueryTextListener {

    private View rootView;

    private ListView mListView;
    private Filter filter;

    private ArrayAdapter<Deck> mAdapter;
    private List<Deck> mDecks;

    private FrameLayout mFragmentContainer;

    private boolean mHasTwoPanes;

    private Context mContext;
    private boolean actionMode;
    private android.support.v7.view.ActionMode mActionMode;
    private int posActionMode;

    private BroadcastReceiver updateReceiver;

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        //The activity that uses this fragment should be created first

        setHasOptionsMenu(true);

        final DeckDAO deckDAO = AppFactory.get(getActivity().getApplicationContext()).getDeckDAO();

        TextView mAddDeckHint = (TextView) rootView.findViewById(R.id.button_add_deck_hint);
        mListView = (ListView) rootView.findViewById(R.id.deck_listview);
        mListView.setChoiceMode(AbsListView.CHOICE_MODE_MULTIPLE);
        mDecks = deckDAO.findAll();
        mContext = getActivity();

        if (mFragmentContainer != null) {

            //Tablet-layout is used here
            mHasTwoPanes = true;
            actionMode = false;

            //mListView.setChoiceMode(ListView.CHOICE_MODE_SINGLE);
            mListView.setBackgroundColor(Color.WHITE);

            //Set Tablet-Mode in Shared-Preferences to determine it in other activites
            SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(getActivity().getApplicationContext());
            SharedPreferences.Editor editor = prefs.edit();
            editor.putBoolean("tablet", true);
            editor.apply();

        }

        if (mDecks.size() > 0) {
            //the hint message on the + button should only be displayed if there are no Decks in the list
            mAddDeckHint.setVisibility(View.GONE);
        }

        //set adapter as anonymous class
        mAdapter = new ArrayAdapter<Deck>(getActivity(), R.layout.deck_list_item, mDecks) {

            @Override
            public View getView(final int position, final View convertView, ViewGroup parent) {

                View rowView = convertView;

                if (rowView == null) {
                    LayoutInflater inflater = (LayoutInflater) mContext
                            .getSystemService(Context.LAYOUT_INFLATER_SERVICE);

                    rowView = mHasTwoPanes ? inflater.inflate(R.layout.deck_list_item_multipane, parent, false) : inflater.inflate(R.layout.deck_list_item, parent, false);
                }

                TextView textViewTitle = (TextView) rowView.findViewById(R.id.list_item_title);
                textViewTitle.setText(mDecks.get(position).getName());

                TextView textViewDesc = (TextView) rowView.findViewById(R.id.list_item_desc);
                textViewDesc.setText(mDecks.get(position).getDescription());

                TextView textViewLastPlayed = (TextView) rowView.findViewById(R.id.list_item_last_visited);
                ImageView imageView = (ImageView) rowView.findViewById(R.id.list_item_thumb);

                Long lastPlayed = AppFactory.get(getActivity()).getDeckDAO().getLastPlayed(mDecks.get(position));

                String dateString = "Neu";

                Date date = new Date(lastPlayed);
                java.text.DateFormat dateFormat = android.text.format.DateFormat.getDateFormat(getContext());
                dateString = lastPlayed > 0 ? dateFormat.format(date) : dateString;

                textViewLastPlayed.setText(getString(R.string.statistic_deck_list_item_last_played_text, dateString));

                Bitmap image;
                if (mDecks.get(position).getPicture() != null) {
                    image = PictureUtil.getBitmapFromPicture(mContext, mDecks.get(position).getPicture());
                    if (image != null) {
                        imageView.setImageBitmap(image);
                    }
                }


                rowView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        if (actionMode) {

                            //selects or deselect this item
                            //posActionMode = position;
                            mListView.setItemChecked(position, !mListView.isItemChecked(position));

                            mActionMode.setTitle(mListView.getCheckedItemCount() + " ausgewählt");

                            if (mListView.getCheckedItemCount() == 0) {
                                mActionMode.finish();
                                return;
                            }

                            MenuItem editItem = mActionMode.getMenu().findItem(R.id.menu_edit);
                            MenuItem flashcardItem = mActionMode.getMenu().findItem(R.id.menu_flashcards);

                            //disable edit if there is more than one selected
                            if (mListView.getCheckedItemCount() > 1) {

                                editItem.setEnabled(false);
                                editItem.getIcon().setAlpha(130);

                                flashcardItem.setEnabled(false);
                                flashcardItem.getIcon().setAlpha(130);

                            } else {

                                editItem.setEnabled(true);
                                editItem.getIcon().setAlpha(255);

                                flashcardItem.setEnabled(true);
                                flashcardItem.getIcon().setAlpha(255);

                            }

                        } else {

                            //visualize the tap on this item
                            mListView.clearChoices();
                            mListView.setItemChecked(position, true);
                        }

                        if (mHasTwoPanes) {
                            //show flashcards for this Deck on tablet
                            showDetailFragment(position);
                        } else {

                            //start learnmode, if on smartphone
                            if (!actionMode) {
                                Intent i = new Intent(mContext, FlashcardLearnActivity.class);
                                i.putExtra("deck", mDecks.get(position).getId());
                                mContext.startActivity(i);
                                mListView.setItemChecked(position, false);
                            }

                        }
                    }
                });


                rowView.setOnLongClickListener(new AdapterView.OnLongClickListener() {

                    @Override
                    public boolean onLongClick(View v) {

                        //on longclick actionmode should be triggered
                        if (mActionMode != null) {
                            return false;
                        }

                        mListView.clearChoices();
                        mListView.setItemChecked(position, true);

                        mAdapter.notifyDataSetChanged();

                        mActionMode = ((AppCompatActivity) (getActivity())).startSupportActionMode(new android.support.v7.view.ActionMode.Callback() {

                            @Override
                            public boolean onCreateActionMode(android.support.v7.view.ActionMode mode, Menu menu) {
                                MenuInflater inflater = mode.getMenuInflater();
                                inflater.inflate(R.menu.menu_toolbar_decklist, menu);

                                return true;
                            }

                            @Override
                            @TargetApi(Build.VERSION_CODES.LOLLIPOP)
                            public boolean onPrepareActionMode(android.support.v7.view.ActionMode mode, Menu menu) {

                                actionMode = true;

                                if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                                    getActivity().getWindow().setStatusBarColor(ContextCompat.getColor(getContext(), R.color.dark_status_bar));
                                }

                                mode.setTitle(1 + mContext.getString(R.string.selected));

                                MenuItem editItem = menu.findItem(R.id.menu_edit);
                                editItem.setEnabled(true);
                                editItem.getIcon().setAlpha(255);

                                MenuItem flashcardItem = menu.findItem(R.id.menu_flashcards);
                                flashcardItem.setEnabled(true);
                                flashcardItem.getIcon().setAlpha(255);

                                return true;
                            }

                            @Override
                            public boolean onActionItemClicked(android.support.v7.view.ActionMode mode, MenuItem item) {

                                // if item is disabled, do nothing
                                if (!item.isEnabled()) return false;

                                switch (item.getItemId()) {
                                    case R.id.menu_delete:
                                        deleteDeck();
                                        return true;
                                    case R.id.menu_edit:
                                        editDeck(mDecks.get(position));
                                        return true;
                                    case R.id.menu_flashcards:
                                        Intent i = new Intent(mContext, FlashcardListActivity.class);
                                        i.putExtra("deck", mDecks.get(position).getId());
                                        mContext.startActivity(i);
                                        return true;
                                    default:
                                        return false;
                                }
                            }

                            @Override
                            public void onDestroyActionMode(android.support.v7.view.ActionMode mode) {

                                if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                                    getActivity().getWindow().setStatusBarColor(getResources().getColor(R.color.dark_primary_color));
                                }

                                mActionMode = null;
                                actionMode = false;
                                mListView.clearChoices();
                                mListView.invalidateViews();

                                if (mHasTwoPanes) {
                                    if (position < mDecks.size()) {
                                        mListView.setItemChecked(position, true);
                                        showDetailFragment(position);
                                    } else {
                                        mListView.setItemChecked(0, true);
                                        showDetailFragment(0);
                                    }

                                }
                            }


                        });

                        //tell android system we handled onlonglick
                        return true;
                    }
                });


                return rowView;

            }


        };

        filter = mAdapter.getFilter();

        mListView.setAdapter(mAdapter);
        mListView.setTextFilterEnabled(false);

        ButtonFloat buttonAdd = (ButtonFloat) rootView.findViewById(R.id.button_add_deck);
        buttonAdd.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                EditDeckDialog dialog = new EditDeckDialog();
                dialog.show(getFragmentManager(), "NoticeDialogFragment");
                dialog.setOnDialogClickedListener(new EditDeckDialog.OnDialogClickedListener() {
                    @Override
                    public void onDialogClicked() {
                        mAdapter.clear();
                        mAdapter.addAll(AppFactory.get(getActivity()).getDeckDAO().findAll());

                        if (mHasTwoPanes) {
                            mListView.setItemChecked(0, true);
                            showDetailFragment(0);
                        }

                        getActivity().invalidateOptionsMenu();
                    }
                });
            }
        });

        IntentFilter filter = new IntentFilter();
        filter.addAction("usg.lernkarten.FLASHCARDS_UPDATED");

        updateReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                mDecks.clear();
                mDecks.addAll(deckDAO.findAll());
                mAdapter.notifyDataSetChanged();
            }
        };

        getActivity().registerReceiver(updateReceiver, filter);

    }

    @Override
    public void onDestroy() {
        if(updateReceiver != null) {
            getActivity().unregisterReceiver(updateReceiver);
        }
        super.onDestroy();
    }

    @Override
    public void onResume() {
        super.onResume();
        ((MainActivity) getActivity()).registerSearchHandler(this);

        if (mHasTwoPanes) {
            showDetailFragment(-1);
        }
    }


    /**
     * Deletes checked decks in ListView. An alert dialog is displayed to warn the user.
     */
    private void deleteDeck() {
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());

        builder.setMessage(R.string.deck_delete_deck_title)
                .setTitle(R.string.delete_title)


                .setPositiveButton(R.string.ok, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int id) {
                        List<Deck> checkedDecks = new ArrayList<>();

                        for (int i = mAdapter.getCount() - 1; i >= 0; i--) {
                            if (mListView.isItemChecked(i)) {
                                Deck d = mAdapter.getItem(i);
                                checkedDecks.add(d);
                                Log.d("DECK", "remove");
                                mDecks.remove(d);
                            }
                        }

                        for (Deck d : checkedDecks) {
                            AppFactory.get(getActivity()).getDeckDAO().delete(d);
                        }

                        mListView.setItemChecked(0, true);
                        mAdapter.notifyDataSetChanged();

                        getActivity().invalidateOptionsMenu();
                        mActionMode.finish();

                        if (mHasTwoPanes) showDetailFragment(0);
                    }
                })

                .setNegativeButton(R.string.cancel, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int id) {
                        mActionMode.finish();
                    }
                });

        builder.create().show();

    }

    /**
     * Opens EditDeck-Dialog
     *
     * @param deck The deck that should be edited.
     */
    private void editDeck(Deck deck) {
        Deck checkedDeck = deck;

        if (mHasTwoPanes) {
            int pos = mListView.getCheckedItemPosition();
            if (pos == ListView.INVALID_POSITION) {
                pos = 0;
            }
            checkedDeck = mDecks.get(pos);
        }

        //put current deck in bundle, so that NewDialog is able to determine it
        Bundle bundle = new Bundle();
        bundle.putInt("id", checkedDeck.getId());
        bundle.putString("name", checkedDeck.getName());
        bundle.putString("description", checkedDeck.getDescription());

        EditDeckDialog dialog = new EditDeckDialog();
        dialog.setArguments(bundle);
        dialog.setTargetFragment(this, 0);
        dialog.show(getFragmentManager(), "NoticeDialogFragment");
        dialog.setOnDialogClickedListener(new EditDeckDialog.OnDialogClickedListener() {
            @Override
            public void onDialogClicked() {
                mActionMode.finish();
                mAdapter.clear();
                mAdapter.addAll(AppFactory.get(getActivity()).getDeckDAO().findAll());
            }
        });

    }

    /**
     * Shows the Detail View of the selected Deck in tablet mode.
     */
    private void showDetailFragment(int position) {
        FragmentManager fragmentManager = getChildFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        Fragment flashcardListFragment = new FlashcardListFragment();

        int pos = 0;

        if (mDecks.size() > 0) {

            if(position == ListView.INVALID_POSITION) {

                for (int i = mAdapter.getCount() - 1; i >= 0; i--) {
                    if (mListView.isItemChecked(i)) {
                        pos = i;
                    }
                }

                if (pos == 0 && !mListView.isItemChecked(0)) {
                    mListView.setItemChecked(0, true);
                }

            } else {
                pos = position;
            }

            int id = mDecks.get(pos).getId();

            Bundle bundle = new Bundle();
            bundle.putInt("deck", id);
            flashcardListFragment.setArguments(bundle);
            fragmentTransaction.replace(R.id.fragment_container, flashcardListFragment);
            fragmentTransaction.commit();
        } else {
            fragmentTransaction.replace(R.id.fragment_container, new EmptyFlashcardsFragment());
            fragmentTransaction.commit();
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        super.onCreateView(inflater, container, savedInstanceState);

        rootView = inflater.inflate(R.layout.deck_list_view, container, false);
        mListView = (ListView) rootView.findViewById(R.id.deck_listview);
        mFragmentContainer = (FrameLayout) rootView.findViewById(R.id.fragment_container);

        return rootView;
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        super.onCreateOptionsMenu(menu, inflater);
        if (mHasTwoPanes && !((MainActivity) getActivity()).isDrawerOpen() && mDecks.size() > 0)
            inflater.inflate(R.menu.menu_decklist, menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.edit_deck:
                editDeck(null);
                return true;
            case R.id.delete_deck:
                deleteDeck();
                return true;
            case R.id.play:
                Intent i = new Intent(mContext, FlashcardLearnActivity.class);
                i.putExtra("deck", mDecks.get(mListView.getCheckedItemPosition()).getId());
                mContext.startActivity(i);
                return true;
        }
        return false;
    }

    @Override
    public boolean onQueryTextSubmit(String query) {
        return false;
    }

    @Override
    public boolean onQueryTextChange(String newText) {
        //Called on every text change in search input to filter the decks
        if (mListView != null) {
            filter.filter(newText);
        }

        return true;
    }
}
