/**
 * Musterprojekt Softwaretechnik
 * Copyright (c) 2015 by Institut für SoftwareArchitektur, TH Mittelhessen.
 * Lizenz Creative Commons CC BY-NC-SA 3.0
 *
 */
package usg.lernkarten.util;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.JsonReader;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import usg.lernkarten.data.Answer;
import usg.lernkarten.data.Deck;
import usg.lernkarten.data.Flashcard;
import usg.lernkarten.data.Picture;
import usg.lernkarten.data.dao.AnswerDAO;
import usg.lernkarten.data.dao.AppFactory;
import usg.lernkarten.data.dao.DeckDAO;
import usg.lernkarten.data.dao.FlashcardDAO;
import usg.lernkarten.data.dao.PictureDAO;

/**
 * This class offers methods to import json-data.
 *
 */
public class ImportUtil {

    private static ImportUtil iu;
    private Context context;

    //not intended for instantiation - singleton.
    private ImportUtil() {
    }

    /**
     * Returns the instance of this class.
     *
     * @param ctx   Context
     *
     * @return
     */
    public static ImportUtil get(Context ctx) {
        if(iu == null) {
            iu = new ImportUtil();
            iu.context = ctx.getApplicationContext();
        }

        return iu;
    }

    /**
     * Reads the json-stream.
     *
     * @param in    Inputstream that contains the json-data.
     *
     * @return  List of the decks in json-data.
     * @throws IOException
     */
    public List<Deck> readJsonStream(InputStream in) throws IOException {
        try (JsonReader reader = new JsonReader(new InputStreamReader(in, "UTF-8"))) {
            return readDecksArray(reader);
        }
    }

    /**
     * Returns the List of decks read in the json-data.
     *
     * @param reader
     * @return  list of decks
     * @throws IOException
     */
    private List<Deck> readDecksArray(JsonReader reader) throws IOException {
        List<Deck> decks = new ArrayList<>();

        reader.beginArray();
        while (reader.hasNext()) {
            decks.add(readDeck(reader));
        }
        reader.endArray();
        return decks;
    }

    private Deck readDeck(JsonReader reader) throws IOException {
        Picture image = null;
        String title = null;
        String description = null;
        DeckDAO deckDAO = AppFactory.get(context).getDeckDAO();
        FlashcardDAO flashcardDAO = AppFactory.get(context).getFlashcardDAO();
        AnswerDAO answerDAO = AppFactory.get(context).getAnswerDAO();

        HashMap<Flashcard, List<Answer>> cardMap = new HashMap<>();
        reader.beginObject();
        while (reader.hasNext()) {
            String name = reader.nextName();
            switch (name) {
                case "image":
                    image = readPicture(reader);
                    break;
                case "title":
                    title = reader.nextString();
                    break;
                case "description":
                    description = reader.nextString();
                    break;
                case "flashcards":
                    readFlashcardList(reader, cardMap);
                    break;
            }
        }
        reader.endObject();

        Deck deck = deckDAO.findByName(title);
        if (deck == null) {
            deck = new Deck();
            deck.setPicture(image);
            deck.setDescription(description);
            deck.setName(title);
            deckDAO.persist(deck);
        } else {
            deck.setPicture(image);
            deck.setDescription(description);
            deck.setName(title);
            deckDAO.update(deck);
        }
        for (Map.Entry<Flashcard, List<Answer>> entry : cardMap.entrySet()) {
            Flashcard key = entry.getKey();
            List<Answer> value = entry.getValue();
            key.setDeck(deck);
            flashcardDAO.persist(key);
            for (Answer a : value) {
                a.setFlashcard(key);
                answerDAO.persist(a);
            }
        }
        return deck;
    }

    private List<Flashcard> readFlashcardList(JsonReader reader, HashMap<Flashcard, List<Answer>> cardMap) throws IOException {
        List<Flashcard> flashcards = new ArrayList<>();

        reader.beginArray();
        while (reader.hasNext()) {
            flashcards.add(readFlashcard(reader, cardMap));
        }
        reader.endArray();
        return flashcards;
    }

    private Flashcard readFlashcard(JsonReader reader, HashMap<Flashcard, List<Answer>> cardMap) throws IOException {
        Flashcard card = new Flashcard();
        String question = null;
        List<Answer> answers = null;
        List<Picture> images = null;
        reader.beginObject();
        while (reader.hasNext()) {
            switch (reader.nextName()) {
                case "question":
                    question = reader.nextString();
                    break;
                case "images":
                    images = readPictureList(reader);
                    break;
                case "answers":
                    answers = readAnswerList(reader);
                    break;
            }
        }
        reader.endObject();
        card.setQuestion(question);
        card.setPictures(images);
        for (Answer a : answers) {
            a.setFlashcard(card);
        }
        cardMap.put(card, answers);
        return card;
    }

    private List<Answer> readAnswerList(JsonReader reader) throws IOException {
        List<Answer> answers = new ArrayList<>();

        reader.beginArray();
        while (reader.hasNext()) {
            answers.add(readAnswer(reader));
        }
        reader.endArray();
        return answers;
    }

    private Answer readAnswer(JsonReader reader) throws IOException {
        Answer answerObject = new Answer();
        String answer = null;
        boolean answerCorrect = false;
        List<Picture> images = null;

        reader.beginObject();
        while (reader.hasNext()) {
            switch (reader.nextName()) {
                case "answer":
                    answer = reader.nextString();
                    break;
                case "answerCorrect":
                    answerCorrect = reader.nextBoolean();
                    break;
                case "images":
                    images = readPictureList(reader);
                    break;
            }
        }
        reader.endObject();
        answerObject.setAnswer(answer);
        answerObject.setAnswerCorrect(answerCorrect);
        answerObject.setPictures(images);
        return answerObject;
    }

    private List<Picture> readPictureList(JsonReader reader) throws IOException {
        List<Picture> pics = new ArrayList<>();

        reader.beginArray();
        while (reader.hasNext()) {
            pics.add(readPicture(reader));
        }
        reader.endArray();
        return pics;
    }

    private Picture readPicture(JsonReader reader) throws IOException {
        String name = null;
        String imagePath = null;
        Picture image;

        reader.beginObject();
        while (reader.hasNext()) {
            switch (reader.nextName()) {
                case "name":
                    name = reader.nextString();
                    break;
                case "data":
                    imagePath = reader.nextString();
                    break;
                default:
                    break;
            }
        }
        reader.endObject();
        image = this.getBitmapFromURL(imagePath, name);
        return image;
    }

    private Picture getBitmapFromURL(String src, String name) {
        try {
            URL url = new URL(src);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setDoInput(true);
            connection.connect();
            InputStream input = connection.getInputStream();
            Bitmap myBitmap = BitmapFactory.decodeStream(input);
            Picture pic = new Picture();
            pic.setName(name);
            pic.setSize(String.valueOf(connection.getContentLength()));
            pic.setMimeType(connection.getContentType());
            PictureDAO pictureDAO = AppFactory.get(context).getPictureDAO();
            pictureDAO.persist(pic);
            PictureUtil.savePictureToInternalStorage(context, myBitmap, pic);
            pictureDAO.update(pic);
            return pic;
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }
}
