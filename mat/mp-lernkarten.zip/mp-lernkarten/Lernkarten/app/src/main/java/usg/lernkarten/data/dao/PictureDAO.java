/**
 * Musterprojekt Softwaretechnik
 * Copyright (c) 2015 by Institut für SoftwareArchitektur, TH Mittelhessen.
 * Lizenz Creative Commons CC BY-NC-SA 3.0
 *
 */
package usg.lernkarten.data.dao;


import java.util.List;

import usg.lernkarten.data.Answer;
import usg.lernkarten.data.Flashcard;
import usg.lernkarten.data.Picture;

public interface PictureDAO {

    /**
     * Returns all pictures in db.
     *
     * @return List of all pictures
     */
    List<Picture> findAll();

    /**
     * Returns all pictures for the given flashcard
     *
     * @param flashcard
     * @return all pictures for the given flashcard
     */
    List<Picture> findAllByFlashcard(Flashcard flashcard);

    /**
     * returns all pictures for the given answer
     *
     * @param answer
     * @return all pictures for the given answer
     */
    List<Picture> findAllByAnswer(Answer answer);

    /**
     * Finds the picture by the given id
     *
     * @param id
     * @return picture with that id, if there is none null
     */
    Picture findById(Integer id);

    /**
     * Persists the given entity
     *
     * @param picture
     * @return id of the persisted entity
     */
    Long persist(Picture picture);

    /**
     * Updates the given entity
     *
     * @param picture
     */
    void update(Picture picture);

    /**
     * Deletes the given entity
     *
     * @param picture
     */
    void delete(Picture picture);

}
