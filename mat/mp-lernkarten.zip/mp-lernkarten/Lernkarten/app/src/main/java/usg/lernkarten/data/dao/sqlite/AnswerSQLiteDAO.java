/**
 * Musterprojekt Softwaretechnik
 * Copyright (c) 2015 by Institut für SoftwareArchitektur, TH Mittelhessen.
 * Lizenz Creative Commons CC BY-NC-SA 3.0
 */
package usg.lernkarten.data.dao.sqlite;

import static usg.lernkarten.data.db.AnswerDB.*;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;
import java.util.List;

import usg.lernkarten.data.Answer;
import usg.lernkarten.data.Flashcard;
import usg.lernkarten.data.Picture;
import usg.lernkarten.data.dao.AnswerDAO;
import usg.lernkarten.data.db.AnswerDB;
import usg.lernkarten.data.db.AnswerPictureDB;
import usg.lernkarten.data.db.util.MySQLiteOpenHelper;

/**
 * Concrete Data-Access Class to access the data from a SQLite-DB
 */
public class AnswerSQLiteDAO implements AnswerDAO {

    private final MySQLiteOpenHelper mySQLiteOpenHelper;
    private final Context context;

    public AnswerSQLiteDAO(Context ctx) {
        this.context = ctx;
        mySQLiteOpenHelper = new MySQLiteOpenHelper(ctx);
    }

    @Override
    public List<Answer> findAll() {
        List<Answer> result = new ArrayList<>();

        SQLiteDatabase db = mySQLiteOpenHelper.getReadableDatabase();
        String[] projection = {ID, ANSWER_ANSWER, ANSWER_CORRECT, ANSWER_FLASHCARD_ID};

        Cursor c = db.query(TABLE_NAME, projection, null, null, null, null, null);

        while (c.moveToNext()) {
            Answer a = new Answer();
            a.setId(c.getInt(0));
            a.setAnswer(c.getString(1));
            a.setAnswerCorrect(c.getInt(2) > 0);
            a.setFlashcard(new FlashcardSQLiteDAO(context).findById(c.getInt(3)));
            a.setPictures(new PictureSQLiteDAO(context).findAllByAnswer(a));
            result.add(a);
        }

        c.close();
        db.close();

        return result;
    }

    @Override
    public List<Answer> findAllByFlashcard(Flashcard flashcard) {
        List<Answer> result = new ArrayList<>();

        SQLiteDatabase db = mySQLiteOpenHelper.getReadableDatabase();
        String[] projection = {ID, ANSWER_ANSWER, ANSWER_CORRECT, ANSWER_FLASHCARD_ID};

        Cursor c = db.query(TABLE_NAME, projection, ANSWER_FLASHCARD_ID + "=" + flashcard.getId(), null, null, null, null);

        while (c.moveToNext()) {
            Answer a = new Answer();
            a.setId(c.getInt(0));
            a.setAnswer(c.getString(1));
            a.setAnswerCorrect(c.getInt(2) > 0);
            a.setFlashcard(new FlashcardSQLiteDAO(context).findById(c.getInt(3)));
            a.setPictures(new PictureSQLiteDAO(context).findAllByAnswer(a));
            result.add(a);
        }

        c.close();
        db.close();

        return result;
    }

    @Override
    public Answer findById(Integer id) {
        Answer a = null;
        SQLiteDatabase db = mySQLiteOpenHelper.getReadableDatabase();
        String[] projection = {ID, ANSWER_ANSWER, ANSWER_CORRECT, ANSWER_FLASHCARD_ID};

        Cursor c = db.query(TABLE_NAME, projection, ID + "=" + id, null, null, null, null);

        if (c.moveToNext()) {
            a = new Answer();
            a.setId(c.getInt(0));
            a.setAnswer(c.getString(1));
            a.setAnswerCorrect(c.getInt(2) > 0);
            a.setFlashcard(new FlashcardSQLiteDAO(context).findById(c.getInt(3)));
            a.setPictures(new PictureSQLiteDAO(context).findAllByAnswer(a));
        }

        c.close();
        db.close();

        return a;
    }

    @Override
    public Long persist(Answer answer) {
        SQLiteDatabase db = mySQLiteOpenHelper.getWritableDatabase();
        ContentValues cv = AnswerDB.createContentValue(answer);
        long id = db.insert(TABLE_NAME, null, cv);

        for (Picture p : answer.getPictures()) {
            cv = AnswerPictureDB.createContentValue(answer, p);
            db.insert(AnswerPictureDB.TABLE_NAME, null, cv);
        }

        answer.setId((int) id);
        db.close();
        return id;
    }

    @Override
    public void update(Answer answer) {
        SQLiteDatabase db = mySQLiteOpenHelper.getWritableDatabase();
        ContentValues cv = AnswerDB.createContentValue(answer);
        String[] whereArgs = {"" + answer.getId()};
        db.update(TABLE_NAME, cv, ID + "=?", whereArgs);

        db.delete(AnswerPictureDB.TABLE_NAME, AnswerPictureDB.ANSWERPICTURE_ANSWER_ID + "=?", whereArgs);
        for (Picture p : answer.getPictures()) {
            cv = AnswerPictureDB.createContentValue(answer, p);
            db.insert(AnswerPictureDB.TABLE_NAME, null, cv);
        }

        db.close();
    }

    @Override
    public void delete(Answer answer) {
        SQLiteDatabase db = mySQLiteOpenHelper.getWritableDatabase();
        String[] whereArgs = {"" + answer.getId()};
        db.delete(TABLE_NAME, ID + "=?", whereArgs);

        db.close();
    }
}
