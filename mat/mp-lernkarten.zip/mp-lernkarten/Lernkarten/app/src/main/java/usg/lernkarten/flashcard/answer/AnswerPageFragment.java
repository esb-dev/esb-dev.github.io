/**
 * Musterprojekt Softwaretechnik
 * Copyright (c) 2015 by Institut für SoftwareArchitektur, TH Mittelhessen.
 * Lizenz Creative Commons CC BY-NC-SA 3.0
 *
 */
package usg.lernkarten.flashcard.answer;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import java.util.List;

import usg.lernkarten.R;
import usg.lernkarten.data.Answer;
import usg.lernkarten.data.Deck;
import usg.lernkarten.data.Flashcard;
import usg.lernkarten.data.Picture;
import usg.lernkarten.data.dao.AnswerDAO;
import usg.lernkarten.data.dao.AppFactory;
import usg.lernkarten.data.dao.PictureDAO;
import usg.lernkarten.flashcard.EditFlashcardActivity;
import usg.lernkarten.flashcard.PictureListAdapter;
import usg.lernkarten.util.DialogUtil;
import usg.lernkarten.util.PictureUtil;

/**
 *  This class represents one Answer which is added to the AnswerPager.
 */
public class AnswerPageFragment extends Fragment {

    private Fragment fragment;

    private AnswerDAO answerDAO;

    private Answer answer;
    private Deck deck;
    private Flashcard flashcard;

    private EditText title;
    private CheckBox mAnswerCorrect;

    private ArrayAdapter<Picture> mAdapter;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        final View rootView = inflater.inflate(R.layout.answer_page_fragment, container, false);
        getActivity().setTitle(R.string.edit);

        fragment = this;

        setHasOptionsMenu(true);
        answerDAO = AppFactory.get(this.getActivity()).getAnswerDAO();

        Toolbar cardToolbar = (Toolbar) rootView.findViewById(R.id.card_toolbar);
        cardToolbar.setTitle(getString(R.string.flashcard_back_title));
        if (cardToolbar != null) {
            cardToolbar.inflateMenu(R.menu.menu_edit_answer_card);
            cardToolbar.setOnMenuItemClickListener(new Toolbar.OnMenuItemClickListener() {
                @Override
                public boolean onMenuItemClick(MenuItem menuItem) {
                    switch (menuItem.getItemId()) {
                        case R.id.flashcard_add_picture:
                            DialogUtil.showPhotoDialog(fragment);
                            return true;
                        case R.id.flashcard_delete_answer:
                            showAnswerDeleteDialog();
                            return true;
                    }
                    return true;
                }
            });
        }

        Bundle args = getArguments();

        answer = (Answer) args.getSerializable("answer");
        flashcard = answer.getFlashcard();
        deck = flashcard.getDeck();

        ListView mListView = (ListView) rootView.findViewById(R.id.answerPictureListView);
        List<Picture> pictureList = answer.getPictures();
        mAdapter = new PictureListAdapter(getActivity(), pictureList);

        mListView.setAdapter(mAdapter);

        title = (EditText) rootView.findViewById(R.id.flashcard_question);
        title.setText(answer.getAnswer());

        mAnswerCorrect = (CheckBox) rootView.findViewById(R.id.checkBoxAnswerCorrect);
        mAnswerCorrect.setChecked(answer.getAnswerCorrect());

        return rootView;
    }


    /**
     *  Shows a dialog to delete the current Answer.
     *
     */
    private void showAnswerDeleteDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(fragment.getActivity());
        builder.setMessage(R.string.answer_delete_answer_message).setTitle(R.string.delete_title);

        builder.setPositiveButton(R.string.ok, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                ((EditAnswerActivity) getActivity()).removeAnswer(answer);
                AppFactory.get(getActivity()).getAnswerDAO().delete(answer);
            }
        });

        builder.setNegativeButton(R.string.cancel, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                //Nothing to do
            }
        });

        AlertDialog dialog = builder.create();
        dialog.show();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        Intent intent;

        switch (item.getItemId()) {
            case R.id.action_edit_flashcard_save:

                //save changes
                if(title.getText().length() < 1) {
                    title.setError(getString(R.string.form_edit_text_not_empty));
                    return false;
                }

                answer.setAnswer(title.getText().toString());
                answer.setAnswerCorrect(mAnswerCorrect.isChecked());

                if(answer.getId() == null || answer.getId() < 0) {
                    answerDAO.persist(answer);
                } else {
                    answerDAO.update(answer);
                }

                DialogUtil.showAnswerDialog(fragment.getActivity(), deck, flashcard);

                return true;

            case android.R.id.home:

                //discard changes
                intent = new Intent(fragment.getActivity(), EditFlashcardActivity.class);
                intent.putExtra("deck", deck.getId());
                intent.putExtra("flashcard", flashcard.getId());
                startActivity(intent);

                fragment.getActivity().finish();

                return true;

        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        switch (requestCode){
            case PictureUtil.CAPTURE_CAMERA_ACTIVITY_REQUEST_CODE:
                if (resultCode == Activity.RESULT_OK) {
                    try {
                        Bundle extras = data.getExtras();
                        Bitmap image = (Bitmap) extras.get("data");
                        Picture picture = new Picture();
                        picture.setName(getString(R.string.picture_photo_camera));

                        savePicture(image, picture);
                    }catch (Exception e){
                        Toast.makeText(getActivity().getApplicationContext(), getString(R.string.picture_take_picture_camera_error),
                                Toast.LENGTH_LONG).show();
                    }
                }
                break;
            case PictureUtil.CAPTURE_GALLERY_ACTIVITY_REQUEST_CODE:
                Log.d("CAPTURE GALLERY Y", "");
                if (resultCode == Activity.RESULT_OK) {
                    Log.d("CAPTURE GALLERYTY", "RESULT OK");
                    Uri selectedImage = data.getData();
                    Picture picture = new Picture();
                    Bitmap image = PictureUtil.getBitmapFromDataURI(getActivity(), selectedImage, picture);

                    savePicture(image, picture);
                }
                break;
            default:
                //do nothing
        }
    }

    /**
     * Saves the current image / picture to the current answer.
     *
     * @param image     Image to be saved.
     * @param picture   Picture to be saved.
     *
     */
    private void savePicture(Bitmap image, Picture picture) {

        PictureDAO pictureDAO = AppFactory.get(getActivity()).getPictureDAO();

        pictureDAO.persist(picture);

        PictureUtil.savePictureToInternalStorage(getActivity(), image, picture);
        pictureDAO.update(picture);

        answer.addPicture(picture);

        mAdapter.notifyDataSetChanged();
    }

    /**
     * Returns the answer of this page.
     *
     * @return  Answer of this page.
     */
    public Answer getAnswer() {
        return this.answer;
    }
}