/**
 * Musterprojekt Softwaretechnik
 * Copyright (c) 2015 by Institut für SoftwareArchitektur, TH Mittelhessen.
 * Lizenz Creative Commons CC BY-NC-SA 3.0
 *
 */
package usg.lernkarten.data.db;

import android.content.ContentValues;

import usg.lernkarten.data.Deck;

/**
 * Class that contains constants and helper-methods for the deck table.
 */
public final class DeckDB {

    public static final String TABLE_NAME = "deck";

    public static final String ID = "_id";
    public static final String DECK_NAME = "name";
    public static final String DECK_DESCRIPTION = "description";
    public static final String DECK_PICTURE_ID = "picture_id";

    /**
     * Not intended for instantiation.
     */
    private DeckDB() {
    }

    public static ContentValues createContentValue(Deck deck) {
        ContentValues cv = new ContentValues();

        cv.put(DECK_NAME, deck.getName());
        cv.put(DECK_DESCRIPTION, deck.getDescription());
        cv.put(DECK_PICTURE_ID, deck.getPicture().getId());

        return cv;
    }
}
