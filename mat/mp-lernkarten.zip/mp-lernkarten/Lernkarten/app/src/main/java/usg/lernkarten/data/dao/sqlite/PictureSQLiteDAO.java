/**
 * Musterprojekt Softwaretechnik
 * Copyright (c) 2015 by Institut für SoftwareArchitektur, TH Mittelhessen.
 * Lizenz Creative Commons CC BY-NC-SA 3.0
 *
 */
package usg.lernkarten.data.dao.sqlite;

import static usg.lernkarten.data.db.PictureDB.*;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;
import java.util.List;

import usg.lernkarten.data.Answer;
import usg.lernkarten.data.Flashcard;
import usg.lernkarten.data.Picture;
import usg.lernkarten.data.dao.PictureDAO;
import usg.lernkarten.data.db.util.MySQLiteOpenHelper;
import usg.lernkarten.data.db.PictureDB;

/**
 * Concrete Data-Access Class to access the data from a SQLite-DB
 */
public class PictureSQLiteDAO implements PictureDAO {

    private final MySQLiteOpenHelper mySQLiteOpenHelper;

    public PictureSQLiteDAO(Context ctx) {
        mySQLiteOpenHelper = new MySQLiteOpenHelper(ctx);
    }

    @Override
    public List<Picture> findAll() {
        List<Picture> result = new ArrayList<>();

        SQLiteDatabase db = mySQLiteOpenHelper.getReadableDatabase();
        String[] projection = {ID, PICTURE_NAME, PICTURE_MIME_TYPE, PICTURE_SIZE};

        Cursor c = db.query(TABLE_NAME, projection, null, null, null, null, null);

        while(c.moveToNext()) {
            Picture p = new Picture();
            p.setId(c.getInt(0));
            p.setName(c.getString(1));
            p.setMimeType(c.getString(2));
            p.setSize(c.getString(3));

            result.add(p);
        }

        c.close();
        db.close();

        return result;
    }

    @Override
    public List<Picture> findAllByFlashcard(Flashcard flashcard) {
        List<Picture> result = new ArrayList<>();

        SQLiteDatabase db = mySQLiteOpenHelper.getReadableDatabase();
        final String query = "SELECT p._id, p.name, p.mime_type, p.size FROM picture p, flashcard_picture fp WHERE p._id = fp.picture_id AND fp.flashcard_id=?;";
        Cursor c = db.rawQuery(query, new String[]{String.valueOf(flashcard.getId())});

        while(c.moveToNext()) {
            Picture p = new Picture();
            p.setId(c.getInt(0));
            p.setName(c.getString(1));
            p.setMimeType(c.getString(2));
            p.setSize(c.getString(3));

            result.add(p);
        }

        c.close();
        db.close();

        return result;
    }

    @Override
    public List<Picture> findAllByAnswer(Answer answer) {
        List<Picture> result = new ArrayList<>();

        SQLiteDatabase db = mySQLiteOpenHelper.getReadableDatabase();
        final String query = "SELECT p._id, p.name, p.mime_type, p.size FROM picture p, answer_picture ap WHERE p._id = ap.picture_id AND ap.answer_id=?;";
        Cursor c = db.rawQuery(query, new String[]{String.valueOf(answer.getId())});

        while(c.moveToNext()) {
            Picture p = new Picture();
            p.setId(c.getInt(0));
            p.setName(c.getString(1));
            p.setMimeType(c.getString(2));
            p.setSize(c.getString(3));

            result.add(p);
        }

        c.close();
        db.close();

        return result;
    }


    @Override
    public Picture findById(Integer id) {
        Picture p = null;

        SQLiteDatabase db = mySQLiteOpenHelper.getReadableDatabase();
        String[] projection = {ID, PICTURE_NAME, PICTURE_MIME_TYPE, PICTURE_SIZE};

        Cursor c = db.query(TABLE_NAME, projection, ID + "=" + id, null, null, null, null);

        while(c.moveToNext()) {
            p = new Picture();
            p.setId(c.getInt(0));
            p.setName(c.getString(1));
            p.setMimeType(c.getString(2));
            p.setSize(c.getString(3));
        }

        c.close();
        db.close();

        return p;
    }

    @Override
    public Long persist(Picture picture) {
        SQLiteDatabase db = mySQLiteOpenHelper.getWritableDatabase();
        ContentValues cv = PictureDB.createContentValue(picture);
        long id = db.insert(TABLE_NAME, null, cv);

        picture.setId((int) id);

        db.close();
        return id;
    }

    @Override
    public void update(Picture picture) {
        SQLiteDatabase db = mySQLiteOpenHelper.getWritableDatabase();
        ContentValues cv = PictureDB.createContentValue(picture);
        String[] whereArgs = { "" + picture.getId() };
        db.update(TABLE_NAME, cv, ID + "=?", whereArgs);

        db.close();
    }

    @Override
    public void delete(Picture picture) {
        SQLiteDatabase db = mySQLiteOpenHelper.getWritableDatabase();
        String[] whereArgs = { "" + picture.getId() };
        db.delete(TABLE_NAME, ID + "=?", whereArgs);

        db.close();
    }

}
