/**
 * Musterprojekt Softwaretechnik
 * Copyright (c) 2015 by Institut für SoftwareArchitektur, TH Mittelhessen.
 * Lizenz Creative Commons CC BY-NC-SA 3.0
 */
package usg.lernkarten.flashcard;

import android.annotation.TargetApi;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Build;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.PopupMenu;
import android.util.Log;
import android.util.SparseBooleanArray;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.support.v7.view.ActionMode;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import usg.lernkarten.R;
import usg.lernkarten.data.Deck;
import usg.lernkarten.data.Flashcard;
import usg.lernkarten.data.Picture;
import usg.lernkarten.data.dao.AppFactory;
import usg.lernkarten.util.PictureUtil;

/**
 * This class provides a custom ArrayAdapter to show Flashcards in a ListView.
 */
class FlashcardListAdapter extends ArrayAdapter<Flashcard> {

    private final List<Flashcard> mFlashcards;
    private final Context context;

    private boolean actionMode;
    private ActionMode mActionMode;

    //GridView or ListView: depends on device
    private final AbsListView mListView;

    public FlashcardListAdapter(Context context, List<Flashcard> flashcards, AbsListView listView) {
        super(context, R.layout.flashcard_list_item, flashcards);
        this.context = context;
        this.mFlashcards = flashcards;
        this.mListView = listView;
        this.mListView.setChoiceMode(AbsListView.CHOICE_MODE_MULTIPLE);
    }


    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {

        View rowView = convertView;

        if (rowView == null) {
            LayoutInflater inflater = (LayoutInflater) context
                    .getSystemService(Context.LAYOUT_INFLATER_SERVICE);

            rowView = inflater.inflate(R.layout.flashcard_list_item, parent, false);
        }

        final TextView textViewTitle = (TextView) rowView.findViewById(R.id.flashcard_list_item_title);
        final TextView textViewAnswerCount = (TextView) rowView.findViewById(R.id.flashcard_list_item_answer_count);
        final TextView textViewLastVisited = (TextView) rowView.findViewById(R.id.flashcard_list_item_last_visited);
        final ImageView imageView = (ImageView) rowView.findViewById(R.id.flashcard_list_item_thumb);
        final ImageView overflow = (ImageView) rowView.findViewById(R.id.list_item_overflow);

        textViewTitle.setText(mFlashcards.get(position).getQuestion());

        int answerCount = AppFactory.get(context).getAnswerDAO().findAllByFlashcard(mFlashcards.get(position)).size();
        if (answerCount == 1) {
            textViewAnswerCount.setText(context.getString(R.string.answer_available, answerCount));
        } else {
            textViewAnswerCount.setText(context.getString(R.string.answers_available, answerCount));
        }

        Long lastPlayed = mFlashcards.get(position).getLastPlayed();
        String dateString = context.getString(R.string.new_);
        if (lastPlayed > 0) {
            Date date = new Date(lastPlayed);
            java.text.DateFormat dateFormat = android.text.format.DateFormat.getDateFormat(getContext());
            dateString = dateFormat.format(date);
        }
        textViewLastVisited.setText(dateString);

        List<Picture> pics = mFlashcards.get(position).getPictures();
        Bitmap image;
        if (!pics.isEmpty()) {
            Picture pic = pics.get(0);
            image = PictureUtil.getBitmapFromPicture(context, pic);
            if (image != null) {
                imageView.setImageBitmap(image);
            }
        } else {
            imageView.setImageBitmap(BitmapFactory.decodeResource(context.getResources(), R.drawable.flashcard));
        }

        rowView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (actionMode) {

                    //Smartphone-Mode
                    mListView.setItemChecked(position, !mListView.isItemChecked(position));
                    mActionMode.setTitle(mListView.getCheckedItemCount() + " ausgewählt");

                    if (mListView.getCheckedItemCount() == 0) {
                        mActionMode.finish();
                        return;
                    }

                    MenuItem editItem = mActionMode.getMenu().findItem(R.id.menu_edit);

                    if (mListView.getCheckedItemCount() > 1) {

                        editItem.setEnabled(false);
                        editItem.getIcon().setAlpha(130);

                    } else {

                        editItem.setEnabled(true);
                        editItem.getIcon().setAlpha(255);

                    }


                } else {

                    mListView.setItemChecked(position, true);

                    final Flashcard fc = mFlashcards.get(position);

                    Deck deck = mFlashcards.get(position).getDeck();

                    editFlashcard(fc, deck);
                }

                // On tap on flashcard show FlashcardLearnActivity

                /*
                Intent intent = new Intent(v.getContext(), FlashcardLearnActivity.class);
                intent.putExtra("deck", mFlashcards.get(position).getDeck().getId());
                intent.putExtra("flashcard", mFlashcards.get(position).getId());

                context.startActivity(intent);
                */

            }
        });

        rowView.setOnLongClickListener(new AdapterView.OnLongClickListener() {

            @Override
            public boolean onLongClick(View v) {

                if (mListView instanceof GridView) {
                    return false;
                }

                if (mActionMode != null) {
                    return false;
                }

                mListView.clearChoices();
                mListView.setItemChecked(position, true);

                notifyDataSetChanged();

                mActionMode = ((AppCompatActivity) (context)).startSupportActionMode(new android.support.v7.view.ActionMode.Callback() {

                    @Override
                    public boolean onCreateActionMode(android.support.v7.view.ActionMode mode, Menu menu) {
                        MenuInflater inflater = mode.getMenuInflater();
                        inflater.inflate(R.menu.menu_toolbar_flashcardlist, menu);

                        return true;
                    }

                    @Override
                    @TargetApi(Build.VERSION_CODES.LOLLIPOP)
                    public boolean onPrepareActionMode(android.support.v7.view.ActionMode mode, Menu menu) {

                        actionMode = true;

                        if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                            ((Activity) context).getWindow().setStatusBarColor(ContextCompat.getColor(context, R.color.dark_status_bar));
                        }

                        //mode.setTitle(mListView.getCheckedItemCount() + " ausgewählt");
                        mode.setTitle(1 + context.getString(R.string.selected));

                        MenuItem editItem = menu.findItem(R.id.menu_edit);
                        editItem.setEnabled(true);
                        editItem.getIcon().setAlpha(255);


                        return true;
                    }

                    @Override
                    public boolean onActionItemClicked(android.support.v7.view.ActionMode mode, MenuItem item) {

                        if (!item.isEnabled()) {
                            return false;
                        }

                        switch (item.getItemId()) {
                            case R.id.menu_delete:
                                deleteFlashcard();
                                return true;
                            case R.id.menu_edit:

                                SparseBooleanArray checked = mListView.getCheckedItemPositions();

                                for (int i = 0; i < mListView.getAdapter().getCount(); i++) {
                                    if (checked.get(i)) {
                                        Flashcard flashcard = mFlashcards.get(i);
                                        Deck deck = mFlashcards.get(i).getDeck();

                                        editFlashcard(flashcard, deck);
                                    }
                                }

                                return true;

                            default:
                                return false;
                        }
                    }

                    @Override
                    public void onDestroyActionMode(android.support.v7.view.ActionMode mode) {

                        if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                            ((Activity) context).getWindow().setStatusBarColor(ContextCompat.getColor(context, R.color.dark_primary_color));
                        }

                        mActionMode = null;
                        actionMode = false;
                        mListView.clearChoices();
                        mListView.invalidateViews();

                        /*
                        mListView.setChoiceMode(ListView.CHOICE_MODE_SINGLE);
                        if (position < mFlashcards.size()) {
                            mListView.setItemChecked(position, true);
                        } else {
                            mListView.setItemChecked(0, true);
                        }
                        */

                    }


                });

                return true;
            }
        });

        if (overflow != null) {
            overflow.setOnClickListener(new View.OnClickListener() {

                @Override
                public void onClick(final View v) {

                    //On tap on overflow menu show options
                    PopupMenu popup = new PopupMenu(v.getContext(), overflow);
                    popup.getMenuInflater().inflate(R.menu.overflow_menu_flashcard, popup.getMenu());

                    popup.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                        public boolean onMenuItemClick(MenuItem item) {
                            final Flashcard fc = mFlashcards.get(position);

                            switch (item.getItemId()) {
                                case R.id.overflow_edit:

                                    Deck deck = mFlashcards.get(position).getDeck();

                                    Integer flashcardID = fc.getId();
                                    Integer deckId = deck.getId();

                                    Intent intent = new Intent(v.getContext(), EditFlashcardActivity.class);
                                    intent.putExtra("deck", deckId);
                                    intent.putExtra("flashcard", flashcardID);
                                    context.startActivity(intent);

                                    break;
                                case R.id.overflow_delete:
                                    AlertDialog.Builder builder = new AlertDialog.Builder(v.getContext());
                                    builder.setMessage(R.string.flashcard_delete_flashcard_message).setTitle(R.string.delete_title);

                                    builder.setPositiveButton(R.string.ok, new DialogInterface.OnClickListener() {
                                        public void onClick(DialogInterface dialog, int id) {
                                            mFlashcards.remove(fc);
                                            AppFactory.get(v.getContext()).getFlashcardDAO().delete(fc);
                                            notifyDataSetChanged();
                                        }
                                    });

                                    builder.setNegativeButton(R.string.cancel, new DialogInterface.OnClickListener() {
                                        public void onClick(DialogInterface dialog, int id) {
                                            //nothing to do
                                        }
                                    });

                                    AlertDialog dialog = builder.create();
                                    dialog.show();

                                    break;
                            }
                            return true;
                        }
                    });

                    popup.show();

                }

            });
        }


        return rowView;
    }

    /**
     * Deletes checked decks in ListView.
     */
    private void deleteFlashcard() {
        AlertDialog.Builder builder = new AlertDialog.Builder(context);

        builder.setMessage(R.string.flashcard_delete_flashcard_message)
                .setTitle(R.string.delete_title)


                .setPositiveButton(R.string.ok, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int id) {
                        List<Flashcard> checkedFlashcards = new ArrayList<>();

                        for (int i = getCount() - 1; i >= 0; i--) {
                            if (mListView.isItemChecked(i)) {
                                Flashcard f = getItem(i);
                                checkedFlashcards.add(f);
                                mFlashcards.remove(f);
                            }
                        }

                        for (Flashcard f : checkedFlashcards) {
                            AppFactory.get(context).getFlashcardDAO().delete(f);
                        }

                        mListView.setItemChecked(0, true);
                        notifyDataSetChanged();

                        ((Activity) context).invalidateOptionsMenu();
                        mActionMode.finish();
                    }
                })

                .setNegativeButton(R.string.cancel, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int id) {

                        mActionMode.finish();
                    }
                });

        builder.create().show();

    }

    /**
     * Opens EditDeck-Dialog
     *
     * @param deck The deck that should be edited.
     */
    private void editFlashcard(Flashcard fc, Deck deck) {

        Integer flashcardID = fc.getId();
        Integer deckId = deck.getId();

        Intent intent = new Intent(context, EditFlashcardActivity.class);
        intent.putExtra("deck", deckId);
        intent.putExtra("flashcard", flashcardID);

        context.startActivity(intent);

    }

}