/**
 * Musterprojekt Softwaretechnik
 * Copyright (c) 2015 by Institut für SoftwareArchitektur, TH Mittelhessen.
 * Lizenz Creative Commons CC BY-NC-SA 3.0
 *
 */
package usg.lernkarten.flashcard;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Bitmap;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

import usg.lernkarten.R;
import usg.lernkarten.data.Picture;
import usg.lernkarten.data.dao.AppFactory;
import usg.lernkarten.util.PictureUtil;

/**
 * This class represents a custom ArrayAdapter to provide a list with pictures.
 *
 */
public class PictureListAdapter extends ArrayAdapter<Picture> {

    private final List<Picture> pictures;
    private final Context context;

    public PictureListAdapter(Context ctx, List<Picture> pictureList) {
        super(ctx, R.layout.picture_list_item, pictureList);

        this.pictures = pictureList;
        this.context = ctx;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {

        View rowView = convertView;

        if(rowView == null) {
            LayoutInflater inflater = (LayoutInflater) context
                    .getSystemService(Context.LAYOUT_INFLATER_SERVICE);

            rowView = inflater.inflate(R.layout.picture_list_item, parent, false);
        }

        TextView imageNameView = (TextView) rowView.findViewById(R.id.pictureListPictureName);
        ImageView imageView = (ImageView) rowView.findViewById(R.id.pictureListPicture);
        Bitmap image;

        if(pictures.get(position) != null){
            String imageName = String.valueOf(pictures.get(position).getName());
            image = PictureUtil.getBitmapFromPicture(imageView.getContext(), pictures.get(position));
            if(image != null){
                imageView.setImageBitmap(image);
            }
            imageNameView.setText(imageName);
        }

        ImageButton imageButton = (ImageButton) rowView.findViewById(R.id.pictureDelete);
        imageButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(final View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(v.getContext());
                builder.setMessage(R.string.picture_delete_picture_message).setTitle(R.string.delete_title);

                builder.setPositiveButton(R.string.ok, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        Picture picture = pictures.get(position);
                        pictures.remove(picture);
                        AppFactory.get(v.getContext()).getPictureDAO().delete(picture);
                        notifyDataSetChanged();
                    }
                });

                builder.setNegativeButton(R.string.cancel, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        //nothing to do
                    }
                });

                AlertDialog dialog = builder.create();
                dialog.show();
            }

        });

        return rowView;
    }

}