/**
 * Musterprojekt Softwaretechnik
 * Copyright (c) 2015 by Institut für SoftwareArchitektur, TH Mittelhessen.
 * Lizenz Creative Commons CC BY-NC-SA 3.0
 */
package usg.lernkarten.statistic;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import usg.lernkarten.util.PictureUtil;
import usg.lernkarten.R;
import usg.lernkarten.data.Flashcard;
import usg.lernkarten.data.Picture;

/**
 *  This class represents an adapter that holds a list of flashcards
 */
public class StatisticFlashcardsAdapter extends RecyclerView.Adapter<StatisticFlashcardsAdapter.ViewHolder> {

    private final List<Flashcard> flashcards;
    private Context context;

    public StatisticFlashcardsAdapter(List<Flashcard> flashcards) {
        this.flashcards = flashcards;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.statistic_flashcards_list_item, parent, false);

        context = parent.getContext();

        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {

        TextView textViewTitle = (TextView) holder.mTextView.findViewById(R.id.statistik_flashcards_list_item_title);
        TextView textLastPlayed = (TextView) holder.mTextView.findViewById(R.id.statistik_flashcards_list_item_last_played);
        TextView textNumberFalse = (TextView) holder.mTextView.findViewById(R.id.statistik_flashcards_list_item_number_false);
        TextView textNumberPlayed = (TextView) holder.mTextView.findViewById(R.id.statistik_flashcards_list_item_number_played);
        TextView textNumberRight = (TextView) holder.mTextView.findViewById(R.id.statistik_flashcards_list_item_number_right);
        TextView textLastPlayedRight = (TextView) holder.mTextView.findViewById(R.id.statistik_flashcards_list_item_last_played_right);
        ImageView imageView = (ImageView) holder.mTextView.findViewById(R.id.statistik_flashcards_list_item_thumb);

        Flashcard flashcard = flashcards.get(position);

        textViewTitle.setText(flashcard.getQuestion());
        int numberFalse = flashcard.getNumberOfWrong();
        int numberRight = flashcard.getNumberOfCorrect();
        int numberPlayed = numberFalse + numberRight;

        Date date = new Date(flashcard.getLastPlayed());
        java.text.DateFormat dateFormat = android.text.format.DateFormat.getDateFormat(context);

        String dateStringLastPlayed = dateFormat.format(date);

        date = new Date(flashcard.getLastCorrect());
        dateFormat = android.text.format.DateFormat.getDateFormat(context);

        String dateStringLastRight = dateFormat.format(date);

        textNumberFalse.setText(String.valueOf(numberFalse));
        textNumberRight.setText(String.valueOf(numberRight));
        textNumberPlayed.setText(String.valueOf(numberPlayed));

        if (flashcard.getLastPlayed() == 0) {
            textLastPlayed.setText(context.getString(R.string.never));
        } else {
            textLastPlayed.setText(dateStringLastPlayed);
        }

        if (flashcard.getLastCorrect() == 0) {
            textLastPlayedRight.setText(context.getString(R.string.never));
        } else {
            textLastPlayedRight.setText(dateStringLastRight);
        }

        Bitmap image;
        List<Picture> pictures = flashcards.get(position).getPictures();
        if (!pictures.isEmpty()) {
            Picture picture = pictures.get(0);
            image = PictureUtil.getBitmapFromPicture(context, picture);
            if (image != null) {
                imageView.setImageBitmap(image);
            }
        } else {
            imageView.setImageBitmap(BitmapFactory.decodeResource(context.getResources(), R.drawable.flashcard));
        }
    }

    @Override
    public int getItemCount() {
        return flashcards.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        public final View mTextView;

        public ViewHolder(View v) {
            super(v);
            mTextView = v;
        }
    }
}
