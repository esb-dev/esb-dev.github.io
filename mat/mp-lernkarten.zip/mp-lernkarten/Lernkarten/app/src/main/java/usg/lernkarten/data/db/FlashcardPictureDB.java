/**
 * Musterprojekt Softwaretechnik
 * Copyright (c) 2015 by Institut für SoftwareArchitektur, TH Mittelhessen.
 * Lizenz Creative Commons CC BY-NC-SA 3.0
 *
 */
package usg.lernkarten.data.db;

import android.content.ContentValues;

import usg.lernkarten.data.Flashcard;
import usg.lernkarten.data.Picture;

/**
 * Class that contains constants and helper-methods for the flashcard-picture table.
 */
public final  class FlashcardPictureDB {

    public static final String TABLE_NAME = "flashcard_picture";

    public static final String FLASHCARDPICTURE_FLASHCARD_ID = "flashcard_id";
    public static final String FLASHCARDPICTURE_PICTURE_ID = "picture_id";

    /**
     * Not intended for instantiation.
     */
    private FlashcardPictureDB() {
    }

    public static ContentValues createContentValue(Flashcard flashcard, Picture picture) {
        ContentValues cv = new ContentValues();

        cv.put(FLASHCARDPICTURE_FLASHCARD_ID, flashcard.getId());
        cv.put(FLASHCARDPICTURE_PICTURE_ID, picture.getId());

        return cv;
    }
}
