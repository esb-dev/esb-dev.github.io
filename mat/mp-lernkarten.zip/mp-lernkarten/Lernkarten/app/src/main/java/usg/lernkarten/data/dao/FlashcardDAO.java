/**
 * Musterprojekt Softwaretechnik
 * Copyright (c) 2015 by Institut für SoftwareArchitektur, TH Mittelhessen.
 * Lizenz Creative Commons CC BY-NC-SA 3.0
 *
 */
package usg.lernkarten.data.dao;

import java.util.List;

import usg.lernkarten.data.Deck;
import usg.lernkarten.data.Flashcard;

public interface FlashcardDAO {

    /**
     * Returns all flashcards in db.
     *
     * @return List of all flashcards
     */
    List<Flashcard> findAll();

    /**
     * Returns all flashcards for the given deck.
     *
     * @return List of all flashcards for the given deck
     */
    List<Flashcard> findByDeck(Deck deck);

    /**
     * Returns all flashcards for the given deck if there are answers for to this flashcard
     *
     * @param deck
     * @return List of all flashcards with answers for the given deck
     */
    List<Flashcard> findByDeckWithAnswer(Deck deck);

    /**
     * Finds the flashcard by the given id
     *
     * @param id
     * @return flashcard with that id, if there is none null
     */
    Flashcard findById(Integer id);

    /**
     * Persists the given entity
     *
     * @param flashcard
     * @return id of the persisted entity
     */
    Long persist(Flashcard flashcard);

    /**
     * Updates the given entity
     *
     * @param flashcard
     */
    void update(Flashcard flashcard);

    /**
     * Deletes the given entity
     *
     * @param flashcard
     */
    void delete(Flashcard flashcard);

}
