/**
 * Musterprojekt Softwaretechnik
 * Copyright (c) 2015 by Institut für SoftwareArchitektur, TH Mittelhessen.
 * Lizenz Creative Commons CC BY-NC-SA 3.0
 */
package usg.lernkarten.learnmode;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v7.app.ActionBar;
import android.support.v7.app.ActionBarActivity;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import usg.lernkarten.R;
import usg.lernkarten.data.Answer;
import usg.lernkarten.data.Deck;
import usg.lernkarten.data.Flashcard;
import usg.lernkarten.data.dao.AppFactory;
import usg.lernkarten.data.dao.FlashcardDAO;

/**
 * This class represents the activity to learn flashcards.
 */
public class FlashcardLearnActivity extends AppCompatActivity implements FlashcardPlayFrontFragment.FlashcardPlayFrontCallbacks, FlashcardPlayBackFragment.FlashcardPlayBackCallbacks {

    private Flashcard card;

    private List<Flashcard> cards;

    private FlashcardDAO flashcardDAO;

    private FragmentManager fragmentManager;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.flashcard_learn_activity);

        flashcardDAO = AppFactory.get(this).getFlashcardDAO();

        int deckId = getIntent().getExtras().getInt("deck");
        Deck deck = AppFactory.get(this).getDeckDAO().findById(deckId);

        cards = flashcardDAO.findByDeck(deck);

        showNextQuestion();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_show_flashcards, menu);

        restoreActionBar();

        return super.onCreateOptionsMenu(menu);
    }

    private void restoreActionBar() {
        ActionBar actionBar = getSupportActionBar();
        actionBar.setNavigationMode(ActionBar.NAVIGATION_MODE_STANDARD);
        actionBar.setDisplayShowTitleEnabled(true);
        actionBar.setDefaultDisplayHomeAsUpEnabled(true);
        actionBar.setTitle(getResources().getString(R.string.app_name));
    }

    @Override
    public void onAnswerButtonSelectedSingle(Flashcard card) {
        Bundle bundle = new Bundle();
        bundle.putSerializable("card", card);
        bundle.putBoolean("isMulti", false);

        Fragment fragment = new FlashcardPlayBackFragment();
        fragment.setArguments(bundle);
        fragmentManager = getSupportFragmentManager();
        fragmentManager.beginTransaction()
                .replace(R.id.flashcard_play_container, fragment)
                .commit();
    }

    @Override
    public void onAnswerButtonSelectedMulti(Flashcard card, List<Answer> answerList, HashMap<Integer, Boolean> resultSet) {
        Bundle bundle = new Bundle();
        bundle.putSerializable("card", card);
        bundle.putSerializable("answers", (ArrayList<Answer>) answerList);
        bundle.putSerializable("resultSet", resultSet);
        bundle.putBoolean("isMulti", true);

        Fragment fragment = new FlashcardPlayBackFragment();
        fragment.setArguments(bundle);
        fragmentManager = getSupportFragmentManager();
        fragmentManager.beginTransaction()
                .replace(R.id.flashcard_play_container, fragment)
                .commit();
    }

    @Override
    public void onEndButtonSelected() {
        finish();
    }

    @Override
    public void onKnownButtonSelected(Flashcard card) {
        flashcardDAO.update(card);
        showNextQuestion();
    }

    @Override
    public void onUnknownButtonSelected(Flashcard card) {
        flashcardDAO.update(card);
        showNextQuestion();
    }

    /**
     * Sets the next question in dependency of the settings
     */
    private void showNextQuestion() {

        if (!cards.isEmpty()) {
            //check which learnmode is selected
            SharedPreferences sharedPref = PreferenceManager.getDefaultSharedPreferences(this);

            String learnmode = sharedPref.getString("learnmode", "0");
            switch (learnmode) {
                case "0":
                    card = getRandomCard();
                    break;
                case "1":
                    card = getRandomCardWeighted();
                    break;
                default:
                    break;
            }

            FlashcardPlayFrontFragment fragment = new FlashcardPlayFrontFragment();

            Bundle bundle = new Bundle();
            bundle.putSerializable("card", card);
            fragment.setArguments(bundle);

            fragmentManager = getSupportFragmentManager();
            fragmentManager.beginTransaction()
                    .replace(R.id.flashcard_play_container, fragment)
                    .commit();

        } else {

            Toast toast = Toast.makeText(this, getString(R.string.learnmode_no_flashcards), Toast.LENGTH_SHORT);
            toast.show();
            this.finish();

        }
    }

    /**
     * Returns a random flashcard of this deck.
     *
     * @return random flashcard
     */
    private Flashcard getRandomCard() {

        if (cards.isEmpty()) {
            Toast toast = Toast.makeText(this, getString(R.string.learnmode_all_answerd), Toast.LENGTH_LONG);
            toast.show();
            this.finish();
        }

        int randomNum = (int) (Math.random() * cards.size());
        Flashcard temp = cards.get(randomNum);
        cards.remove(temp);
        return temp;
    }

    /**
     * Gets a random flashcard but includes wrong answered cards more frequently
     *
     * @return
     */
    private Flashcard getRandomCardWeighted() {
        if (cards.isEmpty()) {
            Toast toast = Toast.makeText(this, getString(R.string.learnmode_all_answerd), Toast.LENGTH_LONG);
            toast.show();
            this.finish();
        }
        Flashcard temp;
        int totalWeight = 0;
        for (Flashcard f : cards) {
            totalWeight += f.getNumberOfWrong();
        }
        int randomNum = -1;
        double random = Math.random() * totalWeight;
        for (int i = 0; i < cards.size(); ++i) {
            random -= cards.get(i).getNumberOfWrong();
            if (random <= 0) {
                randomNum = i;
                break;
            }
        }
        temp = cards.get(randomNum);
        cards.remove(temp);
        return temp;
    }
}
