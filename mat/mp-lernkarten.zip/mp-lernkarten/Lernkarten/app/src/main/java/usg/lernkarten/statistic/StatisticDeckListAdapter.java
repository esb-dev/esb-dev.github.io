/**
 * Musterprojekt Softwaretechnik
 * Copyright (c) 2015 by Institut für SoftwareArchitektur, TH Mittelhessen.
 * Lizenz Creative Commons CC BY-NC-SA 3.0
 *
 */
package usg.lernkarten.statistic;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import usg.lernkarten.data.dao.AppFactory;
import usg.lernkarten.util.PictureUtil;
import usg.lernkarten.R;
import usg.lernkarten.data.Deck;
import usg.lernkarten.data.Flashcard;
import usg.lernkarten.data.dao.FlashcardDAO;

/**
 *  This class implements a custom ArrayAdapter containing the statistics for every deck.
 */
class StatisticDeckListAdapter extends ArrayAdapter<Deck> {

    private final List<Deck> decks;
    private final Context context;

    public StatisticDeckListAdapter(Context context, List<Deck> decks) {
        super(context, R.layout.deck_list_item, decks);
        this.context = context;
        this.decks = decks;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {

        View rowView = convertView;

        if(rowView == null) {
            LayoutInflater inflater = (LayoutInflater) context
                    .getSystemService(Context.LAYOUT_INFLATER_SERVICE);

            rowView = inflater.inflate(R.layout.statistic_deck_list_item, parent, false);
        }

        TextView textViewTitle = (TextView) rowView.findViewById(R.id.statistik_deck_list_item_title);
        TextView textLastPlayed = (TextView) rowView.findViewById(R.id.statistik_deck_list_item_last_played);
        TextView textNumberFalse = (TextView) rowView.findViewById(R.id.statistik_deck_list_item_number_false);
        TextView textNumberPlayed = (TextView) rowView.findViewById(R.id.statistik_deck_list_item_number_played);
        TextView textNumberRight = (TextView) rowView.findViewById(R.id.statistik_deck_list_item_number_right);
        ImageView imageView = (ImageView) rowView.findViewById(R.id.statistik_deck_list_item_thumb);

        FlashcardDAO flashcardDAO = AppFactory.get(context).getFlashcardDAO();

        final Deck deck = decks.get(position);
        textViewTitle.setText(deck.getName());

        int numberFalse = 0;
        int numberRight = 0;
        long lastPlayed = 0;


        List<Flashcard> flashcards = flashcardDAO.findByDeck(deck);
        for (Flashcard f : flashcards){
            numberRight += f.getNumberOfCorrect();
            numberFalse += f.getNumberOfWrong();

            if(f.getLastPlayed() > lastPlayed){
                lastPlayed = f.getLastPlayed();
            }
        }

        int numberLearned = numberFalse + numberRight;

        Date date = new Date(lastPlayed);
        java.text.DateFormat dateFormat = android.text.format.DateFormat.getDateFormat(getContext());
        String dateString = dateFormat.format(date);

        textNumberFalse.setText(String.valueOf(numberFalse));
        textNumberRight.setText(String.valueOf(numberRight));
        textNumberPlayed.setText(String.valueOf(numberLearned));

        if(lastPlayed == 0){
            textLastPlayed.setText(context.getString(R.string.new_));
        }else {
            textLastPlayed.setText(dateString);
        }

        Bitmap image;
        if(decks.get(position).getPicture()!=null){
            image = PictureUtil.getBitmapFromPicture(context, decks.get(position).getPicture());
            if(image != null){
                imageView.setImageBitmap(image);
            }
        }

        rowView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(context,StatisticFlashcardActivity.class);
                i.putExtra("deck", decks.get(position).getId());
                context.startActivity(i);
            }
        });


        return rowView;
    }

}