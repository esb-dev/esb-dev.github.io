/**
 * Musterprojekt Softwaretechnik
 * Copyright (c) 2015 by Institut für SoftwareArchitektur, TH Mittelhessen.
 * Lizenz Creative Commons CC BY-NC-SA 3.0
 *
 */
package usg.lernkarten.data.db;

import android.content.ContentValues;
import usg.lernkarten.data.Picture;

/**
 * Class that contains constants and helper-methods for the picture table.
 */
public class PictureDB {

    public static final String TABLE_NAME = "picture";

    public static final String ID = "_id";
    public static final String PICTURE_NAME = "name";
    public static final String PICTURE_MIME_TYPE = "mime_type";
    public static final String PICTURE_SIZE = "size";

    /**
     * Not intended for instantiation.
     */
    private PictureDB() {
    }

    public static ContentValues createContentValue(Picture picture) {
        ContentValues cv = new ContentValues();

        cv.put(PICTURE_NAME, picture.getName());
        cv.put(PICTURE_MIME_TYPE, picture.getMimeType());
        cv.put(PICTURE_SIZE, picture.getSize());

        return cv;
    }
}
