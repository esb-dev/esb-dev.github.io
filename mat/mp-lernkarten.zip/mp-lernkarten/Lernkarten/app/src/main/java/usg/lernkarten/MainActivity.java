/**
 * Musterprojekt Softwaretechnik
 * Copyright (c) 2015 by Institut für SoftwareArchitektur, TH Mittelhessen.
 * Lizenz Creative Commons CC BY-NC-SA 3.0
 */
package usg.lernkarten;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.app.SearchManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.support.v4.content.ContextCompat;
import android.support.v4.view.MenuItemCompat;
import android.support.v7.app.ActionBar;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.SearchView;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.support.v4.widget.DrawerLayout;
import android.view.View;
import android.widget.Toast;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;

import usg.lernkarten.deck.DeckListFragment;
import usg.lernkarten.update.UpdateTask;
import usg.lernkarten.setting.SettingsFragment;
import usg.lernkarten.statistic.StatisticDeckFragment;
import usg.lernkarten.update.UpdateService;
import usg.lernkarten.util.ImportUtil;

/**
 * The MainActivity, representing the first screen that is shown when opening the app.
 */
public class MainActivity extends AppCompatActivity
        implements NavigationDrawerFragment.NavigationDrawerCallbacks, SearchView.OnQueryTextListener {

    /**
     * Fragment managing the behaviors, interactions and presentation of the navigation drawer.
     */
    private NavigationDrawerFragment mNavigationDrawerFragment;

    /**
     * Used to store the last screen title. For use in {@link #restoreActionBar()}.
     */
    private CharSequence mTitle;

    private SearchView.OnQueryTextListener mListener;
    private SearchView mSearchView;

    private MenuItem searchItem;

    private static final int FILE_PICKED = 10;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main_activity);

        mNavigationDrawerFragment = (NavigationDrawerFragment)
                getSupportFragmentManager().findFragmentById(R.id.navigation_drawer);

        mTitle = getResources().getString(R.string.deck);
        setTitle(mTitle);

        Toolbar toolbar = (Toolbar) findViewById(R.id.flashcard_actionbar);

        /**
         *  Necessary to set color here for devices < Android 5
         */
        toolbar.setTitleTextColor(Color.WHITE);
        toolbar.setSubtitleTextColor(Color.WHITE);

        setSupportActionBar(toolbar);

        mNavigationDrawerFragment.setUp(
                R.id.navigation_drawer,
                (DrawerLayout) findViewById(R.id.drawer_layout), toolbar);

        startService(new Intent(this, UpdateService.class));

    }

    @Override
    public void onNavigationDrawerItemSelected(int position) {

        final int decklistItem = 0;
        final int statisticItem = 1;
        final int importItem = 2;
        final int updateItem = 3;
        final int settingsItem = 4;

        final FragmentManager fragmentManager = getSupportFragmentManager();

        switch (position) {
            case decklistItem:
                DeckListFragment deckListFragment = new DeckListFragment();
                fragmentManager.beginTransaction()
                        .replace(R.id.container, deckListFragment)
                        .commit();
                mTitle = getString(R.string.deck);
                break;
            case importItem:
                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                intent.setType("file/*.json");

                try {

                    startActivityForResult(intent, FILE_PICKED);

                } catch (Exception e) {
                    /**
                     *  No file manager installed.
                     */
                    final AlertDialog.Builder builder = new AlertDialog.Builder(this);
                    builder.setMessage(getString(R.string.import_install_filemanager));
                    builder.setTitle(getString(R.string.import_no_filemanager));
                    builder.setNeutralButton(R.string.close, null);
                    builder.show();

                }
                break;
            case updateItem:
                ProgressDialog mProgressDialog;
                mProgressDialog = new ProgressDialog(MainActivity.this);
                mProgressDialog.setMessage(getString(R.string.import_dialog_title));
                mProgressDialog.setIndeterminate(true);
                mProgressDialog.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
                mProgressDialog.setCancelable(true);

                // execute this when the downloader must be fired
                final UpdateTask updateTask = new UpdateTask(MainActivity.this, mProgressDialog);
                updateTask.execute(getString(R.string.url_import_url));

                mProgressDialog.setOnCancelListener(new DialogInterface.OnCancelListener() {
                    @Override
                    public void onCancel(DialogInterface dialog) {
                        updateTask.cancel(true);
                    }
                });

                mProgressDialog.setOnDismissListener(new DialogInterface.OnDismissListener() {
                    @Override
                    public void onDismiss(DialogInterface dialog) {
                        mNavigationDrawerFragment.selectItem(0);
                    }
                });

                break;
            case statisticItem:
                mTitle = getString(R.string.statistic_fragment_title);
                Fragment statisticFragment = new StatisticDeckFragment();
                fragmentManager.beginTransaction()
                        .replace(R.id.container, statisticFragment).commit();
                break;
            case settingsItem:
                mTitle = getString(R.string.learnmode);
                SettingsFragment settingsFragment = new SettingsFragment();
                fragmentManager.beginTransaction()
                        .replace(R.id.container, settingsFragment).commit();
                break;
        }

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        switch (requestCode) {
            case FILE_PICKED:
                if (resultCode == RESULT_OK) {
                    File file = new File(data.getData().getPath());
                    try {
                        InputStream is = new FileInputStream(file);
                        ImportUtil.get(this).readJsonStream(is);
                    } catch (Exception e) {
                        Toast.makeText(getApplicationContext(), "Fehler beim Import der Datei.", Toast.LENGTH_SHORT).show();
                    }
                }
                break;
            default:
                super.onActivityResult(requestCode, resultCode, data);
        }
    }

    @SuppressWarnings("deprecation")
    private void restoreActionBar() {
        ActionBar actionBar = getSupportActionBar();
        actionBar.setNavigationMode(ActionBar.NAVIGATION_MODE_STANDARD);
        actionBar.setDisplayShowTitleEnabled(true);
        actionBar.setTitle(mTitle);
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        if (!mNavigationDrawerFragment.isDrawerOpen()) {
            // Only show items in the action bar relevant to this screen
            // if the drawer is not showing. Otherwise, let the drawer
            // decide what to show in the action bar.
            getMenuInflater().inflate(R.menu.menu_main, menu);
            restoreActionBar();

            SearchManager searchManager =
                    (SearchManager) getSystemService(Context.SEARCH_SERVICE);

            searchItem = menu.findItem(R.id.show_decks_search);
            mSearchView = (SearchView) MenuItemCompat.getActionView(searchItem);

            mSearchView.setOnQueryTextFocusChangeListener(new View.OnFocusChangeListener() {
                @Override
                public void onFocusChange(View view, boolean queryTextFocused) {
                    if (!queryTextFocused) {
                        searchItem.collapseActionView();
                        mSearchView.setQuery("", false);
                    }
                }
            });

            mSearchView.setSearchableInfo(
                    searchManager.getSearchableInfo(getComponentName()));
            mSearchView.setSubmitButtonEnabled(true);
            mSearchView.setOnQueryTextListener(this);

            SearchView.SearchAutoComplete searchAutoComplete = (SearchView.SearchAutoComplete) mSearchView.findViewById(android.support.v7.appcompat.R.id.search_src_text);
            searchAutoComplete.setHintTextColor(ContextCompat.getColor(this, android.R.color.white));
            searchAutoComplete.setTextColor(ContextCompat.getColor(this, android.R.color.white));

            return super.onCreateOptionsMenu(menu);
        }

        menu.clear();
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        switch (id) {
            case R.id.show_decks_search:
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }


    }

    public void registerSearchHandler(SearchView.OnQueryTextListener sh) {
        mListener = sh;
    }

    @Override
    public boolean onQueryTextSubmit(String s) {
        mListener.onQueryTextSubmit(s);
        return false;
    }

    @Override
    public boolean onQueryTextChange(String s) {
        mListener.onQueryTextChange(s);
        return true;
    }

    public boolean isDrawerOpen() {
        return mNavigationDrawerFragment.isDrawerOpen();
    }
}
