/**
 * Musterprojekt Softwaretechnik
 * Copyright (c) 2015 by Institut für SoftwareArchitektur, TH Mittelhessen.
 * Lizenz Creative Commons CC BY-NC-SA 3.0
 */
package usg.lernkarten.data.db.util;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import usg.lernkarten.data.db.AnswerDB;
import usg.lernkarten.data.db.AnswerPictureDB;
import usg.lernkarten.data.db.DeckDB;
import usg.lernkarten.data.db.FlashcardDB;
import usg.lernkarten.data.db.FlashcardPictureDB;
import usg.lernkarten.data.db.PictureDB;

/**
 * A concrete helper class to manage database creation
 */
public class MySQLiteOpenHelper extends SQLiteOpenHelper {

    private static final Integer DATABASE_VERSION = 1;
    private static final String DATABASE_NAME = "flashcards.sqlite";

    public MySQLiteOpenHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }


    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + PictureDB.TABLE_NAME + " ("
                + PictureDB.ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + PictureDB.PICTURE_NAME + " TEXT,"
                + PictureDB.PICTURE_MIME_TYPE + " TEXT,"
                + PictureDB.PICTURE_SIZE + " TEXT);");

        db.execSQL("CREATE TABLE " + DeckDB.TABLE_NAME + " ("
                + DeckDB.ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + DeckDB.DECK_NAME + " TEXT, "
                + DeckDB.DECK_DESCRIPTION + " TEXT,"
                + DeckDB.DECK_PICTURE_ID + " INTEGER REFERENCES " + PictureDB.TABLE_NAME + ");");

        db.execSQL("CREATE TABLE " + FlashcardDB.TABLE_NAME + " ("
                + FlashcardDB.ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + FlashcardDB.FLASHCARD_QUESTION + " TEXT,"
                + FlashcardDB.FLASHCARD_NUMBER_OF_CORRECT + " INTEGER,"
                + FlashcardDB.FLASHCARD_NUMBER_OF_WRONG + " INTEGER,"
                + FlashcardDB.FLASHCARD_LAST_CORRECT + " LONG,"
                + FlashcardDB.FLASHCARD_LAST_PLAYED + " LONG,"
                + FlashcardDB.FLASHCARD_DECK_ID + " INTEGER REFERENCES " + DeckDB.TABLE_NAME + ");");

        db.execSQL("CREATE TABLE " + AnswerDB.TABLE_NAME + " ("
                + AnswerDB.ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + AnswerDB.ANSWER_ANSWER + " TEXT,"
                + AnswerDB.ANSWER_CORRECT + " INTEGER,"
                + AnswerDB.ANSWER_FLASHCARD_ID + " INTEGER REFERENCES " + FlashcardDB.TABLE_NAME + ");");

        db.execSQL("CREATE TABLE " + AnswerPictureDB.TABLE_NAME + " ("
                + AnswerPictureDB.ANSWERPICTURE_ANSWER_ID + " INTEGER REFERENCES " + AnswerDB.TABLE_NAME + ","
                + AnswerPictureDB.ANSWERPICTURE_PICTURE_ID + " INTEGER REFERENCES " + PictureDB.TABLE_NAME + ","
                + "PRIMARY KEY (" + AnswerPictureDB.ANSWERPICTURE_ANSWER_ID + ", " + AnswerPictureDB.ANSWERPICTURE_PICTURE_ID + "));");

        db.execSQL("CREATE TABLE " + FlashcardPictureDB.TABLE_NAME + " ("
                + FlashcardPictureDB.FLASHCARDPICTURE_FLASHCARD_ID + " INTEGER REFERENCES " + FlashcardDB.TABLE_NAME + ","
                + FlashcardPictureDB.FLASHCARDPICTURE_PICTURE_ID + " INTEGER REFERENCES " + PictureDB.TABLE_NAME + ","
                + "PRIMARY KEY (" + FlashcardPictureDB.FLASHCARDPICTURE_FLASHCARD_ID + ", " + FlashcardPictureDB.FLASHCARDPICTURE_PICTURE_ID + "));");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
}
