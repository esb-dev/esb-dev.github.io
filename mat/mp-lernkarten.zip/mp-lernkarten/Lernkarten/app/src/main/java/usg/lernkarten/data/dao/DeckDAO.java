/**
 * Musterprojekt Softwaretechnik
 * Copyright (c) 2015 by Institut für SoftwareArchitektur, TH Mittelhessen.
 * Lizenz Creative Commons CC BY-NC-SA 3.0
 *
 */
package usg.lernkarten.data.dao;

import java.util.List;

import usg.lernkarten.data.Deck;


public interface DeckDAO {

    /**
     * Returns all decks in db.
     *
     * @return List of all decks
     */
    List<Deck> findAll();

    /**
     * Finds the deck by the given name
     *
     * @param name
     * @return deck with that name, if there is none null
     */
    Deck findByName(String name);

    /**
     * Finds the deck by the given id
     *
     * @param id
     * @return deck with that id, if there is none, null
     */
    Deck findById(Integer id);

    /**
     * Returns the time when this flashcard was learned for the last time
     * @param deck
     * @return
     */
    Long getLastPlayed(Deck deck);

    /**
     * Persists the given entity
     *
     * @param deck
     * @return id of the persisted entity
     */
    Long persist(Deck deck);

    /**
     * Updates the given entity
     *
     * @param deck
     */
    void update(Deck deck);

    /**
     * Deletes the given entity
     *
     * @param deck
     */
    void delete(Deck deck);

}
