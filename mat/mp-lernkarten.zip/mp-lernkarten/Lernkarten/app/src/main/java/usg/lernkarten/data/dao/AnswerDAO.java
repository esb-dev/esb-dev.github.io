/**
 * Musterprojekt Softwaretechnik
 * Copyright (c) 2015 by Institut für SoftwareArchitektur, TH Mittelhessen.
 * Lizenz Creative Commons CC BY-NC-SA 3.0
 *
 */
package usg.lernkarten.data.dao;

import java.util.List;

import usg.lernkarten.data.Answer;
import usg.lernkarten.data.Flashcard;

public interface AnswerDAO {

    /**
     * Returns all answers in db.
     *
     * @return List of all answers
     */
    List<Answer> findAll();

    /**
     * Returns all answers for a certain flahscard.
     *
     * @param flashcard
     * @return all answers fot the given flashcard
     */
    List<Answer> findAllByFlashcard(Flashcard flashcard);

    /**
     * Finds an answer by the given id
     *
     * @param id
     * @return answer with that id, if there is none null
     */
    Answer findById(Integer id);

    /**
     * Persists the given entity
     *
     * @param answer
     * @return id of the persisted entity
     */
    Long persist(Answer answer);

    /**
     * Updates the given entity
     *
     * @param answer
     */
    void update(Answer answer);

    /**
     * Deletes the given entity
     *
     * @param answer
     */
    void delete(Answer answer);

}
