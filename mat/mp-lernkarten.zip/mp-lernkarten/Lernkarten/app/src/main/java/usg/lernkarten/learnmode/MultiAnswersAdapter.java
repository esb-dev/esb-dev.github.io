/**
 * Musterprojekt Softwaretechnik
 * Copyright (c) 2015 by Institut für SoftwareArchitektur, TH Mittelhessen.
 * Lizenz Creative Commons CC BY-NC-SA 3.0
 */
package usg.lernkarten.learnmode;

import android.content.Context;
import android.support.v4.content.ContextCompat;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;

import java.util.HashMap;
import java.util.List;

import usg.lernkarten.R;
import usg.lernkarten.data.Answer;

/**
 * This Class represents an ArrayAdapter that holds the answers and a map that contains the information if the user gave the correct answer.
 */
class MultiAnswersAdapter extends ArrayAdapter<Answer> {

    private final Context context;
    private final List<Answer> values;
    private final HashMap<Integer, Boolean> checkedMap;
    private final Boolean showResult;

    public MultiAnswersAdapter(Context ctx, List<Answer> answers, HashMap<Integer, Boolean> checked, Boolean showResult) {
        super(ctx, R.layout.multi_answer_item, answers);
        context = ctx;
        values = answers;
        checkedMap = checked;
        this.showResult = showResult;
        if (!this.showResult) {
            for (Answer a : answers) {
                checked.put(a.getId(), false);
            }
        }
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {

        View rowView = convertView;

        if (rowView == null) {
            LayoutInflater inflater = (LayoutInflater) context
                    .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            rowView = inflater.inflate(R.layout.multi_answer_item, parent, false);
        }

        Answer a = values.get(position);

        CheckBox checkBox = (CheckBox) rowView.findViewById(R.id.multi_answer_item_checkbox);
        checkBox.setText(values.get(position).getAnswer());

        //set the color of the answer: if answer was correct set color green, if not set red.
        if (showResult) {
            checkBox.setClickable(false);
            checkBox.setChecked(checkedMap.get(values.get(position).getId()));
            if (a.getAnswerCorrect()) {
                if (checkBox.isChecked()) {
                    checkBox.setTextColor(ContextCompat.getColor(getContext(), R.color.correct_green));
                } else {
                    checkBox.setTextColor(ContextCompat.getColor(getContext(), R.color.false_red));
                }
            } else {
                if (checkBox.isChecked()) {
                    checkBox.setTextColor(ContextCompat.getColor(getContext(), R.color.false_red));
                } else {
                    checkBox.setTextColor(ContextCompat.getColor(getContext(), R.color.correct_green));
                }
            }
        } else {
            checkBox.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    CheckBox cb = (CheckBox) v;
                    Integer id = values.get(position).getId();
                    checkedMap.put(id, cb.isChecked());
                }
            });
        }
        return rowView;
    }
}
