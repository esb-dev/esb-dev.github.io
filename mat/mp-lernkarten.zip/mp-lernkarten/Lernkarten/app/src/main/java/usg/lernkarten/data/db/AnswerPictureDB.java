/**
 * Musterprojekt Softwaretechnik
 * Copyright (c) 2015 by Institut für SoftwareArchitektur, TH Mittelhessen.
 * Lizenz Creative Commons CC BY-NC-SA 3.0
 *
 */
package usg.lernkarten.data.db;

import android.content.ContentValues;

import usg.lernkarten.data.Answer;
import usg.lernkarten.data.Picture;

/**
 * Class that contains constants and helper-methods for the answer-picture table.
 */
public final class AnswerPictureDB {

    public static final String TABLE_NAME = "answer_picture";

    public static final String ANSWERPICTURE_PICTURE_ID = "picture_id";
    public static final String ANSWERPICTURE_ANSWER_ID = "answer_id";

    /**
     * Not intended for instantiation.
     */
    private AnswerPictureDB(){
    }

    public static ContentValues createContentValue(Answer answer, Picture picture) {
        ContentValues cv = new ContentValues();

        cv.put(ANSWERPICTURE_PICTURE_ID, picture.getId());
        cv.put(ANSWERPICTURE_ANSWER_ID, answer.getId());

        return cv;
    }
}
