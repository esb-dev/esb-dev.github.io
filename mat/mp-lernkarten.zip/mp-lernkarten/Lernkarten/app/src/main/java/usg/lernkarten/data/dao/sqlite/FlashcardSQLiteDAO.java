/**
 * Musterprojekt Softwaretechnik
 * Copyright (c) 2015 by Institut für SoftwareArchitektur, TH Mittelhessen.
 * Lizenz Creative Commons CC BY-NC-SA 3.0
 *
 */
package usg.lernkarten.data.dao.sqlite;

import static usg.lernkarten.data.db.FlashcardDB.*;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;

import usg.lernkarten.data.Deck;
import usg.lernkarten.data.Flashcard;
import usg.lernkarten.data.Picture;
import usg.lernkarten.data.dao.FlashcardDAO;
import usg.lernkarten.data.db.AnswerDB;
import usg.lernkarten.data.db.FlashcardDB;
import usg.lernkarten.data.db.FlashcardPictureDB;
import usg.lernkarten.data.db.util.MySQLiteOpenHelper;

/**
 * Concrete Data-Access Class to access the data from a SQLite-DB
 */
public class FlashcardSQLiteDAO implements FlashcardDAO{

    private final MySQLiteOpenHelper mySQLiteOpenHelper;
    private final Context context;

    public FlashcardSQLiteDAO(Context ctx) {
        this.context = ctx;
        mySQLiteOpenHelper = new MySQLiteOpenHelper(ctx);
    }

    @Override
    public List<Flashcard> findAll() {
        List<Flashcard> result = new ArrayList<>();

        SQLiteDatabase db = mySQLiteOpenHelper.getReadableDatabase();
        String[] projection = {ID, FLASHCARD_QUESTION, FLASHCARD_NUMBER_OF_CORRECT, FLASHCARD_NUMBER_OF_WRONG, FLASHCARD_LAST_CORRECT, FLASHCARD_LAST_PLAYED, FLASHCARD_DECK_ID};

        Cursor c = db.query(TABLE_NAME, projection, null, null, null, null, null);

        while(c.moveToNext()) {
            Flashcard f = new Flashcard();
            f.setId(c.getInt(0));
            f.setQuestion(c.getString(1));
            f.setNumberOfCorrect(c.getInt(2));
            f.setNumberOfWrong(c.getInt(3));
            f.setLastCorrect(c.getLong(4));
            f.setLastPlayed(c.getLong(5));
            f.setDeck(new DeckSQLiteDAO(context).findById(c.getInt(6)));
            f.setPictures(new PictureSQLiteDAO(context).findAllByFlashcard(f));
            result.add(f);
        }

        c.close();
        db.close();

        return result;
    }

    public List<Flashcard> findByDeck(Deck deck) {
        List<Flashcard> result = new ArrayList<>();

        SQLiteDatabase db = mySQLiteOpenHelper.getReadableDatabase();
        String[] projection = {ID, FLASHCARD_QUESTION, FLASHCARD_NUMBER_OF_CORRECT, FLASHCARD_NUMBER_OF_WRONG, FLASHCARD_LAST_CORRECT, FLASHCARD_LAST_PLAYED, FLASHCARD_DECK_ID};

        Cursor c = db.query(TABLE_NAME, projection,  FLASHCARD_DECK_ID + "=" + deck.getId(), null, null, null, null);

        while(c.moveToNext()) {
            Flashcard f = new Flashcard();
            f.setId(c.getInt(0));
            f.setQuestion(c.getString(1));
            f.setNumberOfCorrect(c.getInt(2));
            f.setNumberOfWrong(c.getInt(3));
            f.setLastCorrect(c.getLong(4));
            f.setLastPlayed(c.getLong(5));
            f.setDeck(new DeckSQLiteDAO(context).findById(c.getInt(6)));
            f.setPictures(new PictureSQLiteDAO(context).findAllByFlashcard(f));
            result.add(f);
        }

        c.close();
        db.close();

        return result;
    }

    @Override
    public List<Flashcard> findByDeckWithAnswer(Deck deck) {
        List<Flashcard> result = new ArrayList<>();

        SQLiteDatabase db = mySQLiteOpenHelper.getReadableDatabase();
        final String query = "SELECT f." + FlashcardDB.ID + ", "
                    + "f." + FlashcardDB.FLASHCARD_QUESTION + ", "
                    + "f." + FlashcardDB.FLASHCARD_NUMBER_OF_CORRECT + ", "
                    + "f." + FlashcardDB.FLASHCARD_NUMBER_OF_WRONG + ", "
                    + "f." + FlashcardDB.FLASHCARD_LAST_CORRECT + ", "
                    + "f." + FlashcardDB.FLASHCARD_LAST_PLAYED + ", "
                    + "f." + FlashcardDB.FLASHCARD_DECK_ID
                    + " FROM " + FlashcardDB.TABLE_NAME + " f"
                    + " WHERE f." + FlashcardDB.ID + " in"
                    + " ( SELECT " + AnswerDB.ANSWER_FLASHCARD_ID + " FROM " + AnswerDB.TABLE_NAME + " )"
                    + " AND f." + FlashcardDB.FLASHCARD_DECK_ID + "=?";
        Cursor c = db.rawQuery(query, new String[]{String.valueOf(deck.getId())});

        while(c.moveToNext()) {
            Flashcard f = new Flashcard();
            f.setId(c.getInt(0));
            f.setQuestion(c.getString(1));
            f.setNumberOfCorrect(c.getInt(2));
            f.setNumberOfWrong(c.getInt(3));
            f.setLastCorrect(c.getLong(4));
            f.setLastPlayed(c.getLong(5));
            f.setDeck(new DeckSQLiteDAO(context).findById(c.getInt(6)));
            f.setPictures(new PictureSQLiteDAO(context).findAllByFlashcard(f));
            result.add(f);
        }

        c.close();
        db.close();

        for(Flashcard f : result) {
            Log.d("DECKWITHANSWER", f.getQuestion());
        }

        return result;
    }

    @Override
    public Flashcard findById(Integer id) {
        Flashcard f = null;

        SQLiteDatabase db = mySQLiteOpenHelper.getReadableDatabase();
        String[] projection = {ID, FLASHCARD_QUESTION, FLASHCARD_NUMBER_OF_CORRECT, FLASHCARD_NUMBER_OF_WRONG, FLASHCARD_LAST_CORRECT, FLASHCARD_LAST_PLAYED, FLASHCARD_DECK_ID};

        Cursor c = db.query(TABLE_NAME, projection, ID + "=" + id, null, null, null, null);


        if(c.moveToNext()) {
            f = new Flashcard();
            f.setId(c.getInt(0));
            f.setQuestion(c.getString(1));
            f.setNumberOfCorrect(c.getInt(2));
            f.setNumberOfWrong(c.getInt(3));
            f.setLastCorrect(c.getLong(4));
            f.setLastPlayed(c.getLong(5));
            f.setDeck(new DeckSQLiteDAO(context).findById(c.getInt(6)));
            f.setPictures(new PictureSQLiteDAO(context).findAllByFlashcard(f));
        }

        c.close();
        db.close();

        return f;
    }

    @Override
    public Long persist(Flashcard flashcard) {
        SQLiteDatabase db = mySQLiteOpenHelper.getWritableDatabase();
        ContentValues cv = FlashcardDB.createContentValue(flashcard);
        long id = db.insert(TABLE_NAME, null, cv);

        for(Picture p : flashcard.getPictures()) {
            cv = FlashcardPictureDB.createContentValue(flashcard, p);
            db.insert(FlashcardPictureDB.TABLE_NAME, null, cv);
        }

        flashcard.setId((int) id);

        db.close();
        return id;
    }

    @Override
    public void update(Flashcard flashcard) {
        SQLiteDatabase db = mySQLiteOpenHelper.getWritableDatabase();
        ContentValues cv = FlashcardDB.createContentValue(flashcard);
        String[] whereArgs = { "" + flashcard.getId() };
        db.update(TABLE_NAME, cv, ID + "=?", whereArgs);

        db.delete(FlashcardPictureDB.TABLE_NAME, FlashcardPictureDB.FLASHCARDPICTURE_FLASHCARD_ID + "=?", whereArgs);
        for(Picture p : flashcard.getPictures()) {
            cv = FlashcardPictureDB.createContentValue(flashcard, p);
            db.insert(FlashcardPictureDB.TABLE_NAME, null, cv);
        }

        db.close();
    }

    @Override
    public void delete(Flashcard flashcard) {
        SQLiteDatabase db = mySQLiteOpenHelper.getWritableDatabase();
        String[] whereArgs = { "" + flashcard.getId() };
        db.delete(TABLE_NAME, ID + "=?", whereArgs);

        db.close();
    }
}
