/**
 * Musterprojekt Softwaretechnik
 * Copyright (c) 2015 by Institut für SoftwareArchitektur, TH Mittelhessen.
 * Lizenz Creative Commons CC BY-NC-SA 3.0
 */
package usg.lernkarten.flashcard.answer;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;

import java.util.List;

import usg.lernkarten.data.Answer;
import usg.lernkarten.flashcard.answer.AnswerPageFragment;

/**
 *  Represents a custom FragmentPagerAdapter to go through the answers in a Pager View.
 */
class AnswerPagerAdapter extends FragmentPagerAdapter {

    private final List<Answer> answerList;

    public AnswerPagerAdapter(FragmentManager fm, List<Answer> answerList) {
        super(fm);
        this.answerList = answerList;
    }

    @Override
    public Fragment getItem(int position) {
        Fragment fragment = new AnswerPageFragment();
        Bundle args = new Bundle();

        args.putSerializable("answer", answerList.get(position));
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public int getItemPosition(Object object) {
        Answer a = ((AnswerPageFragment) object).getAnswer();
        if (answerList.contains(a)) {
            return answerList.indexOf(a);
        } else {
            return POSITION_NONE;
        }
    }

    @Override
    public int getCount() {
        return answerList.size();
    }

    @Override
    public CharSequence getPageTitle(int position) {
        return "Bearbeiten";
    }
}