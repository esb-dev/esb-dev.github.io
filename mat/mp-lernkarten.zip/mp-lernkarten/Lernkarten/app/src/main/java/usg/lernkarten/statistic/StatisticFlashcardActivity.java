/**
 * Musterprojekt Softwaretechnik
 * Copyright (c) 2015 by Institut für SoftwareArchitektur, TH Mittelhessen.
 * Lizenz Creative Commons CC BY-NC-SA 3.0
 *
 */
package usg.lernkarten.statistic;

import android.graphics.Color;
import android.os.Bundle;
import android.support.v7.app.ActionBar;
import android.support.v7.app.ActionBarActivity;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;

import usg.lernkarten.R;
import usg.lernkarten.data.Deck;
import usg.lernkarten.data.dao.AppFactory;
import usg.lernkarten.data.dao.DeckDAO;
import usg.lernkarten.data.dao.FlashcardDAO;
import usg.lernkarten.util.Util;

/**
 * This class Represents a activity to display the statistics
 */
public class StatisticFlashcardActivity extends AppCompatActivity {

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.statistic_flashcards_view);

        RecyclerView mRecyclerView = (RecyclerView) findViewById(R.id.statistik_flashcards_recycler);
        mRecyclerView.setHasFixedSize(true);

        DeckDAO deckDAO = AppFactory.get(this).getDeckDAO();
        FlashcardDAO flashcardDAO = AppFactory.get(this).getFlashcardDAO();

        int deckId = getIntent().getExtras().getInt("deck");

        Deck deck = deckDAO.findById(deckId);

        Toolbar toolbar = (Toolbar) findViewById(R.id.flashcard_actionbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        toolbar.setTitleTextColor(Color.WHITE);
        toolbar.setSubtitleTextColor(Color.WHITE);


        LinearLayoutManager mLayoutManager;
        if(Util.isTablet(getApplicationContext())) {
            mLayoutManager = new GridLayoutManager(this, 2);
        } else {
            mLayoutManager = new LinearLayoutManager(this);
        }

        mRecyclerView.setLayoutManager(mLayoutManager);

        // specify an adapter
        StatisticFlashcardsAdapter mAdapter = new StatisticFlashcardsAdapter(flashcardDAO.findByDeck(deck));

        mRecyclerView.setAdapter(mAdapter);
        mRecyclerView.setItemAnimator(new DefaultItemAnimator());
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_statistik_flashcards, menu);
        restoreActionBar();
        return super.onCreateOptionsMenu(menu);
    }

    private void restoreActionBar() {
        ActionBar actionBar = getSupportActionBar();
        actionBar.setNavigationMode(ActionBar.NAVIGATION_MODE_STANDARD);
        actionBar.setDisplayShowTitleEnabled(true);
        actionBar.setDefaultDisplayHomeAsUpEnabled(true);
        actionBar.setTitle(getResources().getString(R.string.statistic_title_activity_statistic_flashcards));
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()) {
            case android.R.id.home:
                this.finish();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

}
