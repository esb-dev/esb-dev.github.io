/**
 * Musterprojekt Softwaretechnik
 * Copyright (c) 2015 by Institut für SoftwareArchitektur, TH Mittelhessen.
 * Lizenz Creative Commons CC BY-NC-SA 3.0
 */
package usg.lernkarten.util;

import android.content.Context;
import android.content.res.Configuration;

/**
 * This class offers util methods.
 */
public class Util {

    /**
     * Checks whether app is running on tablet
     *
     * @param context   Context needed to access device configuration
     * @return          true, if app is running on tablet else false
     */
    public static Boolean isTablet(Context context) {

        return (context.getResources().getConfiguration().screenLayout &
                Configuration.SCREENLAYOUT_SIZE_MASK) >= Configuration.SCREENLAYOUT_SIZE_LARGE;
    }

}
