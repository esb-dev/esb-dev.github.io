/**
 * Musterprojekt Softwaretechnik
 * Copyright (c) 2015 by Institut für SoftwareArchitektur, TH Mittelhessen.
 * Lizenz Creative Commons CC BY-NC-SA 3.0
 */
package usg.lernkarten.learnmode;

import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.content.res.ResourcesCompat;
import android.view.GestureDetector;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageSwitcher;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.ViewSwitcher;

import java.util.HashMap;
import java.util.List;

import usg.lernkarten.data.dao.AppFactory;
import usg.lernkarten.util.PictureUtil;
import usg.lernkarten.R;
import usg.lernkarten.data.Answer;
import usg.lernkarten.data.Flashcard;
import usg.lernkarten.data.dao.AnswerDAO;

/**
 * Fragment that handles the evaluation of the asked flashcard.
 */
public class FlashcardPlayBackFragment extends Fragment {

    private static final int SWIPE_MIN_DISTANCE = 120;
    private static final int SWIPE_MAX_OFF_PATH = 250;
    private static final int SWIPE_THRESHOLD_VELOCITY = 200;

    private View rootView;

    private int index;
    private GestureDetector gd;

    private Context context;

    private ImageSwitcher imageSwitcher;
    private FlashcardPlayBackCallbacks mCallbacks;

    private Flashcard card;
    private List<Answer> answers;
    private HashMap<Integer, Boolean> resultSet;

    private Boolean isMulti;


    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        context = getActivity().getApplicationContext();

        AnswerDAO answerDAO = AppFactory.get(context).getAnswerDAO();

        card = (Flashcard) getArguments().getSerializable("card");
        resultSet = (HashMap<Integer, Boolean>) getArguments().getSerializable("resultSet");
        isMulti = (Boolean) getArguments().getSerializable("isMulti");
        answers = answerDAO.findAllByFlashcard(card);

        generateQuestionView();

        Button known = (Button) rootView.findViewById(R.id.flashcard_single_back_known);
        known.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onKownButtonSelected();
            }
        });

        Button unknown = (Button) rootView.findViewById(R.id.flashcard_single_back_false);
        unknown.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onUnkownButtonSelected();
            }
        });

        index = 0;

        Animation in = AnimationUtils.loadAnimation(context,
                android.R.anim.fade_in);

        Animation out = AnimationUtils.loadAnimation(context,
                android.R.anim.fade_out);


        imageSwitcher = (ImageSwitcher) rootView.findViewById(R.id.flashcard_single_back_imageSwitcher);
        imageSwitcher.setFactory(new MyImageSwitcherFactory());
        imageSwitcher.setInAnimation(in);
        imageSwitcher.setOutAnimation(out);

        if (card.getPictures().isEmpty()) {
            imageSwitcher.setImageDrawable(ResourcesCompat.getDrawable(getResources(), R.drawable.deck, null));
        } else {
            Bitmap bitmap = PictureUtil.getBitmapFromPicture(context, card.getPictures().get(index));
            Drawable drawable = new BitmapDrawable(bitmap);
            imageSwitcher.setImageDrawable(drawable);
            imageSwitcher.setOnTouchListener(new View.OnTouchListener() {
                @Override
                public boolean onTouch(final View view, final MotionEvent event) {
                    gd.onTouchEvent(event);
                    return true;
                }
            });

            //move card
            gd = new GestureDetector(context, new GestureDetector.OnGestureListener() {

                @Override
                public boolean onDown(MotionEvent e) {
                    return false;
                }

                @Override
                public void onShowPress(MotionEvent e) {

                }

                @Override
                public boolean onSingleTapUp(MotionEvent e) {
                    return false;
                }

                @Override
                public boolean onScroll(MotionEvent e1, MotionEvent e2, float distanceX, float distanceY) {
                    return false;
                }

                @Override
                public void onLongPress(MotionEvent e) {

                }

                @Override
                public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX, float velocityY) {
                    try {
                        if (Math.abs(e1.getY() - e2.getY()) > SWIPE_MAX_OFF_PATH)
                            return false;
                        // right to left swipe
                        if (e1.getX() - e2.getX() > SWIPE_MIN_DISTANCE && Math.abs(velocityX) > SWIPE_THRESHOLD_VELOCITY) {
                            if (index + 1 < card.getPictures().size()) {
                                index = index + 1;
                            } else {
                                return false;
                            }

                        } else {
                            if (index - 1 >= 0) {
                                index = index - 1;
                            } else {
                                return false;
                            }
                        }
                        Bitmap bitmap = PictureUtil.getBitmapFromPicture(context, card.getPictures().get(index));
                        Drawable image = new BitmapDrawable(bitmap);
                        imageSwitcher.setImageDrawable(image);
                    } catch (Exception e) {
                        // nothing
                        e.printStackTrace();
                    }
                    return false;
                }
            });
        }
    }

    private void generateQuestionView() {

        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        ViewGroup view = (ViewGroup) rootView.findViewById(R.id.flashcard_play_back_answer);

        if (isMulti != null && isMulti) {
            MultiAnswersAdapter mAdapter = new MultiAnswersAdapter(context, answers, resultSet, true);

            inflater.inflate(R.layout.question_multi_view, view);

            TextView textview = (TextView) rootView.findViewById(R.id.question_multi_question);
            textview.setText("");

            ListView answerListView = (ListView) rootView.findViewById(R.id.question_multi_answer_list);
            answerListView.setAdapter(mAdapter);

        } else {
            inflater.inflate(R.layout.question_single_view, view);

            TextView textview = (TextView) rootView.findViewById(R.id.question_single_question);

            if (answers.size() > 0) {
                textview.setText(answers.get(0).getAnswer());
            } else {
                textview.setText(R.string.onesideflashcard);
            }

        }
    }

    private void onKownButtonSelected() {

        card.setLastCorrectNow();
        card.setLastPlayedNow();
        card.increaseNumberOfCorrectBy(1);
        mCallbacks.onKnownButtonSelected(card);

    }

    private void onUnkownButtonSelected() {

        card.setLastPlayedNow();
        card.increaseNumberOfWrongBy(1);
        mCallbacks.onUnknownButtonSelected(card);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        rootView = inflater.inflate(R.layout.flashcard_play_back_fragment, container, false);

        return rootView;
    }

    private class MyImageSwitcherFactory implements ViewSwitcher.ViewFactory {

        public View makeView() {

            ImageView imageView = new ImageView(context);
            imageView.setScaleType(ImageView.ScaleType.FIT_CENTER);
            imageView.setLayoutParams(new ImageSwitcher.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

            return imageView;
        }

    }

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        try {
            mCallbacks = (FlashcardPlayBackCallbacks) activity;
        } catch (ClassCastException e) {
            throw new ClassCastException("Activity must implement NavigationDrawerCallbacks.");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mCallbacks = null;
    }

    public interface FlashcardPlayBackCallbacks {

        void onKnownButtonSelected(Flashcard card);

        void onUnknownButtonSelected(Flashcard card);

    }
}
