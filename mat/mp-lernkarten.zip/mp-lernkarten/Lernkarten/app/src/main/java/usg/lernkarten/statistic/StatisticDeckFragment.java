/**
 * Musterprojekt Softwaretechnik
 * Copyright (c) 2015 by Institut für SoftwareArchitektur, TH Mittelhessen.
 * Lizenz Creative Commons CC BY-NC-SA 3.0
 *
 */
package usg.lernkarten.statistic;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.SearchView;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.GridView;
import android.widget.ListView;

import usg.lernkarten.MainActivity;
import usg.lernkarten.R;
import usg.lernkarten.data.dao.AppFactory;
import usg.lernkarten.data.dao.DeckDAO;

/**
 *  The fragment containing the statistics of every deck in a GridView or a ListView depending on the device.
 */
public class StatisticDeckFragment extends Fragment implements SearchView.OnQueryTextListener {

    private GridView mGridView;
    private ListView mListView;


    @Override
    public void onResume() {
        ((MainActivity) getActivity()).registerSearchHandler(this);

        super.onResume();
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        DeckDAO deckDAO = AppFactory.get(getActivity().getApplicationContext()).getDeckDAO();

        StatisticDeckListAdapter mAdapter = new StatisticDeckListAdapter(getActivity(), deckDAO.findAll());

        if (mGridView == null) {
            //Phone layout
            mListView.setAdapter(mAdapter);
            mListView.setTextFilterEnabled(true);
        } else {
            //Tablet layout
            mGridView.setAdapter(mAdapter);
            mGridView.setTextFilterEnabled(true);
        }

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View rootView = inflater.inflate(R.layout.statistic_deck_fragment, container, false);
        mListView = (ListView) rootView.findViewById(R.id.statistik_deck_listview);
        mGridView = (GridView) rootView.findViewById(R.id.staistik_deck_gridview);

        return rootView;
    }

    @Override
    public boolean onQueryTextSubmit(String s) {
        return false;
    }

    @Override
    public boolean onQueryTextChange(String newText) {
        if (newText != null) {
            if (TextUtils.isEmpty(newText)) {
                mListView.clearTextFilter();
            } else {
                mListView.setFilterText(newText);
            }
        }

        return true;
    }
}
