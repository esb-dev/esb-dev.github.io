/**
 * Musterprojekt Softwaretechnik
 * Copyright (c) 2015 by Institut für SoftwareArchitektur, TH Mittelhessen.
 * Lizenz Creative Commons CC BY-NC-SA 3.0
 */
package usg.lernkarten.learnmode;

import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.content.res.ResourcesCompat;
import android.view.GestureDetector;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageSwitcher;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.ViewSwitcher;

import java.util.HashMap;
import java.util.List;

import usg.lernkarten.data.dao.AppFactory;
import usg.lernkarten.util.PictureUtil;
import usg.lernkarten.R;
import usg.lernkarten.data.Answer;
import usg.lernkarten.data.Flashcard;
import usg.lernkarten.data.dao.AnswerDAO;

/**
 * Handles the transition to the next flashcard.
 */
public class FlashcardPlayFrontFragment extends Fragment {

    private static final int SWIPE_MIN_DISTANCE = 120;
    private static final int SWIPE_MAX_OFF_PATH = 250;
    private static final int SWIPE_THRESHOLD_VELOCITY = 200;

    private List<Answer> answers;
    private Context ctx;
    private Flashcard card;

    private View rootView;

    private int index;

    private GestureDetector gd;


    private ImageSwitcher imageSwitcher;
    private FlashcardPlayFrontCallbacks mCallbacks;


    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        ctx = getActivity().getApplicationContext();
        card = (Flashcard) getArguments().getSerializable("card");
        AnswerDAO answerDAO = AppFactory.get(ctx).getAnswerDAO();
        answers = answerDAO.findAllByFlashcard(card);
        final boolean isMultiple = answers.size() > 1;
        generateQuestionView(isMultiple);

        Button end = (Button) rootView.findViewById(R.id.flashcard_single_front_end);
        end.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onAnswerButtonSelected();
            }
        });
        index = 0;

        Animation in = AnimationUtils.loadAnimation(ctx,
                android.R.anim.fade_in);

        Animation out = AnimationUtils.loadAnimation(ctx,
                android.R.anim.fade_out);


        imageSwitcher = (ImageSwitcher) rootView.findViewById(R.id.flashcard_single_front_imageSwitcher);
        imageSwitcher.setFactory(new MyImageSwitcherFactory());
        imageSwitcher.setInAnimation(in);
        imageSwitcher.setOutAnimation(out);
        if (card.getPictures().isEmpty()) {
            imageSwitcher.setImageDrawable(ResourcesCompat.getDrawable(getResources(), R.drawable.flashcard, null));
        } else {
            Bitmap bitmap = PictureUtil.getBitmapFromPicture(ctx, card.getPictures().get(index));
            Drawable drawable = new BitmapDrawable(bitmap);
            imageSwitcher.setImageDrawable(drawable);
            imageSwitcher.setOnTouchListener(new View.OnTouchListener() {
                @Override
                public boolean onTouch(final View view, final MotionEvent event) {
                    gd.onTouchEvent(event);
                    return true;
                }
            });
            gd = new GestureDetector(ctx, new GestureDetector.OnGestureListener() {

                @Override
                public boolean onDown(MotionEvent e) {
                    return false;
                }

                @Override
                public void onShowPress(MotionEvent e) {

                }

                @Override
                public boolean onSingleTapUp(MotionEvent e) {
                    return false;
                }

                @Override
                public boolean onScroll(MotionEvent e1, MotionEvent e2, float distanceX, float distanceY) {
                    return false;
                }

                @Override
                public void onLongPress(MotionEvent e) {

                }

                @Override
                public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX, float velocityY) {
                    try {
                        if (Math.abs(e1.getY() - e2.getY()) > SWIPE_MAX_OFF_PATH)
                            return false;
                        // right to left swipe
                        if (e1.getX() - e2.getX() > SWIPE_MIN_DISTANCE && Math.abs(velocityX) > SWIPE_THRESHOLD_VELOCITY) {
                            if (index + 1 < card.getPictures().size()) {
                                index = index + 1;
                            } else {
                                return false;
                            }

                        } else {
                            if (index - 1 >= 0) {
                                index = index - 1;
                            } else {
                                return false;
                            }
                        }
                        Bitmap bitmap = PictureUtil.getBitmapFromPicture(ctx, card.getPictures().get(index));
                        Drawable image = new BitmapDrawable(bitmap);
                        //image = getQuestionImageDrawableXML(subjectArray[index]);
                        imageSwitcher.setImageDrawable(image);
                    } catch (Exception e) {
                        // nothing
                        e.printStackTrace();
                    }
                    return false;
                }
            });
        }

    }

    private void onAnswerButtonSelected() {
        mCallbacks.onEndButtonSelected();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        rootView = inflater.inflate(R.layout.flashcard_play_front_fragment, container, false);
        return rootView;
    }

    private void generateQuestionView(boolean isMultiple) {
        LayoutInflater inflater = (LayoutInflater) ctx.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        ViewGroup view = (ViewGroup) rootView.findViewById(R.id.flashcard_play_question_container);
        if (isMultiple) {
            final HashMap<Integer, Boolean> resultSet = new HashMap<>();
            MultiAnswersAdapter mAdapter = new MultiAnswersAdapter(ctx, answers, resultSet, false);
            inflater.inflate(R.layout.question_multi_view, view);
            TextView textview = (TextView) rootView.findViewById(R.id.question_multi_question);
            textview.setText(card.getQuestion());
            ListView answerListView = (ListView) rootView.findViewById(R.id.question_multi_answer_list);
            answerListView.setAdapter(mAdapter);
            Button answer = (Button) rootView.findViewById(R.id.flashcard_single_front_answer);
            answer.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    mCallbacks.onAnswerButtonSelectedMulti(card, answers, resultSet);
                }
            });

        } else {
            inflater.inflate(R.layout.question_single_view, view);
            TextView textview = (TextView) rootView.findViewById(R.id.question_single_question);
            textview.setText(card.getQuestion());
            Button answer = (Button) rootView.findViewById(R.id.flashcard_single_front_answer);
            answer.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    mCallbacks.onAnswerButtonSelectedSingle(card);
                }
            });
        }
    }

    private class MyImageSwitcherFactory implements ViewSwitcher.ViewFactory {
        public View makeView() {
            ImageView imageView = new ImageView(ctx);
            imageView.setScaleType(ImageView.ScaleType.FIT_CENTER);
            imageView.setLayoutParams(new ImageSwitcher.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            return imageView;
        }
    }

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        try {
            mCallbacks = (FlashcardPlayFrontCallbacks) activity;
        } catch (ClassCastException e) {
            throw new ClassCastException("Activity must implement NavigationDrawerCallbacks.");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mCallbacks = null;
    }

    public interface FlashcardPlayFrontCallbacks {
        /**
         * Called when an item in the navigation drawer is selected.
         */
        void onAnswerButtonSelectedSingle(Flashcard card);

        void onAnswerButtonSelectedMulti(Flashcard card, List<Answer> answerList, HashMap<Integer, Boolean> resultSet);

        void onEndButtonSelected();
    }
}
