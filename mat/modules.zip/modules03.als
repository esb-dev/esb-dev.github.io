/*
Module in Alloy, Teil 03

Die Darstellung basiert auf

Julien Brunel, David Chemouil, Alcino Cunha, Nuno Macedo:
Practical Alloy
Abschnitt Module system
*/

/*
/* 
Wir hatten die Definitionen aus dem Modul so verwendet:

fact rooted_dag {
  dag[Object, entries.object]
  rootedAt[Object, entries.object, Root]
}

Dabei gibt der erste Parameter den Typ der Knoten des Graphen an.

Das könne wir vereinfaschen, in dem wir das Modul parametrisieren:
*/

module modules03[node]

pred dag [r : node -> node] {
  all n : node | n not in n.^r
}

pred rootedAt [r : node -> node, root : node] {
  node in root.*r
}

/*
Damit können wir unsere Spezifikation für das Dateisystem umbauen:
siehe modules04.als
*/

