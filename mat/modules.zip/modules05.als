/*
Module in Alloy, Teil 05

Die Darstellung basiert auf

Julien Brunel, David Chemouil, Alcino Cunha, Nuno Macedo:
Practical Alloy
Abschnitt The predefined ordering module
*/

/*
Es kommt oft vor, dass man eine totale Ordnung für die Elemente
einer Signatur braucht. 

Dafür gibt es util/ordering. Dort wird definiert:

- Eine Relation next, die angibt, welches atom auf welches folgt
- Ein Singleton first und ein Singleton last
- Eine Reihe von Funktionen zum Vergleich, Maximum, Minimum und 
  Ähnliches.

Wir wollen util/ordering am Beispiel unseres Dateisystems ansehen, 
in dem wir einführen, dass jeder Entry im Dateisystem einen
Timestamp hat:
*/
 

module filesystem

/*
Wir machen eine neue Signatur Time auf und verwenden sie mit
utl/ordering, d.h. für die Signatur Time stehen nun alle
Definitionen von util/ordering zur Verfügung.

Man beachte: erst open ... dann sig Time.
*/

open util/ordering[Time]
sig Time {}

abstract sig Object {}

sig Dir extends Object {
  entries : set Entry
}

sig File extends Object {}

one sig Root extends Dir {}

/*
Nun erweitern wir Entry: Jeder Eintrag im Dateisystem
bekommt einen Timestamp:
*/

sig Entry {
  object : one Object,
  name   : one Name,
  time   : one Time
}

/*
Wir legen fest, dass jeder Eintrag einen früheren Timestamp hat
als seine Kinder:
*/

fact children_timestamp {
  all e : Entry, t : e.object.entries.time | lt[e.time, t]
}

/*
Bisher hatten wir noch folgendes Faktum:
fact {
   // Dirs können sich nicht selbst enthalten
   all d : Dir | d not in d.^(entries.object)
}

Das ist aber jetzt überflüssig, denn das obige fact
erzwingt dies.

Wir können das prüfen:
*/
assert acyclic {
   // Dirs können sich nicht selbst enthalten
   all d : Dir | d not in d.^(entries.object)
}

check acyclic for 8 // 10 sec

sig Name {}

fact unique_names {
  all d : Dir, n : Name | lone (d.entries & name.n)
}

fact no_shared_dirs {
  all d : Dir | lone object.d
}

fact no_dangling_objects {
  Entry.object = Object - Root
}

fact one_directory_per_entry {
  all e : Entry | one entries.e
}

fun descendants [o : Object] : set Object {
  o.^(entries.object)
}

pred reachable [o : Object] {
  o in Root + descendants[Root]
}


run example {}
run example {} for 4

/*
Die Verwendung von util/ordering hat einen Effekt, den man 
beachten sollte. Der Scope der Signatur mit der totalen Ordnung
ist immer exakt, auch wenn dies nicht explizit fordert.

Das hat den Hintergrund, dass dadurch die Analyse viel schneller ist.

Es kann aber sein, dass dann merkwürdige Effekte bei der Analyse
entstehen.

Im Buch Practical Alloy gibt es ein Beispiel dafür, das wir
uns ansehen können:
modules 06.als
*/


