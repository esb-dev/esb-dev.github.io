/*
Module in Alloy, Teil 01

Die Darstellung basiert auf

Julien Brunel, David Chemouil, Alcino Cunha, Nuno Macedo:
Practical Alloy
Abschnitt Module system
*/

/*
Alloy hat ein System für die Modularisierung und Wiederverwendung
von Spezifikationen: das Modulsystem von Alloy.
*/

/*
Wie deklariert und wie verwendet man ein Modul?

Man gibt einem Modul einen Namen mit dem Schlüsselwort
`module`. Um ihn in einer anderen Spezifikation zu verwenden,
wird er dort mit `open` einbezogen.

module und open müssen am Anfang der Datei stehen, vor jeder 
anderen Deklaration.

Beim open wird nach dem Namen der Datei gesucht, man sollte also 
die Datei entsprechend benennen.

Nach dem open werden alle Definitionen des Moduls in die
Datei inkludiert, mit Ausnahem von denen, die im Modul als
private deklariert wurden. Um Namenskonflikte zu vermeiden kann man
ein Modul auch per alias beim open mit dem Keyowrd as benennen.
Würden wir in unserem Beispiel mit `open modudles01 as dag` nehmen,
können wir dann die Symbole mit `dag/rootedAt` zum Beispiel verwenden.

Wir machen ein Beispiel:

Unser Dateisystem aus dem zweiten Teil des Kurses ist ein
gerichteter azyklischer Graph. Außerdem hatte er eine eindeutige
Wurzel.
Statt diese Constraints direkt (wie in strukt08.als)
zu formulieren, ist es besser ein Modul dafür zu machen, dann
können wir diese Constraints auch an anderer Stelle verwenden
und unsere Spezifikation wird übersichtlicher.

Machen wir also eine Spezifikation für einen _directed acyclic
graph_, kurz _dag_:
*/

module modules01

pred dag [node : set univ, r : node -> node] {
  all n : node | n not in n.^r
}

pred rootedAt [node : set univ, r : node -> node, root : node] {
  node in root.*r
}

/*
Damit können wir unsere Spezifikation für das Dateisystem umbauen:
siehe modules02.als
*/

