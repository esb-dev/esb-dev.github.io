/*
Module in Alloy, Teil 03

Die Darstellung basiert auf

Julien Brunel, David Chemouil, Alcino Cunha, Nuno Macedo:
Practical Alloy
Abschnitt Module system
*/

/* 
Wir hatten die Definitionen aus dem Modul so verwendet:

fact rooted_dag {
  dag[Object, entries.object]
  rootedAt[Object, entries.object, Root]
}
Dabei geben wir als als ersten Parameter von dag und rootedAt
die Knoten an, die im Graphen vorkommen. 

Deshalb können wir auch beim Einbinden des Moduls ihn gleich
parametrisieren:
*/

open modules03[Object]

abstract sig Object {}
sig File extends Object {}
sig Dir extends Object {
	entries: set Entry
}
one sig Root extends Dir {}

sig Name {}

sig Entry {
	name: one Name,
	object: one Object
}


fact {
	// Ein Entry kann nicht in mehreren Dirs vorkommen
	entries in Dir lone -> Entry
}
fact {
  // Namen von Einträgen in Dirs müssen eindeutig sein
	// d.entries = Einträge in d und name.n = Einträge mit Name n
  all d : Dir, n : Name | lone (d.entries & name.n)
}

fact {
  // Ein Dir kann in höchstens einem Eintrag vorkommen
	// object.d = Einträge, in denen d vorkommt
  all d : Dir | lone object.d
}


fact {
  // Ein Entry gehören zu genau einem Dir
  entries in Dir one -> Entry
}

/*
Bisher:

fact rooted_dag {
  dag[Object, entries.object]
  rootedAt[Object, entries.object, Root]
}

Jetzt:
*/
fact rooted_dag {
  dag[entries.object]
  rootedAt[entries.object, Root]
}


run {}

run {
	some File
	some Dir - Root
} for 4


assert ObjectsAreReachable {
	Object - Root in Root.^(entries.object)
}


check ObjectsAreReachable 
check ObjectsAreReachable for 8

/* 
Wir wollen uns nun einige der vorgegeben Module ansehen.
Besonders interessant: ordering - siehe modules05.als
*/
