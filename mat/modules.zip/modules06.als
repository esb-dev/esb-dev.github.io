/*
Module in Alloy, Teil 06

Die Darstellung basiert auf

Julien Brunel, David Chemouil, Alcino Cunha, Nuno Macedo:
Practical Alloy
Abschnitt The predefined ordering module
*/


open util/ordering[Nat]

abstract sig Nat {}
sig Even, Odd extends Nat {}

/*
Was haben wir hier:
Nat = natürliche Zahlen
Even = gerade Zahlen
Odd = ungerade Zahlen

Die Abstraktion: 
Wir haben nicht 0, 1, 2
sondern first next next of next ... last
*/

fact {
  all n : Even | n.next in Odd
  all n : Odd | n.next in Even
  first in Even
  last in Odd
}

/* Was wird hier verlangt?
Auf eine gerade Zahl folgt eine ungerade
Auf eine ungerade Zahl folgt eine gerade
Die erste Zahl ist gerade
Die letzte Zahl ist ungerade
*/

run example {}
run example {} for 2
/*
Der Lauf im Scope 3 findet kein Modell, es gibt aber eines mit
2 natürlichen Zahlen!

Warum?
Der Scope ist wegen util/ordering exakt 3, als

first (Even) - next of first (Odd) - last (Even)

Mit einer ungeraden Zahl von Zahlen kann die letzte Zahl
niemals ungerade sein.
*/

run example {} for 4

run example {} for 5

/*
Es gibt auch noch das interessante Modul util/sequniv, das
sogar automatisch verwendet wird, wenn man eine Feld einer
Signatur als seq = Sequence deklariert.

Dies wollen wir uns im nächsten Beispiel
modules07.als 
genauer ansehen.
*/
