/*
Relationale Logik in Alloy. Teil 04

Integers in Alloy - speziell das Modul integer

siehe auch
Julien Brunel, David Chemouil, Alcino Cunha, Nuno Macedo:
Practical Alloy
Abschnitt Working with Integers
*/

open util/integer

run {}


/*
Wir probieren ein paar Beispiele
im Evaluator:

add[3, 4]

3.plus[4]
  
3.plus[4].plus[1]

sub[4, 3]

4.sub[3]

analog minus

mul[3, 2]

2.mul[3]

div[5, 3]

rem[1, 4]

negate[2]

signum[-3]

max

next

prev

max[3 + 4]

min[2+ 3 + 4]

larger[3, 4]

smaller[3, 4]

3.eq[4]

4.gt[3]

gte[3, 3]

lt[3, 4]

lte[3, 4]

zero[2.plus[-2]]

neg[3.sub[4]]

nonpos[0]

nonneg[0]

*/

/*
Integer overflow:

5.plus[2]
= 7
5.plus[3]
= -8
*/

/*
Warum ist das so:

Alloy transformiert intern alle Spezifikationen zu Formeln der
Aussagenlogik. Diese kennt keine Integers. Deshalb werden Integers
zu Bitstrings transformiert wobei eine Boolesche Variable jeweils
ein Bit repräsentiert und Operatoren für Integer werden realisiert
durch entsprechende bitweise Operationen.

Die Angabe 
*/

run moreInt {} for 5 Int

/*
erhöht die Zahl der verwendeten Bits von 4 = Default auf 5.

Dieses Vorgehen wird auch Bit-Blasting oder Bitvector-Flattening 
genannt, bei dem arithmetische Operationen durch Bitoperationen wie
Volladierer-Schaltungen oder Multiplizierschaltungen ersetzt werden.

Das erklärt auch, weshalb man Integers vermeiden sollte, denn das
Bit-Blasting ist sehr aufwändig.

Zurück zum Thema Overflow:

Man kann in den Options > Prevent overflows einstellen, dass der
Alloy Analyzer keine Modelle produziert, bei denen ein Overflow
auftreten würde. Aber Achtung: Das kann einen falsche Eindruck
erwecken, denn man sieht die Beispiele nicht mehr, bei denen
durch einen Overflow etwas schief gehen könnte.

Beispiel:
*/
sig file {
	size: one Int
}

check fileSize {
	all f: file | f.size > 8
}
/*
Hier findet der Analyzer kein Gegenbeispiel, obwohl es offensichtlich
kleinere Dateien gibt, weil die 8 nicht durch einen Vektor mit 4 Bits
repräsentiert werden kann.

Setzt man die Option auf: erlaube overflow, dann wird ein
Gegenbeispiel gefunden.

*/
/*
Wenn wir die Textdarstellung des Modells ansehen,
sehen wir, dass es auch einen vordefinierten Typ
String gibt.

Dazu mehr im nächsten Skript rellog05.als
*/
