/*
Fehler in der Spezifikation von Leader election

Die zunächst in der Vorlesung 2024 vorgestellte erste Variante der
Spezifikation hatte einen Fehler: Initiate darf kein overwrite machen, 
sonst wird eventuell die Nachricht mit der höchsten Id überschrieben.

Hier die Verifaktion, die den Fehler aufdeckt.

Dank an Stella Maidorn, die den Fehler entdeckt hat.
*/

open util/ordering[Id]

sig Id {}

sig Node {
	succ: one Node,
	id: one Id,
	var inbox: set Id,
	var outbox: set Id
}

var sig Elected in Node {}

fact Ring {
	all n: Node | Node in n.^succ
}

fact NotEmpty {
	some Node
}

fact IdsUnique {
	all i: Id | lone id.i
}

pred init {
	no inbox   
	no outbox  
	no Elected 
}

pred initiate[n: Node] {
	historically n.id not in n.outbox     
	//outbox' = outbox ++ n -> n.id // falsch
  outbox' = outbox + n -> n.id         
	inbox' = inbox and Elected' = Elected 
}

pred stutter {
	inbox' = inbox
	outbox' = outbox
	Elected' = Elected
}

pred send[n: Node, i: Id] {
	i in n.outbox
	outbox' = outbox - n->i
	inbox'  = inbox  + n.succ->i
	Elected' = Elected
}

pred process[n: Node, i:Id] {
	i in n.inbox
	inbox' = inbox - n->i
	gt[i, n.id] implies outbox' = outbox + n->i
              else outbox' = outbox
	i = n.id implies Elected' = Elected + n
           else Elected' = Elected
}

fact trans {
	init
	always (
		stutter or
		some n: Node | initiate[n] or
		some n: Node, i: Id | send[n, i] or
		some n: Node, i: Id | process[n, i]
	)
} 

pred fairness {
  all n : Node, i : Id {
    (eventually always historically n.id not in n.outbox) 
			implies (always eventually initiate[n])
		(eventually always i in n.outbox)
			implies (always eventually send[n,i])
    (eventually always i in n.inbox) 
      implies (always eventually process[n,i])
  }
}

assert AtLeastOneLeader {
  fairness implies eventually (some Elected)
}

fact {
	#Node > 1
}

check AtLeastOneLeader 


