/*
Verifikation in Alloy, Teil 02

Die Darstellung basiert auf

Julien Brunel, David Chemouil, Alcino Cunha, Nuno Macedo:
Practical Alloy
Abschnitt Protocol design with Alloy
*/

/* 
Es sind zwei Eigenschaften, die wir überprüfen wollen:
1. Es gibt höchstens einen Leader - dies ist eine
   Sicherheitseigenschaft
2. Es wird wirklich auch einen Leader geben - dazu brauchen
   wir Fairness-Eigenschaften.

In diesem Skript untersuchen wir die zweite Frage
*/

/* 
Unsere Spezifikation des Ring-Algorithmus
*/

open util/ordering[Node]

sig Node {
	succ: one Node,
	var inbox: set Node,
}

fact Ring {
	all n: Node | Node in n.^succ
}

fact NotEmpty {
	some Node
}

fun Elected: set Node {
	{ n: Node | n not in n.inbox and once (n in n.inbox) }
}

pred init {
	no inbox   
}

pred initiate[n: Node] {
	historically n not in n.succ.inbox     
	//inbox' = inbox ++ n.succ -> (n.succ.inbox + n) 
	inbox' = inbox + n.succ -> n         
}

pred stutter {
	inbox' = inbox
}

pred process[n: Node, i: Node] { 
	i in n.inbox
	let inbox" = inbox - n->i {
		gt[i, n] implies inbox' = inbox" + n.succ->i
    	          else inbox' = inbox"
	}
}

fact trans {
	init
	always (
		stutter or
		some n: Node | initiate[n] or
		some n, i: Node | process[n, i]
	)
} 

/*
Um Eigenschaften zu verifizieren, formulieren wir sie
als Annahme:

Nun könnte man versucht sein, folgende Eigenschaft zu 
nehmen, um zu prüfen, dass unser Algorithmus immer zur
Wahl eines Leaders führt:
*/

assert AtLeastALeader {
	eventually (some Elected)
}

check AtLeastALeader

/*
Nun bekommen wir sofort ein Gegenbeispiel. Warum?

Da wir einen Stotterschritt im fact trans haben, kann es 
natürlich sein, dass dieser immerzu dran kommt und wir deshalb 
keinen Fortschritt bei der Wahl der Leaders machen.

So geht es also nicht. Aber wie dann?

Hier kommen nun Fairness-Eigenschaften ins Spiel:

Dazu verwendet man folgende temporale Eigenschaften:

eventually always phi - gilt in einem System, wenn es einen
  Zustand gibt, ab dem phi immer wahr ist

always eventually phi - gilt in einem System, wenn in jedem
  Zustand schließlich später phi gilt, d.h. dass phi unendlich
  oft gilt.
*/

/* 
Wie verwendet man nun diese Eigenschaften:

Wir wollen erreichen, dass wenn ein Zustandsübergang möglich ist,
dass er dann auch tatsächlich irgendwann ausgeführt wird.

Dazu müssen wir erreichen, dass gilt

- die Möglichkeit wird nicht immer ausgeschlagen oder
- der Zustandsübergang kann immer wieder stattfinden

Die Möglichkeit des Übergangs wird gerade durch unseren guard
charakterisiert. D.h. wir wollen nicht, dass ab einem bestimmten
Punkt der guard immer wahr bleibt und kein Zustandsübergang 
stattfindet.

Also sieht unser Schema so aus:

not eventually always guard or
eventually always transitionpredicate

äquivalent:

(eventually always guard) implies (always eventually transpred)

Tun wir das:
*/

pred fairness {
  all n : Node, i : Node {
    (eventually always historically n not in n.succ.inbox) 
			implies (always eventually initiate[n])
    (eventually always i in n.inbox) 
      implies (always eventually process[n,i])
  }
}

run withProgress {
	fairness
}

assert AtLeastOneLeader {
  fairness implies eventually (some Elected)
}

check AtLeastOneLeader
// No counterexample bei 10 Schritte

check AtLeastOneLeader for 5 Node, 20 steps
// dauert > 20 Sekunden

/* Man könnte meinen, dass man Gegenbeispiele erzeugen kann, in dem 
   man einfach die Zahl der Schritte so klein wählt, dass kein
	 Leader gewählt werden konnte.
	 Das klappt nicht. Warum?
   Wenn die Zahl der Schritte zu klein ist, dann wird die Fairness-
	 Bedingung falsch (weil kein Fortschritt mehr möglich ist).
*/

/*
Nun mit nuXmv
*/
check AtLeastOneLeader for 4 Node, 1.. steps
// No counterexample nach 27 Sekunden


/* Wir können noch überprüfen, dass der einmal gewählte Leader
   niemals durch einen anderen abgelöst wird.
	 Auch das eine Sicherheitseigenschaft.
*/

assert LeaderStaysLeader {
	always (all n : Elected | always n in Elected)
}

check LeaderStaysLeader for 5 Node, 12 steps
