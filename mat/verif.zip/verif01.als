/*
Verifikation in Alloy, Teil 01

Die Darstellung basiert auf

Julien Brunel, David Chemouil, Alcino Cunha, Nuno Macedo:
Practical Alloy
Abschnitt Protocol design with Alloy
*/

/* 
Es sind zwei Eigenschaften, die wir überprüfen wollen:
1. Es gibt höchstens einen Leader - dies ist eine
   Sicherheitseigenschaft
2. Es wird wirklich auch einen Leader geben - dazu brauchen
   wir Lebendigkeitseigenschaften.

In diesem Skript untersuchen wir die erste Frage
*/

/* 
Unsere Spezifikation des Algorithmus zur Leader Election
*/

open util/ordering[Node]

sig Node {
	succ: one Node,
	var inbox: set Node,
}

fact Ring {
	all n: Node | Node in n.^succ
}

fact NotEmpty {
	some Node
}

fun Elected: set Node {
	{ n: Node | n not in n.inbox and once (n in n.inbox) }
}
pred init {
	no inbox   
}

pred initiate[n: Node] {
	historically n not in n.succ.inbox      
	inbox' = inbox + n.succ -> n        
}

pred stutter {
	inbox' = inbox
}

pred process[n: Node, i: Node] { 
	i in n.inbox
	let inbox" = inbox - n->i {
		gt[i, n] implies inbox' = inbox" + n.succ->i
    	          else inbox' = inbox"
	}
}

fact trans {
	init
	always (
		stutter or
		some n: Node | initiate[n] or
		some n, i: Node | process[n, i]
	)
} 

/*
Um Eigenschaften zu verifizieren, formulieren wir sie
als Annahme:
*/

assert AtMostOneLeader {
	always (lone Elected)
}

/*
Mit dem Kommando check können wir die Annahme überprüfen
*/

check AtMostOneLeader
// sieht korrekt aus

/*
Allerdings hat dieser Check 2 Einschränkungen:
1. Wir haben nur Ringe mit maximal 3 Knoten untersucht
2. Wir haben nur Abläufe mit bis zu 10 Schritten untersucht

Wir können diese Einschränkungen berücksichtigen, indem wir
1. Die Zahl der Knoten erhöhen, aber es wird immer eine
   relativ kleine Zahl sein. Das stört uns aber nicht
   besonders wegen der small scope hypothesis
2. Wir können die Zahl der Schritte für die Analyse erhöhen.
   Wenn wir als Solver einen SAT-Solver nehmen, dann wird es
   immer eine begrenzte Zahl von Schritten sein: bounded
   model checking. Wir können aber auch einen Model Checker wie
   nuXmv einsetzen und damit unbounded model checking machen, also
   beliebig lange Ausführungspfade überprüfen.

Tun wir das mal:
*/

// Bounded
check AtMostOneLeader for 6 Node, 20 steps
// ergibt auch kein Gegenbeispiel

/*
Für unbounded model checking müssen wir den Solver umstellen:
Options > Solver > electrod.nuxmv
*/

check AtMostOneLeader for exactly 5 Node, 1..steps
// ergibt auch kein Gegenbeispiel

/* 
Wir können also davon ausgehen, dass die Sicherheitseigenschaft
erfüllt ist: es wird nie zwei Leader geben.

Aber wird der Algorithmus auch immer dazu führen, dass ein
Leader ausgewählt wird?

Das untersuchen wir im nächsten Skript verif02.als
*/







