/*
Mehr über die Spezifikation von Dynamik in Alloy, Teil 01

Die Darstellung basiert auf

Julien Brunel, David Chemouil, Alcino Cunha, Nuno Macedo:
Practical Alloy
Abschnitt Mutable top-level signatures
*/

/*
Bisher haben wir nur Felder _in_ Signaturen gesehen, deren Wert sich von
Zustand zu Zustand ändern kann.

Man kann dies aber auch bei Signaturen selbst angeben.

In unserem Beispioel der App zum Filesharing hatten wir die Signatur
sig File {
	var shared: set Token
}

Dadurch definieren wir eine Menge von Files, die unabhängig vom 
jeweiligen Zustand des Transitionssystems immer vorhanden sind:
manche werden in einem Zustand verwendet, andere nicht, sie sind quasi 
im Hintergrund einfach vorhandenb, spielen aber im aktuellen Zustand
keine Rolle.

Das können wir aber auch anders spezifizieren: Wir machen die
Signatur File selbst veränderlich und es handelt sich dann nicht mehr
um alle möglichen Files, von denen mancehn hochgeladen sind oder
nicht, sondern um die hochgeladenen Files.
*/

sig Token {}
var sig File {
  var shared : set Token
}
var sig trashed in File {}

/*
Was ist dabei zu beachten:

1. Der Scope für veränderliche Signaturen bezieht sich immer auf den
   kompletten möglichen Ablauf, nicht auf einen einzelnen Zustand.
   Mit dem Scope 3 können wir also maximal 3 unterschiedliche Files
   haben, d.h. haben wir 3 Files hochgeladen, können wir kein weiteres
   hochladen, auch wenn wir dazwischen eines in den Paperkorb gelegt
   haben.
2. Gibt es eine veränderliche Signatur, dann ist das Universum univ
   selbst veränderlich.
*/

/* 
Wir wollen nun die Spezifikation mit diesem neuen Ansatz umbauen:
*/

fact init {
	no File
}

/*
Wir müssen nicht festlegen, dass
no shared
im Initialzustand gilt, weil sich das automatisch ergibt: 
Wenn es keine File gibt, muss ide Relation shared leer sein.
*/

pred empty {
	no trashed' 						// Papierkorb geleert
	File' = File - trashed  // Dateien im Papierkorb tatsächlich weg
  shared' = shared        // frame condition
}

pred upload {
	some f: File' | File' = File + f // neu hochgeladen
  // one File' - File              // ginge auch
  trashed' = trashed              
  shared' = shared
}

pred delete [f : File] {
  f in File - trashed            // guard
  trashed'  = trashed + f        // effect
  shared'   = shared - f->Token  // effect 
  File' = File                   // frame
}

pred restore [f : File] {
  f in trashed            // guard
  trashed'  = trashed - f // effect
  File' = File            // frame
  shared'   = shared      // frame
}

pred share [f : File, t : Token] {
  f in File - trashed               // guard
  historically t not in File.shared // guard
  shared'   = shared + f->t         // effect
  File' = File                      // frame
  trashed'  = trashed               // frame
}

pred download [t : Token] {
  some shared.t                // guard 
  shared'   = shared - File->t // effect
  File' = File                 // frame
  trashed'  = trashed          // frame
}

pred stutter {
  File' = File        
  trashed'  = trashed 
  shared'   = shared  
}

fact transitions {
  always (
    upload or
    (some f : File | delete[f] or restore[f]) or
    (some f : File, t : Token | share[f, t]) or
    (some t : Token | download[t]) or
    empty or
    stutter
  )
}

run example {}

/*
Nun reforumulieren wir noch die Assertions:
*/

/* 
Würden wir einfach unsere bisherige Spezifikation übernehmen
und uploaded durch File ersetzten, ergäbe sich folgendes:

Bisher:
assert restore_undoes_delete {
  all f : File | always (
    delete[f] and after restore[f] implies
    uploaded'' = uploaded and trashed'' = trashed and shared'' = shared
  )
}
check restore_undoes_delete

Jetzt:
assert restore_undoes_delete {
  all f : File | always (
    delete[f] and after restore[f] implies
    File'' = File and trashed'' = trashed and shared'' = shared
  )
}
check restore_undoes_delete

Aber:
all f: File ist jetzt außerhalb eines temporalen Operators, d.h.
die Aussage bezieht sich nur auf den Initialzustand. 
Und da ist sie trivialerweise wahr, denn es gibt ja gar keine Files!

Also müssen wir die Assertion jetzt anders formuzlieren:
*/

assert restore_undoes_delete {
  always all f : File | (
    delete[f] and after restore[f] implies
    File'' = File and trashed'' = trashed and shared'' = shared
  )
}
check restore_undoes_delete

/*
Auch hier finden wir wieder ein Gegenbeispiel, wie in unserer
ursprünglichen Spezifikation.

Beim Holen aus dem Papierkorb ging die Zuordnung des Tokens verloren!
*/

/*
Und die andere Assertion:
*/
assert one_download_per_token {
  all t : Token | always (
    download[t] implies
    after always not download[t]
  )
}
check one_download_per_token
