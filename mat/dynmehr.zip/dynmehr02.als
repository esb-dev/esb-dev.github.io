/*
Mehr über die Spezifikation von Dynamik in Alloy, Teil 02

Die Darstellung basiert auf

Julien Brunel, David Chemouil, Alcino Cunha, Nuno Macedo:
Practical Alloy
Abschnitt Pointwise effects
*/

/*
In diesem Zusatz geht es um den Stil von Sepzifikationen.

Man unterscheidet den rein relationalen Stil, auch _pointfree_
genannt und den _pointwise_n Stil, im Stil der Prädikatenlogik.

Das folgende Beispiel soll den Unterschied erläutern.

pred share [f : File, t : Token] {
  f in uploaded - trashed             // guard
  historically t not in File.shared   // guard
  shared' = shared + f->t             // effect
  uploaded' = uploaded                // frame
  trashed' = trashed                  // frame
}

Die Änderung an der Relation shared wird in einem relationalen
Ausdruck spezifiziert, der angibt, wei die komplette Relation
hinterher aussieht: shared' = shared + f->t.
Dadurch wird in demselben Ausdruck spezifiziert, was sich an der
Relation ändert (+ f->t) und was gleich bleibt (shared).

Wir sagen nicht explizit, was sich für f ändert und was sich für alle
anderen Dateien nicht ändert. Das könnte man aber so:

pred share [f : File, t : Token] {
  f in uploaded - trashed                  // guard
  historically t not in File.shared        // guard
  f.shared' = f.shared + t                 // effect
  all g : File - f | g.shared' = g.shared  // frame
  uploaded' = uploaded                     // frame
  trashed' = trashed                       // frame
}

In diesem Stil sagen wir explizit, dass sich für f etwas ändert,
nämlich 
	f.shared' = f.shared + t,
und dass sich für alle anderen Files nichts ändert, also
  all g : File - f | g.shared' = g.shared

Beide Formulierung sind äquivalent und es ist eher eine
Geschmacksfrage, was einem besser gefällt.

Ich empfehle aus meiner Sicht: Fre3unden Sie sich mit dem
rein relationalen Stil an. Er erlaubt nicht nur knappere
Formulierungen, sondern entspricht der "Denke", die hinter
der Logik in Alloy steckt.
*/
