/*
Mehr über die Spezifikation von Dynamik in Alloy, Teil 023
Die Darstellung basiert auf

Julien Brunel, David Chemouil, Alcino Cunha, Nuno Macedo:
Practical Alloy
Abschnitt Verifying by induction
*/

/*
Wir laden die Spezifikation unseres Beispiels aus dynam05.als
und verifizieren

assert shared_are_accessible {
  always shared.Token in uploaded - trashed
}
check shared_are_accessible for 10 but 1.. steps

und das dauert ziemlich:

Option Solver changed to electrod.nuxmv
Executing "Check shared_are_accessible for 10 but 1.. steps"
   Actual scopes: 10 Token, 10 File
   Solver=electrod.nuxmv Steps=1..2147483647 Bitwidth=4 MaxSeq=7 SkolemDepth=1 Symmetry=20 Mode=batch
   No translation information available. 3ms.
   No counterexample found. Assertion may be valid. 31658ms.
*/

/* 
Stattdessen können wir Induktion versuchen:

1. Zeige, dass die Eigenschaft im Initialzustand gilt
2. Zeige, dass wenn die Eigenschaft in einem Zustand gilt, dass sie
   dann auch in jedem Folgezustand gilt, durch welches Ereignis er auch
   immer erricht wird.

Um so vorgehen zu können, müssen wir die Spezifikation etwas umbauen:

- wir machen aus dem fact init ein pred
- wir machen aus dem fact transition auch ein pred next
- wir machen ein neues pred traces, das beginnend mit init
  immer next verlangt
*/

sig Token {}
sig File {
  var shared : set Token
}
var sig uploaded in File {}
var sig trashed in uploaded {}

pred init {
  no uploaded
  no shared
}

pred next {
  (some f : File | upload[f] or delete[f] or restore[f]) or
  (some f : File, t : Token | share[f, t]) or
  (some t : Token | download[t]) or
  empty or
  stutter
} 

pred traces {
  init
  always next
}

pred empty {
  no trashed'                    // effect on trashed
  uploaded' = uploaded - trashed // effect on uploaded
  shared'   = shared             // no effect on shared
}

pred upload [f : File] {
  f not in uploaded        // guard
  uploaded' = uploaded + f // effect on uploaded
  trashed'  = trashed      // no effect on trashed
  shared'   = shared       // no effect on shared
}

pred delete [f : File] {
  f in uploaded - trashed       // guard
  trashed'  = trashed + f       // effect on trashed
  shared'   = shared - f->Token // effect on shared
  uploaded' = uploaded          // no effect on uploaded
}

pred restore [f : File] {
  f in trashed            // guard
  trashed'  = trashed - f // effect on trashed
  uploaded' = uploaded    // no effect on uploaded
  shared'   = shared      // no effect on shared
}

pred share [f : File, t : Token] {
  f in uploaded - trashed           // guard
  historically t not in File.shared // guard
  shared'   = shared + f->t         // effect on shared
  uploaded' = uploaded              // no effect on uploaded
  trashed'  = trashed               // no effect on trashed
}

pred download [t : Token] {
  some shared.t                // guard 
  shared'   = shared - File->t // effect on shared
  uploaded' = uploaded         // no effect on uploaded
  trashed'  = trashed          // no effect on trashed
}

pred stutter {
  uploaded' = uploaded // no effect on uploaded
  trashed'  = trashed  // no effect on trashed
  shared'   = shared   // no effect on trashed
}

run example { 
	traces 
}

/*
Nun können wir unsere Assertion umformulieren: 
*/
pred inv_shared_are_accessible {
  shared.Token in uploaded - trashed
}

/*
1. init impliziert die Invariante
   Es reicht ein Schritt!
*/
assert init_inv_shared_are_accessible {
  init implies inv_shared_are_accessible
}
check init_inv_shared_are_accessible for 10 but 1 steps expect 0

/*
2. Wenn die Invariante gilt und next auch, dann gilt
   die Invariante auch im nächsten Schritt
   Hier brauchen wir 2 Schritte
*/ 
assert pres_inv_shared_are_accessible {
  (inv_shared_are_accessible and next) implies
    after inv_shared_are_accessible
}
check pres_inv_shared_are_accessible for 10 but 2 steps expect 0
 
/*
Wir brauchen nur einen Bruchteil der Zeit zur überprüfung.
Das ist Verifikation durch Induktion
*/

/* 
Aber:
Nicht alle Invarianten sind induktiv, deshalb kann man dieses 
Konzept nicht immer anwenden.

Ein Beispiel betrachten wir in dynmehr04.als
*/

