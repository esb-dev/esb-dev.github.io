/*
Mehr über die Spezifikation von Dynamik in Alloy, Teil 023
Die Darstellung basiert auf

Julien Brunel, David Chemouil, Alcino Cunha, Nuno Macedo:
Practical Alloy
Abschnitt Verifying by induction
*/

/*
Wir starten mit der Spezifikation
aus dynmehr03.als
*/
sig Token {}
sig File {
  var shared : set Token
}
var sig uploaded in File {}
var sig trashed in uploaded {}

pred init {
  no uploaded
  no shared
}

pred next {
  (some f : File | upload[f] or delete[f] or restore[f]) or
  (some f : File, t : Token | share[f, t]) or
  (some t : Token | download[t]) or
  empty or
  stutter
} 

pred traces {
  init
  always next
}

pred empty {
  no trashed'                    // effect on trashed
  uploaded' = uploaded - trashed // effect on uploaded
  shared'   = shared             // no effect on shared
}

pred upload [f : File] {
  f not in uploaded        // guard
  uploaded' = uploaded + f // effect on uploaded
  trashed'  = trashed      // no effect on trashed
  shared'   = shared       // no effect on shared
}

pred delete [f : File] {
  f in uploaded - trashed       // guard
  trashed'  = trashed + f       // effect on trashed
  shared'   = shared - f->Token // effect on shared
  uploaded' = uploaded          // no effect on uploaded
}

pred restore [f : File] {
  f in trashed            // guard
  trashed'  = trashed - f // effect on trashed
  uploaded' = uploaded    // no effect on uploaded
  shared'   = shared      // no effect on shared
}

pred share [f : File, t : Token] {
  f in uploaded - trashed           // guard
  historically t not in File.shared // guard
  shared'   = shared + f->t         // effect on shared
  uploaded' = uploaded              // no effect on uploaded
  trashed'  = trashed               // no effect on trashed
}

pred download [t : Token] {
  some shared.t                // guard 
  shared'   = shared - File->t // effect on shared
  uploaded' = uploaded         // no effect on uploaded
  trashed'  = trashed          // no effect on trashed
}

pred stutter {
  uploaded' = uploaded // no effect on uploaded
  trashed'  = trashed  // no effect on trashed
  shared'   = shared   // no effect on trashed
}

run example { 
	traces 
}

pred inv_shared_are_accessible {
  shared.Token in uploaded - trashed
}

assert init_inv_shared_are_accessible {
  init implies inv_shared_are_accessible
}
check init_inv_shared_are_accessible for 10 but 1 steps expect 0

assert pres_inv_shared_are_accessible {
  (inv_shared_are_accessible and next) implies
    after inv_shared_are_accessible
}
check pres_inv_shared_are_accessible for 10 but 2 steps expect 0
 
/*
Wir versuchen nun folgendes:
*/

pred inv_shared_are_uploaded {
  shared.Token in uploaded
}

/*
Dies ist tatsächlich eine Invariante unserer Transitionssystems:
*/
assert shared_are_uploaded {
  traces implies always inv_shared_are_uploaded
}
check shared_are_uploaded for 10 but 1.. steps
/*
Executing "Check shared_are_uploaded for 10 but 1.. steps"
   Actual scopes: 10 Token, 10 File
   Solver=electrod.nuxmv Steps=1..2147483647 Bitwidth=4 MaxSeq=7 SkolemDepth=1 Symmetry=20 Mode=batch
   No translation information available. 0ms.
   No counterexample found. Assertion may be valid. 27459ms.
*/

/*
Wenn wir nun aber den induktiven Ansatz versuchen, erleben 
wir eine Überraschung:
*/

assert init_inv_shared_are_uploaded {
  init implies inv_shared_are_uploaded
}
check init_inv_shared_are_uploaded for 10 but 1 steps

assert pres_inv_shared_are_uploaded {
  (inv_shared_are_uploaded and next) implies
    after inv_shared_are_uploaded
}
check pres_inv_shared_are_uploaded for 10 but 2 steps

/* 
Wir bekommen ein Gegenbeispiel. Woran liegt das?
Wir probieren das mit scope 1, damit wir besser sehen können,
was da passiert:
*/

check pres_inv_shared_are_uploaded for 1 but 2 steps

/*
Wenn wir das Beispiel anschauen, sehen wir, dass im
linken Zustand ein File mit Token uploaded ist und im trash.
Die Invariante ist erfüllt.

Im rechten Zustand wurde der Papierkorb geleert, das File ist
also nicht mehr uploaded, hat aber immer noch ein Token.

Aber diese Kombination ist in einem gültigen Ablauf nicht möglich.
Wenn die Aktion delete zutrifft, dann kann das File hinterher im 
Papierkorb gar kein Token mehr haben.

Der induktive Ansatz prüft auch Übergänge, die gar nicht möglich sind,
weil man in den linken Zustand so gar nicht gelangen kann.

Ist auch logisch:
Die Analyse ist deshalb so viel schneller, weil sie bestimmte 
Sachen nicht berücksichtigen muss.

Was lernen wir daraus:

Verifikation per Induktion ist viel schneller, setzt aber voraus,
dass wir induktive Invarianten finden - und dies ist im Allgemeinen
nicht einfach.
*/

/*
Was können wir in unserem konkreten Beispiel tun?

Wir können schauen, ob wir eine stärkere Invariante finden.

Und dies ist tatsächlich der Fall:
 
Wir wissen, das inv_shared_are_accessible gilt. Deshalb können wir
folgendes prüfen:
*/
assert accessible_is_uploaded {
  inv_shared_are_accessible implies inv_shared_are_uploaded
}
check accessible_is_uploaded for 10 but 1 steps

