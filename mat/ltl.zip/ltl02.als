/*
Temporale Operatoren in Alloy, Teil 02
Operatoren, die die Vergangenheit betreffen
*/

/*
Wir bleiben beim Beispiel der Ampeln
*/

let unchanged[r] { (r)' = (r) }

enum Color {Red, Green, Yellow}

one sig Baton {}

abstract sig Lights {
	var color: one Color,
	var inbox: lone Baton
}

one sig L1, L2 extends Lights {}

pred init {
	color = L1 -> Red + L2 -> Red
	inbox = L1 -> Baton
}

pred RG[l: Lights] {
	l.color = Red and Baton in l.inbox
	color' = color ++ l -> Green
	unchanged[inbox]
}

pred GY[l: Lights] {
	l.color = Green and Baton in l.inbox
	color' = color ++ l -> Yellow
	unchanged[inbox]
}

pred YR[l: Lights] {
	l.color = Yellow and Baton in l.inbox
	color' = color ++ l -> Red
	inbox' = (Lights-l) -> Baton
} 

// Visualization
fun green: set Lights {
	{l: Lights | l.color = Green}
}
fun yellow: set Lights {
	{l: Lights | l.color = Yellow}
}
fun red: set Lights {
	{l: Lights | l.color = Red}
}

fact trans {
	init
	always { some l: Lights | RG[l] or GY[l] or YR[l] }
}
 
run {}

/*
Wir bekommen genau ein Modell mit sechs Zuständen, die
zyklisch durchlaufen werden.

Wir können an diesem Beispiel also die temporalen
Operatoren auf einem Pfad beispielhaft anschauen.
*/

/*
before phi gilt in einem Zustand auf einem Pfad, wenn im
vorherigen Zustand phi gilt.
Im Zustand 0 ist before per definitionem false.

before = after^{-1}

Beispiel:
before L1.color = Green

Dies probiert man am besten im Evaluator in den
verschiedenen Zuständen
*/

assert Before1 {
	 before L1.color = Green
}
check Before1
// counterexample found

assert Before2 {
	 after after before L1.color = Green
}
check Before2
// no counterexample found

/*
historically phi gilt in einem Zustand auf einem Pfad, wenn 
phi in allen vorherigen Schritten wahr ist.

historically = always^{-1}

Beispiel:
historically (L1.color != Green or L2.color != Green)

gilt in allen Zuständen
*/

assert Security {
	always historically (L1.color != Green or L2.color != Green)
}
check Security
// no counterexample found

/*
once phi gilt in einem Zustand auf einem Pfad, wenn phi 
in einem früheren (<=) Zustand galt.

once = eventually^{-1}

Beispiel:
once L1.color = Green

Gilt nicht in Zustand 0
Gilt in allen folgenden Zuständen
*/

assert Once {
	after always once L1.color = Green
}
check Once
// no counterexample found

/* 
phi since psi gilt in einem Zustand auf einem Pfad, 
wenn psi vorher mal galt und ab dann phi bis jetzt gilt.

since = until^{-1}

Beispiel:
L1.color = Yellow since L1.color = Green
ist wahr in Zustand 1 und 2
*/

/*
phi triggered psi gilt in einem Zustand auf einem Pfad, wenn
phi in einem vorherigen Zustand gilt und ab dann psi bis jetzt oder
phi gilt niemals vorher, aber immer psi.

triggered = releases^{-1}

Beispiel:
L1.color = Red triggered L2.color = Green

wird in Zustand 4 wahr

*/

/*
Bisher haben wir einen einzelnen Pfad angesehen.
Aber es kann ja sein, dass unser spezifiziertes System
mehrere Ausführungspfade hat.

Dies betrachten wir im Skript ltl03.als
*/
