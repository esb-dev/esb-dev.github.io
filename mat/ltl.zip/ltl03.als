/*
Temporale Operatoren in Alloy, Teil 03
LTL auf Kripke-Strukturen
*/

/*
Wir bleiben beim Beispiel der Ampeln. Aber wir
nehmen einen Stotterschritt dazu, so dass es mehrere
mögliche Ausführungspfade gibt.
*/

let unchanged[r] { (r)' = (r) }

enum Color {Red, Green, Yellow}

one sig Baton {}

abstract sig Lights {
	var color: one Color,
	var inbox: lone Baton
}

one sig L1, L2 extends Lights {}

pred stutter {
	unchanged[color]
	unchanged[inbox]
}

pred init {
	color = L1 -> Red + L2 -> Red
	inbox = L1 -> Baton
}

pred RG[l: Lights] {
	l.color = Red and Baton in l.inbox
	color' = color ++ l -> Green
	unchanged[inbox]
}

pred GY[l: Lights] {
	l.color = Green and Baton in l.inbox
	color' = color ++ l -> Yellow
	unchanged[inbox]
}

pred YR[l: Lights] {
	l.color = Yellow and Baton in l.inbox
	color' = color ++ l -> Red
	inbox' = (Lights-l) -> Baton
} 

// Visualization
fun green: set Lights {
	{l: Lights | l.color = Green}
}
fun yellow: set Lights {
	{l: Lights | l.color = Yellow}
}
fun red: set Lights {
	{l: Lights | l.color = Red}
}

fact trans {
	init
	always { some l: Lights | RG[l] or GY[l] or YR[l] or stutter }
}
 
run {}

/*
Wir bekommen initial ein Modell mit einem Zustand, der sich
immer wiederholt. 
Mit Fork in jedem Zustand können wir die Ampeln laufen lassen.

Wir können an diesem Beispiel die temporalen
Operatoren auf einer Kripke-Struktur beispielhaft anschauen.
Die Formel muss immer auf _allen_ möglichen Pfaden gelten.
*/

/*
Zunächst die Sicherheitseigenschaft, dass niemals beide
Ampeln gleichzeitig grün sind:
*/

assert Security {
	always (L1.color != Green or L2.color != Green)
}

check Security
// no counterexample found

/*
Lebendigkeit

Wir probieren man eventually:
*/

assert LivenessF1 {
	eventually L1.color = Green
}

check LivenessF1
/*
Wir bekommen ein Gegenbeispiel, weil es ja einen
möglichen Pfad gibt, bei dem sich der Zustand der Ampeln
niemals ändert.
*/

assert LivenessF2 {
	not eventually L1.color = Green
}

check LivenessF2
/*
Auch hier gibt es ein Gegenbeispiel, weil es ja Pfade gibt, bei 
denen L1 grün wird.

Wir sehen: In Kripke-Strukturen gilt der Satz vom ausgeschlossenen
Dritten (Tertium non datur) NICHT!
*/

/*
Um Lebendigkeit zu überprüfen, müssen wir sicherstellen,
dass wir einen Fortschritt machen und nicht auf Pfaden landen,
bei denen sich immer derselbe Zustand widerholt.

Dazu verwenden wir LTL-Aussagen der schwachen Fairness:
*/

pred fairness {
	all l: Lights {
		(eventually always l.color = Red and Baton in l.inbox)
			implies (always eventually RG[l])
		(eventually always l.color = Green and Baton in l.inbox)
			implies (always eventually GY[l])
		(eventually always 	l.color = Yellow and Baton in l.inbox)
			implies (always eventually YR[l])
	}
}

run withProgress {
	fairness
}

/* 
Jetzt bekommen wir wieder den Ablauf der Ampel, aber wir können mit
Fork auch einen Stotterschritt einbauen
*/

assert Liveness {
	fairness implies 
		always (eventually L1.color = Green and eventually L2.color = Green)
}

check Liveness for 20 steps
// no counterexample found


/*
Da unsere Spezifikation so gemacht ist, dass der Staffelstab 
kontrolliert, welche Ampel schalten darf, können wir die
Fairness auch kompakter formulieren:
*/

pred fairness" {
	all l: Lights |
		(eventually always Baton in l.inbox)
			implies (always eventually (RG[l] or GY[l] or YR[l]))
}

run withProgress" {
	fairness"
} 

assert Liveness" {
	fairness" implies 
		always (eventually L1.color = Green and eventually L2.color = Green)
}

check Liveness"
// no counterexample found

/*
Damit ist der Teil über die temporale Logik angeschlossen.

Im nächsten Teil sehen wir uns an, wie die Sprache von
Alloy insgesamt aufgebaut ist.
*/

