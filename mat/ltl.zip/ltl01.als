/*
Temporale Operatoren in Alloy, Teil 01
*/

/*
Wir nehmen als Beispiel zwei Ampeln an
einer Baustelle.
*/

let unchanged[r] { (r)' = (r) }

enum Color {Red, Green, Yellow}

one sig Baton {}

abstract sig Lights {
	var color: one Color,
	var inbox: lone Baton
}

one sig L1, L2 extends Lights {}

pred init {
	color = L1 -> Red + L2 -> Red
	inbox = L1 -> Baton
}

pred RG[l: Lights] {
	l.color = Red and Baton in l.inbox
	color' = color ++ l -> Green
	unchanged[inbox]
}

pred GY[l: Lights] {
	l.color = Green and Baton in l.inbox
	color' = color ++ l -> Yellow
	unchanged[inbox]
}

pred YR[l: Lights] {
	l.color = Yellow and Baton in l.inbox
	color' = color ++ l -> Red
	inbox' = (Lights-l) -> Baton
} 

// Visualization
fun green: set Lights {
	{l: Lights | l.color = Green}
}
fun yellow: set Lights {
	{l: Lights | l.color = Yellow}
}
fun red: set Lights {
	{l: Lights | l.color = Red}
}

fact trans {
	init
	always { some l: Lights | RG[l] or GY[l] or YR[l] }
}
 
run {}

/*
Wir bekommen genau ein Modell mit sechs Zuständen, die
zyklisch durchlaufen werden.

Wir können an diesem Beispiel also die temporalen
Operatoren auf einem Pfad beispielhaft anschauen.
*/

/*
always phi gilt auf einem Pfad, wenn ab dem Startpunkt immer
phi gilt.

Beispiel:
Sicherheitseigenschaft: niemals beide Ampeln grün
*/

assert Security1 {
	always not (L1.color = Green and L2.color = Green)
}
check Security1
// no counterexample found

assert Security2 {
	always (not L1.color = Green or not L2.color = Green)
}
check Security2

/*
eventually phi gilt auf einem Pfad, wenn nach endlich vielen
Schritten phi gilt.

Beispiel:
Lebendigkeitseigenschaft: L2 wird mal grün
*/

assert Liveness1 {
	eventually L2.color = Green
}
check Liveness1
// no counterexample found

/*
Beide Ampeln werden immer wieder mal grün
*/
assert Liveness2 {
	always (eventually L2.color = Green and eventually L1.color = Green)
}
check Liveness2
// no counterexample found 

/*
after phi gilt auf einem Pfad, wenn phi im nächsten Zustand gilt.

Beispiel:
Im Zustand No1 ist die Ampel 1 grün
*/

assert After1 {
	after L1.color = Green
}
check After1
// no counterexample found

assert After2 {
	after after L1.color = Yellow
}
check After2

/* 
Man kann solche Aussagen auch im Evaluator ausprobieren.
Dann kann man auch bei bestimmten Zuständen starten.
Tun wir das:

run

Im Zustand 1:

after L1.color = Yellow
//true

im Zustand 2:
after L1.color = Yellow
//false

*/

/* 
phi until psi gilt auf einem Pfad, wenn phi solange gilt,
bis dann psi wahr wird.

Beispiele:
L1 ist erst rot, wird dann grün

*/

assert Until1 {
	L1.color = Red until L1.color = Green
}
check Until1
// no counterexample found

assert Until3 {
	L1.color = Red until L2.color = Green
}
check Until3
// hier gibt es natürlich ein Gegenbeispiel

/*
phi releases psi gilt auf einem Pfad, wenn
psi immer gilt oder
psi gilt bis inklusive zu einem Zustand, in dem phi gilt
d.h. in diesem Zustand wird die Verpflichtung, dass psi
immer gelten soll aufgehoben 

Es gilt
false releases phi. wenn phi immer gilt
und
phi releases psi genau dann, wenn
not (not phi until not psi)
d.h. release ist der zu until duale Operator
*/

assert Releases1 {
 L2.color = Green releases L1.color in Color
}
check Releases1
// no counterexample found

assert Releases2 {
		(L1.color = Green or L1.color = Red) releases L1.color = Red
}
check Releases2

/*
Schließlich betrachten wir noch den Operator ;,
den Sequenzoperator.

phi ; psi entspricht phi and after psi
*/

assert Seqop1 {
	L1.color = Red and after L1.color = Green
}
check Seqop1
// no counterexample found

assert Seqop2 {
	L1.color = Red
	; L1.color = Green
	; L1.color = Yellow
}
check Seqop2
// no counterexample found

/*
Alloy hat außer diesen temporalen Operatoren, die
sich vom aktuellen Zustand aus auf die nachfolgenden
Zustände beziehen auch Operatoren, die sich auf die
Vergangenheit beziehen.

Diese betrachten wir im Skript ltl02.als
*/




 
