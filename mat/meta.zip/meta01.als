/*
Metalevel in Alloy, Teil 01

Die Darstellung basiert auf

Julien Brunel, David Chemouil, Alcino Cunha, Nuno Macedo:
Practical Alloy
Abschnitt meta-capabilities
*/

/*
Wir betrachen folgende Spezifikation:
*/

sig Token {}

sig Attribute {}

sig File {
  attributes : set Attribute,
  var shared : set Token
}

sig Text, Binary extends File {}

sig Link extends File {
  link : one File
}

/*
Der Alloy Analyzer zeigt uns das Metamodell dazu
*/

/*
Normalerweise werden die Metasignaturen nicht von Alloy erzeugt,
wir können es aber erreichen, indem wir sie in einem run referenzieren.

Wir können aber in einem run dafür sorgen, dass die Metasignaturen
erzeugt werden. 
Dabei werden Elemente des Metalevels mit einem Suffix $ bezeichnet.
*/
 
run some_sig {
  some sig$
} 

/* Nun können wir im Evaluator nachsehen, was erzeugt wurde:

sig$            = alle Signaturen
field$          = alle Felder
static$         = alle nichtveränderlichen Elemente
var$            = alle veränderlichen Elemente
File$.fields    = die Felder der Signatur File
Text$.parent    = die Supersignatur der Signatur Text
File$.subfields = die Felder von File und aller Subsignaturen
File$.value     = Alle Atome der Signatur in unserem aktuellen Modell
*/

/*
Wir können den Metalevel verwenden, um bestimmte Eigenschaften
der gesuchten Modelle zu erzwingen:
*/

/*
Hier wird verlangt, dass wir von jeder Signatur mindestens
ein Atom bekommen.
*/
run no_empty_config_sigs {
  all s : sig$ & static$ | some s.value
}

/*
Mit dem Metalevel kann man auch bestimmte Aussagen stark vereinfachen.
Beispiele:
*/

fact init {
  // Initial sind alle veränderlichen Elemente leer
  all v : var$ | no v.value
}

pred stutter {
  all v : var$ | v.value = v.value'
}

run everything_happens {
  all v : var$ | eventually some v.value
}

/*
Probieren Sie dies mal mit dem Beispiel des Dateisystems aus.
siehe meta02.als
*/
