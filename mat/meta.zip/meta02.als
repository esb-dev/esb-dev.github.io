/*
Metalevel in Alloy, Teil 03
*/


sig Token {}
sig File {
  var shared : set Token
}
var sig uploaded in File {}
var sig trashed in uploaded {}

/* bisher
fact init {
  no uploaded
  no shared
}
*/
fact init {
  all v : var$ | no v.value
}

fact transitions {
  always (
    (some f : File | upload[f] or delete[f] or restore[f]) or
    (some f : File, t : Token | share[f, t]) or
    (some t : Token | download[t]) or
    empty or
    stutter
  )
}

pred empty {
  no trashed'                    
  uploaded' = uploaded - trashed 
  shared'   = shared             
}

pred upload [f : File] {
  f not in uploaded        
  uploaded' = uploaded + f 
  trashed'  = trashed      
  shared'   = shared       
}

pred delete [f : File] {
  f in uploaded - trashed      
  trashed'  = trashed + f        
  shared'   = shared - f->Token 
  uploaded' = uploaded          
}

pred restore [f : File] {
  f in trashed            
  trashed'  = trashed - f 
  uploaded' = uploaded    
  shared'   = shared      
}

pred share [f : File, t : Token] {
  f in uploaded - trashed           
  historically t not in File.shared 
  shared'   = shared + f->t         
  uploaded' = uploaded              
  trashed'  = trashed               
}

pred download [t : Token] {
  some shared.t                
  shared'   = shared - File->t 
  uploaded' = uploaded         
  trashed'  = trashed          
}

/* 
Bisher:
pred stutter {
  uploaded' = uploaded 
  trashed'  = trashed  
  shared'   = shared   
}
*/

pred stutter {
  all v : var$ | v.value = v.value'
}

run everything_happens {
  all v : var$ | eventually some v.value
}
