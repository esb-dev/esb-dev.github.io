/*
Spezifikation von Strukturen (statisch) in Alloy am Beispiel 
der Spezifikation eines Dateisystems. Teil 09.

Die Beispiele basieren auf

Julien Brunel, David Chemouil, Alcino Cunha, Nuno Macedo:
Practical Alloy
Abschnitt Structural modeling und
Declaring enumeration signature
*/

/* 
Bisher: 
*/

abstract sig Object {}

sig File extends Object {}

sig Dir extends Object {
	entries: Name -> Object
}

one sig Root extends Dir {}

sig Name {}

fact {
  all d : Dir, n : Name | lone n.(d.entries)
}

fact {
  all d : Dir | lone entries.d
}

fact {
  Name.(Object.entries) = Object - Root
}

fact {
   all d : Dir | d not in d.^{d: Dir, o: Object | some d.entries.o }
}

run {}

run {
	some File
	some Dir - Root
} for 4

assert ObjectsAreReachable {
	Object - Root in Root.^{d: Dir, o: Object | some d.entries.o }
}

check ObjectsAreReachable 

check ObjectsAreReachable for 8

/* 
Wir möchten noch Berechtigungen für den Zugriff auf die Dateien 
in unserem Dateisystem einführen.

In Unix-Systemen ist es üblich, dass wir 
die Benutzerklassen User, Gruppe und Sonstige haben und
die Berechtigungen Lesen, Schreiben und Ausführen.

Diese Berechtigungen könnten wir nun so spezifizieren:

abstract sig Permission {}
one sig Read, Write, Execute extends Permission {}

es geht aber auch einfacher:
*/ 

enum Permission { Read, Write, Execute }

/*
Wir können nun in einer Instanz sehen, dass wir Atome für die 
Berechtigungen haben:
*/

run perm {
	one Object
	#Permission = 3
}

/* 
Wir sehen nicht nur die drei Berechtigungen, sondern auch, dass
sie eine Sequenz bilden.
enum entspricht also nicht exakt dem Muster abstract / one sig,
sondern hat noch eine zusätzliche Eigenschaft, sie haben eine
ordering.

Wir werden später noch über das Modul ordering sprechen.
*/

/* 
Wir können nun mit der Enumeration Permission jedem Object
Berechtigungen für die drei Benutzerklassen zuordnen, 
zum Beispiel so:

abstract sig Object {
  user_permission   : set Permission,
  group_permission  : set Permission,
  others_permission : set Permission
}

Wir wollen dies aber nicht weiter verfolgen.
Wer sich genauer dafür interessiert:
=> Practical Alloy, Abschnitt Enumeration signatures
*/

/* 
Damit ist unsere Einführung in das Design von Strukturen in
Alloy am Beispiel des Dateisystems abgeschlossen.

Im nächsten Abschnitt, werden wir systematisch alle Konstrukte
der relationalen Logik in Alloy kennenlernen. 
*/
