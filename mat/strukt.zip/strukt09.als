/*
Spezifikation von Strukturen (statisch) in Alloy am Beispiel 
der Spezifikation eines Dateisystems. Teil 09.

Die Beispiele basieren auf

Julien Brunel, David Chemouil, Alcino Cunha, Nuno Macedo:
Practical Alloy
Abschnitt Structural modeling und
Higher-arity relations
*/

/* 
Bisher haben wir immer binäre Relationen verwendet. Man kann
in Alloy aber auch n-äre Relationen einsetzen.

Als Beispiel machen wir eine Variante der Spezifikation unseres
Dateisystems mit hard links, bei der eine ternäre Relation
vorkommt. 
*/

abstract sig Object {}

sig File extends Object {}

sig Dir extends Object {
	entries: Name -> Object
}

/*
Dir enthält im Feld entries nun eine Menge von Paaren von
Name und Object. Das bedeutet, dass entries selbst jetzt
eine Teilmenge von Dir -> Name -> Object ist.

Übrigens:
Es gibt ein vorgefertigtes Modul ternary, das den Umgang mit
ternären Relationen vereinfachen kann. 
Man kann es öffen via
File > Open Sample Models > models > util > ternary.als

Wir finden dort Funktionen, die man aus der relationalen
Algebra kennt.
*/

one sig Root extends Dir {}

sig Name {}

fact {
  // Namen von Einträgen in Dirs müssen eindeutig sein
	// d.entries = Paare (Name, Object) in d und 
  // n.(d.entries) = die Menge der Namen n in diesen Paaren
  all d : Dir, n : Name | lone n.(d.entries)
}

fact {
  // Ein Dir kann in höchstens einem anderen Dir enthalten sein
	// entries.d = Einträge, in denen d vorkommt
  all d : Dir | lone entries.d
}

fact {
  // Jedes Object außer Root kommt in einem Eintrag vor
	// Object.entries = alle möglichen Paare (Name, Object)
	// Name.(Object.entries) = Menge der Objekte in diesen Paaren,
	//  also alle in ihnen vorkommenden Objekte 
  Name.(Object.entries) = Object - Root
}

fact {
   // Dirs können sich nicht selbst enthalten, auch kein Zyklus
   all d : Dir | d not in d.^{d: Dir, o: Object | some d.entries.o }
}

run {}

run {
	some File
	some Dir - Root
} for 4

/*
Die Visualisierung kann nun etwas unübersichtlich werden,
deshalb kann man besser die Darstellung der Modelle als Tabellen,
d.h. tabellarische Darstellung der Relationen verwenden.
*/

assert ObjectsAreReachable {
	Object - Root in Root.^{d: Dir, o: Object | some d.entries.o }
}


check ObjectsAreReachable 


check ObjectsAreReachable for 8

/* 
Wir wollen noch ein weiteres Konzept von Alloy kennenlernen:
Enumerationen in struct10.als.
*/ 

