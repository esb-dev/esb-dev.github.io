/*
Spezifikation von Dynamik in Alloy, Teil 03

Die Darstellung basiert auf

Julien Brunel, David Chemouil, Alcino Cunha, Nuno Macedo:
Practicel Alloy
Abschnitt Behavioral modeling
*/

/* 
Bisher + eine kleine Erweiterung `stutter`
*/

sig Token {}
sig File {
  var shared : set Token
}
var sig uploaded in File {}
var sig trashed in uploaded {}

fact init {
  no uploaded
  no shared
}

fact transitions {
  always (
    (some f : File | upload[f] or delete[f] or restore[f]) or
    (some f : File, t : Token | share[f, t]) or
    (some t : Token | download[t]) or
    empty or
    stutter // <= neu
  )
}

pred empty {
  no trashed'                    
  uploaded' = uploaded - trashed 
  shared'   = shared             
}

pred upload [f : File] {
  f not in uploaded        
  uploaded' = uploaded + f 
  trashed'  = trashed      
  shared'   = shared       
}

pred delete [f : File] {
  f in uploaded - trashed      
  trashed'  = trashed + f        
  shared'   = shared - f->Token 
  uploaded' = uploaded          
}

pred restore [f : File] {
  f in trashed            
  trashed'  = trashed - f 
  uploaded' = uploaded    
  shared'   = shared      
}

pred share [f : File, t : Token] {
  f in uploaded - trashed           
  historically t not in File.shared 
  shared'   = shared + f->t         
  uploaded' = uploaded              
  trashed'  = trashed               
}

pred download [t : Token] {
  some shared.t                
  shared'   = shared - File->t 
  uploaded' = uploaded         
  trashed'  = trashed          
}

/* 
Neu:
*/
pred stutter {
  uploaded' = uploaded 
  trashed'  = trashed  
  shared'   = shared   
}

/*
Bei `stutter` ändert sich gar nichts!

Was soll das? Ist dieser Schritt nötig? Ist er nicht eher merkwürdig,
denn dann wäre ja ein Ablauf in dem immer nichst passiert auch korrekt?

Warum baut man in der Regel einen Stotterschritt ein?

1. Wir betrachten immer unendlich viele Schritte im _model checking_,
   d.h. bei einem Endzustand müssen wir erlauben, dass er immer
   wiederholt wird.
2. Wenn wir unser Transitionssytem kombinieren mit einem anderen, müssen
   wir ermöglichen, dass das andere System einen Zustandsübergang macht,
   während unser System sich nicht ändert.
3. Wenn unser System in eine Verklemmung (_dead lock_) laufen sollte,
   müssen wir erlauben, dass es diesen ständig wiederholt. Würden wir das
   nicht erlauben, könnte der _model checker_ den _dead lock_ nicht
   als möglichen Ablauf ermitteln.
*/

/*
Nun können wir Alloy mal mit dieser Spezifikation laufen lassen:
*/

run example {}

/*
Und das einfachste Beispiel, das wir bekommen, ist eines, in dem
gar nichts passiert!

Im nächsten Schritt dynamo04.als wollen wir sehen, wie wir im
Alloy Analyzer interessantere Abläufe sehen können.
*/


