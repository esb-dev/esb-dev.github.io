/*
Spezifikation von Dynamik in Alloy, Teil 02

Die Darstellung basiert auf

Julien Brunel, David Chemouil, Alcino Cunha, Nuno Macedo:
Practical Alloy
Abschnitt Behavioral modeling
*/

/* 
Bisher:
*/

sig Token {}
sig File {
  var shared : set Token
}
var sig uploaded in File {}
var sig trashed in uploaded {}

fact init {
  no uploaded
  no shared
}

fact transitions {
  always (
    (some f : File | upload[f] or delete[f] or restore[f]) or
    (some f : File, t : Token | share[f, t]) or
    (some t : Token | download[t]) or
    empty
  )
}

/*
Wir wollen nun die verschiedenen Übergänge definieren.

Das Konzept dabei ist:

- Wir spezifizieren, unter welcher Bedingung ein Übergang 
  überhaupt stattfinden kann. Man kann zum Beispiel nur eine Datei
	löschen, die hochgeladen wurde, aber nícht im trash ist usw.
  => _guard_
- Dann definieren wir, was sich ändert. Dazu gibt es das Symbol `'``
  den Beistrich, der ein Element der Struktur im Folgezustand
  bezeichnet: uploaded' ist die Menge der hochgeladenen Dateien
  im nächsten Zustand.
  => _effect_
- Und dann vergessen wird nicht auch noch festzulegen, was sich
  nicht ändert.
  => _frame condition_

Wir wenden nun diese Konzept für alle Aktionen an:
*/

pred empty {
  no trashed'                      // effect: trashed' ist leer
  uploaded' = uploaded - trashed   // effect: uploaded' ohne trashed 
  shared' = shared                 // frame: an den Tokens nichts geändert

pred upload [f : File] {
  f not in uploaded          // guard
  uploaded' = uploaded + f   // effect: f in uploaded'
  trashed' = trashed         // frame: kein Effekt auf trashed
  shared' = shared           // frame: kein Effekt auf shared
}

pred delete [f : File] {
  f in uploaded - trashed       // guard
  trashed' = trashed + f        // effect: f in trashed'
  shared' = shared - f->Token   // effect: f kann man nicht mehr downloaden
  uploaded' = uploaded          // frame
}

pred restore [f : File] {
  f in trashed                  // guard
  trashed' = trashed - f        // effect: trashed' ohne f
  uploaded' = uploaded          // frame
  shared' = shared              // frame
}

pred share [f : File, t : Token] {
  f in uploaded - trashed             // guard
  historically t not in File.shared   // guard
  shared' = shared + f->t             // effect: shared' hat f->t
  uploaded' = uploaded                // frame
  trashed' = trashed                  // frame
}

/*
Bei der Definition von `shared` verwenden wir einen Operator der
temporalen Logik: `historically`.
historically t not in File.shared sagt aus, dass in der
Vergangenheit immer gegolten hat t not in File.shared, d.h.
ein Token kann nur einmal verwendet werden.
(historically ist always in die Vergangenheit) 
*/ 

pred download [t : Token] {
  some shared.t                // guard
  shared' = shared - File->t   // effect: shared' kleiner
  uploaded' = uploaded         // frame
  trashed' = trashed           // frame
}

/*
Jetzt haben wir alle möglichen Aktionen spezifiziert und sind fast
fertig. 
Es gibt aber noch eine Aktion, die wir vorsehen müssen: nämlich dass
gar nichts passiert bei einem Zustandsübergang.

Dies machen wir in dynam03.als
*/
