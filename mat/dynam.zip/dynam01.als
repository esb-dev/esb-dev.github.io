/*
Spezifikation von Dynamik in Alloy 6, Teil 01

Die Darstellung basiert auf

Julien Brunel, David Chemouil, Alcino Cunha, Nuno Macedo:
Practical Alloy
Abschnitt Behavioral modeling
*/

/* 
Die Einführung machen wir am Beispiel einer Webanwendung zum
File sharing.

Das System soll sich so verhalten:

- Man kann Dateien hochladen.
- Andere können solche Dateien herunterladen, vorausgesetzt sie haben
  Zugriff auf ein Token zu einer Datei.
- Ein Token kann  nur einmal verwendet werden.
- Der User, der Dateien hochgeladen hat, kann sie auch löschen.
- Das Löschen geschieht durch Verschieben in einen "Papierkorb", 
  von dem eine Datei auch wiederhergestellt werden kann.
- Der "Papierkorb" wird nach Kommando des Users oder nach einer 
  gewissen Zeit automatisch gelöscht.
*/

/*
Wir haben bisher gesehen, wie man in Alloy Strukturen spezifizieren
kann. Dises sind aber statisch, immutable. 

Jetzt wollen wir Zustandsübergänge spezifizieren können. Wir betrachten
unsere Anwendung als ein Transitionssystem (_transition System_). 
Ein Transitionssystem hat eine bestimmte Struktur, die sich aber über die
Zeit ändern kann. Wir verwenden in Alloy diskrete Transitionssysteme,
d.h. wir haben diskrete Zeitschritte: 
Zeitpunkt 1, Zeitpunkt 2, Zeitpunkt 3 usw.

Jeder Schritt zwischen zwei Zeitpunkt ist eine Transition, ein 
Zustandsübergang.

Das bedeutet:

1. Wir beschreiben die Struktur unseres Systems in seinen Zuständen,
2. Wir definieren, welche Teile der Struktur sich bei einem 
   Zustandsübergang ändern kann.
3. Beginnend mit dem Initialzustand spezifizieren wir, was bei
   einem Zustandsübergang passieren kann.

Wenden wir dieses Konzept auf unser Beispiel an:
*/

sig Token {}
sig File {
  var shared : set Token
}
var sig uploaded in File {}
var sig trashed in uploaded {}

/*
File  = die Menge der Files, die es überhaupt im System gibt
Token = die Menge der Tokens

uploaded = die Teilmenge der Files, die hochgeladen wurden.
  Diese Signatur wird mit dem Schlüsselwort `var`gekennzeichnet,
  was bedeutet, dass sie sich von Zustand zu Zustand ändern kann.
trashed = die Teilmenge der hochgeladenen Files, die im Papierkorb
	sind. Auch diese Teilmenge kann sich zustandsabhängig ändern.

shared = die Relation in File -> Token, die angibt, dass das Token
	zur Datei gehört. Diese Relation kann sich auch ändern, denn wenn
  eine Datei heruntergeladen wird, erlischt das dafür verwendete Token.

Wir abstrahieren vom User, denn es reicht, wenn wir das Verhalten
aus der Sicht eines Unerse beschreiben.

Wir erinnern uns: Konzentration auf das Wesentliche, auf das, was uns
wirkliuch interessert - das vielleicht wichtigste Designprinzip von 
Alloy.
*/

/*
Wie spezifizieren wir nun das Transitionssystem. Die Grundidee besteht
darin, dass wir _temporale Logik_ verwenden, um präzise auszudrücken,
wodurch sich Zustand vorher und Zustand nachher unterscheiden.

Diese Idee wurde von Leslie Lamport in _Temporal Logic of Actions_
(https://lamport.azurewebsites.net/pubs/lamport-actions.pdf) entwickelt
und in seinem Tool TLA+ umgesetzt. Alloy verwendet die Idee von
Leslie Lamport und unterstützt dabei _lineare temporale Logik_, was 
bedeutet, dass das Verhalten des Systems als Pfad (_trace_) gesehen wird, einer 
unendlichen Folge von Zuständen, die einen möglichen Pfad des 
Transitionssystems beschreiben.

Wie geht man vor:
1. Zunächst beschreibt man den initialen Zustand
2. Dann müssen wir spezifizieren, was alles passieren kann
	 bei einem Zstandsübergang
3. Wir dürfen dabei nicht vergessen auch explizit festzulegen,
   was sich _nicht_ ändert (_frame condition_).

Tun wir das:
*/

fact init {
	no uploaded
	no shared
}

/*
Im Initialzustand ist keine Datei hochgeladen und kein Token zugeordnet.
*/

/*
Nun müssen wir überlagen, was alles passieren kann:
*/

fact transitions {
  always (
    (some f : File | upload[f] or delete[f] or restore[f]) or
    (some f : File, t : Token | share[f, t]) or
    (some t : Token | download[t]) or
    empty
  )
}

/*
Hier begegnet uns der erste temporale Operator: `always` = immer =
in allen Zuständen.

Denn was kann in allen Zuständen Passieren?

- Es kann sein, dass eine Datei hochgeladen wird, gelöscht wird oder
  aus dem "Papierkorb" zurückgewholt wird.
- Es kann sein, dass einer Datei ein Token zugeordnet wird.
- Es kann sein, dass ein Token zum Download verwendet wird.
- Oder es kann sein, dass der "Papierkorb" geleert wird.
*/

/*
Wir haben jetzt das Transistionssystem definiert, aber brauchen 
natürlich die Aktionen wie `upload` usw.

Dies machen wir in nächsten Schritt: dynam02.als
*/






 

