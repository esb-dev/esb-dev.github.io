/*
Spezifikation von Dynamik in Alloy, Teil 05

Die Darstellung basiert auf

Julien Brunel, David Chemouil, Alcino Cunha, Nuno Macedo:
Practicel Alloy
Abschnitt Behavioral modeling
*/

/* 
Bisher:
*/

sig Token {}
sig File {
  var shared : set Token
}
var sig uploaded in File {}
var sig trashed in uploaded {}

fact init {
  no uploaded
  no shared
}

fact transitions {
  always (
    (some f : File | upload[f] or delete[f] or restore[f]) or
    (some f : File, t : Token | share[f, t]) or
    (some t : Token | download[t]) or
    empty or
    stutter 
  )
}

pred empty {
  no trashed'                    
  uploaded' = uploaded - trashed 
  shared'   = shared             
}

pred upload [f : File] {
  f not in uploaded        
  uploaded' = uploaded + f 
  trashed'  = trashed      
  shared'   = shared       
}

pred delete [f : File] {
  f in uploaded - trashed      
  trashed'  = trashed + f        
  shared'   = shared - f->Token 
  uploaded' = uploaded          
}

pred restore [f : File] {
  f in trashed            
  trashed'  = trashed - f 
  uploaded' = uploaded    
  shared'   = shared      
}

pred share [f : File, t : Token] {
  f in uploaded - trashed           
  historically t not in File.shared 
  shared'   = shared + f->t         
  uploaded' = uploaded              
  trashed'  = trashed               
}

pred download [t : Token] {
  some shared.t                
  shared'   = shared - File->t 
  uploaded' = uploaded         
  trashed'  = trashed          
}

pred stutter {
  uploaded' = uploaded 
  trashed'  = trashed  
  shared'   = shared   
}

run example {}

/*
Wir überprüfen zunächst einige Invarianten, d.h. Eigenschaften,
die immer erfüllt sein sollen = Sicherheitseigenschaften
*/

/*
Wir erwarten, dass alle Dateien, die heruntergeladen werden können
auch hochgeladen wurden und nicht im "Papierkorb" sind:
*/
assert shared_are_accessible {
  always shared.Token in uploaded - trashed
}
check shared_are_accessible

/*
Wir können den Check mit _bounded model checking_ machen, in dem wir
als Solver einen SAT-Solver auswählen oder _unbounded model checking_,
in dem wir electrod.nuxmv verwenden.
*/

/*
Wir erwarten, dass ein restore ein delete rückgängig macht:
*/ 
assert restore_undoes_delete {
  all f : File | always (
    delete[f] and after restore[f] implies
    uploaded'' = uploaded and trashed'' = trashed and shared'' = shared
  )
}
check restore_undoes_delete

/*
Der Operator after bezeichnet dabei den Zustand im nächsten Schritt.

Anmerkung: In der temporalen Logik heißt dieser Operator üblicherweise
`next`. Da in vielen Alloy-Spezifikationen next aber für das nächste
Element einer georndeten Liste verwendet wird, heißt der temporale
Operator in Alloy `after`.

Wenn wir den check durchführen, erhalten wir ein Gegenbeispiel.
Wir analysieren das Gegenbeispiel:

0-1 Das File wird im ersten Schritt hochgeladen
1-2 Das File bekommt ein Token
2-3 Das File wird in den Papierkorb gelegt
3-4 Das File wird aus dem Papierkorb zurückgeholt

Aber: es hat sein Token verloren!

Was könnte man tun?
- Wir könnten die Aoosziation zum Token behalten, wenn wir die Datei
  in den Papierkorb legen
- Wir könnten verbieten, dass man Dateien mit einem zugeordneten Token
	löschen kann

Was zeigt das Beispie:
Alloy hilft "Grenzfälle" zu überprüfen!
*/

/*
Wir erwarten, dass ein Token nur einmal verwendet werden kann:
*/

assert one_download_per_token {
  all t : Token | always (
    download[t] implies
    after always not download[t]
  )
}
check one_download_per_token

/*
Geschachteltes always:
Wenn immer ein Token benutzt wird zum download, dann kann es ab dann
nie wieder benutzt werden.

Man könnte das auch anders lösen:
*/

fun downloaded [t : Token] : set File {
  { f : File | once (t in f.shared and download[t]) }
}

assert one_download_per_token_2 {
  all t : Token | always lone downloaded[t]
}
check one_download_per_token_2

/*
Wir erwarten, dass man nach dem Löschen eines Files es erst wieder
löschen kann, wenn es aus den Papierkorb geholt wurde oder erneut
hochgeladen wurde:
*/

assert empty_after_restore {
  all f : File | always (
    delete[f] implies
    after ((restore[f] or upload[f]) releases not delete[f])
  )
}
check empty_after_restore

/*
Was genau bedeutet 
	(restore[f] or upload[f]) releases not delete[f]?

not delete[f] wird erst falsch, wenn (restore[f] or upload[f]) 
eingetreten ist.

Wir werden gleich im nächsaten Abschnitt die temporalen Operatoren
systematisch ansehen!
*/

/* 
Bisher haben wir Invarianten angesehen, also Sicherheitseigenschaften.
Nun noch Beispiele zu Lebendigkeitseigenschaften:
*/

assert non_restored_files_will_disappear {
  all f : File | always (
    delete[f] and after always not restore[f] implies
    eventually f not in uploaded
  )
}
check non_restored_files_will_disappear

/*
Wir bekommen ein Gegenbeispiel, weil wir nichts darüber sepzifiziert
haben, dass keine weiteren Aktionen stattfinden müssen.

Úm das zu erreichen, brauchen wir Fairnesseigenschaften, die sicherstellen,
dass andere Aktionen auch irgendwann drankommen.
*/

pred fairness_on_empty {
  always eventually empty
}

assert non_restored_files_will_disappear_2 {
	fairness_on_empty =>
  all f : File | always (
    delete[f] and after always not restore[f] implies
    eventually f not in uploaded
  )
}
check non_restored_files_will_disappear_2

/*
Jetzt finden der model checker kein Gegenbeispiel mehr.
*/






