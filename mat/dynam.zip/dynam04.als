/*
Spezifikation von Dynamik in Alloy, Teil 04

Die Darstellung basiert auf

Julien Brunel, David Chemouil, Alcino Cunha, Nuno Macedo:
Practicel Alloy
Abschnitt Behavioral modeling
*/

/* 
Bisher:
*/

sig Token {}
sig File {
  var shared : set Token
}
var sig uploaded in File {}
var sig trashed in uploaded {}

fact init {
  no uploaded
  no shared
}

fact transitions {
  always (
    (some f : File | upload[f] or delete[f] or restore[f]) or
    (some f : File, t : Token | share[f, t]) or
    (some t : Token | download[t]) or
    empty or
    stutter 
  )
}

pred empty {
  no trashed'                    
  uploaded' = uploaded - trashed 
  shared'   = shared             
}

pred upload [f : File] {
  f not in uploaded        
  uploaded' = uploaded + f 
  trashed'  = trashed      
  shared'   = shared       
}

pred delete [f : File] {
  f in uploaded - trashed      
  trashed'  = trashed + f        
  shared'   = shared - f->Token 
  uploaded' = uploaded          
}

pred restore [f : File] {
  f in trashed            
  trashed'  = trashed - f 
  uploaded' = uploaded    
  shared'   = shared      
}

pred share [f : File, t : Token] {
  f in uploaded - trashed           
  historically t not in File.shared 
  shared'   = shared + f->t         
  uploaded' = uploaded              
  trashed'  = trashed               
}

pred download [t : Token] {
  some shared.t                
  shared'   = shared - File->t 
  uploaded' = uploaded         
  trashed'  = trashed          
}

pred stutter {
  uploaded' = uploaded 
  trashed'  = trashed  
  shared'   = shared   
}

run example {}


/*
Wie können wir interessante Abläufe sehen.

Lernen wir erstmal die Möglichkeiten im Analyzer kennen:

-> oder <- 

Damit gehen wir im aktuellen Ablauf einen Zeitschrit vor oder zurück.
Oben wird angezeigt, wo wir gerade sind und der aktuelle Zustand wird 
links angezeigt und der nächste Zustand rechts.

New Config (Cmd-C):

Die Konfiguration ist das Modell für die unveränderlichen Mengen und
Relationen unserer Spezikation.

In unserem Beispiel sind das Token und File. D.h. New Config stellt uns
eine neue Konfiguration an Dateien und Tokens bereit mit denen wir Abläufe
starten können. (Hierzu wird das _model finding_ von Alloy verwendet)

New Trace (Cmd-T)

Ein anderer Ablauf mit derselben Konfiguration.

New Init (Cmd-I)

Ein neuer Initialzustand. In unserem Beispiel bringt diese Option nichts,
denn wir haben nur einen möglichen Initialzustand

New Fork (Cmd-F)

Lässt den bsiherigen Ablauf unverändert, aber macht einen anderen möglichen 
Übergang zum nächsten Zustand.

*/

/* 
wir wollen nun einfach mit diesen Möglichkeiten spielen

Am ehesten sieht man verschiedene Abläufe, wenn man eine interssante
Konfiguration nimmt und dann mit New Fork die möglichen Pfade erkundet.

Offensichtlich ist das nur schwierig systematisch zu machen.
Deshalb sollen wir besser den _model checker_ einsetzen, um Eigenschaften
von Abläufen zu verifizieren.

Siehe dynam05.als
*/
