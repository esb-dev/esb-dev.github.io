/*
Der Ring-Leader-Algorithmus, Teil 06

Die Darstellung basiert auf

Julien Brunel, David Chemouil, Alcino Cunha, Nuno Macedo:
Practical Alloy
Abschnitt Protocol design with Alloy
*/

/* 
Wir wollen nun die outbox weglassen:
*/

open util/ordering[Node]

sig Node {
	succ: one Node,
	var inbox: set Node,
}

var sig Elected in Node {}

fact Ring {
	all n: Node | Node in n.^succ
}

fact NotEmpty {
	some Node
}

/* 
Ausgangszustand:
*/
pred init {
	no inbox   // Posteingang leer
	no Elected // Kein Knoten bislang gewählt
}

/*
Initialisierung:

Da wir nun keine outbox mehr haben, müssen wir als
guard spezifizieren, dass unser Knoten noch nichts
an seinen Nachfolger geschickt hatte.
*/

pred initiate[n: Node] {
	historically n not in n.succ.inbox             // guard
	inbox' = inbox + n.succ -> (n.succ.inbox + n)  // effect
	Elected' = Elected                             // frame condition
}

pred stutter {
	inbox' = inbox
	Elected' = Elected
}

/*
Das Prädikat send fällt ganz weg, es bleibt nur
process.
Nun müssen wir aber aufpassen:
In einem Schritt ändert sich sowohl die
inbox des aktuellen Knotens wie seines Nachfolgers!
*/

pred process[n: Node, i: Node] {
	i in n.inbox 	                                  // guard
	let inbox_t = inbox - n->i {
		gt[i, n] implies inbox' = inbox_t + n.succ->i
    	          else inbox' = inbox_t
		i = n implies Elected' = Elected + n
    	       else Elected' = Elected
	}                                              // effects
}

/*
Nun können wir die Effekte der Spezifikation inspizieren
*/

pred trans {
	init
	always (
		stutter or
		some n: Node | initiate[n] or
		some n, i: Node | process[n, i]
	)
} 

run {
	trans
}

run example {
	trans
	eventually some Elected
} for exactly 4 Node

/*
Wir können noch mehr vereinfachen:

Man kann die Teilmenge Elected weglassen und durch
eine Funktion ersetzen - ring07.als
*/
             






