/*
Spezifikation von Dynamik in Alloy, Teil 04

Die Darstellung basiert auf

Julien Brunel, David Chemouil, Alcino Cunha, Nuno Macedo:
Practical Alloy
Abschnitt Protocol design with Alloy
*/

/* 
Wir wollen nun die Prädikate definieren, die den
Algorithmus spezifizieren:

Die Idee besteht darin, dass wir für jeden möglichen Schritt
des Algorithmus angeben:
1. unter welchen Umständen er stattfindet (guard, 
   aka enabling condition)
2. wie die Konfiguration im Folgezustand sich aus den
   bisherigen Gegebenheiten ergibt (effect)
3. was sich nicht ändert (frame condition)

In unserem konkreten Beispiel handelt es sich um drei
mögliche Schritte:
- Ein Knoten initiiert den Algorithmus, indem er seine
  Id an seinen Nachfolger sendet
- Ein Knoten liest eine Id aus seiner inbox und verarbeitet sie,
	d.h. ignoriert sie oder sendet sie weiter oder wird Leader
- Das Netzwerk sendet die Nachrichten in outboxes in die
	inboxes der Nachfolger

Tun wir das.
*/

open util/ordering[Id]

sig Id {}

sig Node {
	succ: one Node,
	id: one Id,
	var inbox: set Id,
	var outbox: set Id
}

var sig Elected in Node {}

fact Ring {
	all n: Node | Node in n.^succ
}

fact NotEmpty {
	some Node
}

fact IdsUnique {
	all i: Id | lone id.i
}

/* 
Ausgangszustand:
*/
pred init {
	no inbox   // Posteingang leer
	no outbox  // Postausgang leer
	no Elected // Kein Knoten bislang gewählt
}


/*
Initialisierung:

Neu ist der temporale Operator historically.
Er hat folgende Semantik:

historically phi ist wahr, wenn phi in der Vergangenheit
bis inklusive des aktuellen Zustands wahr war.  
*/

pred initiate[n: Node] {
	historically n.id not in n.outbox      // guard
	outbox' = outbox + n -> n.id           // effect
	inbox' = inbox and Elected' = Elected  // frame condition
}

run {
	init
	always (some n: Node | initiate[n]) 
}

/*
Wir bekommen kein Modell. Warum?

Nachdem jeder Knoten initiate gemacht hat, kann nichts
mehr passieren, weil wir ja keine weitere Möglichkeit
spezifiziert haben. Die erfüllenden Ausführungspfade sollen
aber unendlich sein, es muss also immer noch weitergehen.

Das regeln wir, indem wir einen sogenannten Stotterschritt
vorsehen. Ein Schritt, in dem alle Relationen gleich bleiben:
*/

pred stutter {
	inbox' = inbox
	outbox' = outbox
	Elected' = Elected
}

run {
	init
	always (stutter or some n: Node | initiate[n])
}

/* 
Nun können wir verschiedene Ausführungspfade inspizieren, mit
New Trace oder New Fork.
*/

/* 
Wir müssen noch die anderen beiden Möglichkeiten spezifizieren:
*/

pred send[n: Node, i: Id] {
	// guard
	i in n.outbox
	// effects
	outbox' = outbox - n->i
	inbox'  = inbox  + n.succ->i
	// frame condition
	Elected' = Elected
}

pred process[n: Node, i:Id] {
	// guard
	i in n.inbox
	// effects
	inbox' = inbox - n->i
	gt[i, n.id] implies outbox' = outbox + n->i
              else outbox' = outbox
	i = n.id implies Elected' = Elected + n
           else Elected' = Elected
}

/*
Nun können wir die Effekte der Spezifikation inspizieren
*/

pred trans {
	init
	always (
		stutter or
		some n: Node | initiate[n] or
		some n: Node, i: Id | send[n, i] or
		some n: Node, i: Id | process[n, i]
	)
} 

run {
	trans
}

/*
Dadurch, dass wir den Schritt stutter haben, ist es schwer 
durch New Fork es hinzukriegen, dass wir tatsächlich einen
Leader bekommen.

Wir können das durch ein zusätzliche Bedingung erzwingen:
*/

run example {
	trans
	eventually Elected
} for exactly 3 Node, exactly 3 Id

/*
eventually ist auch ein temporaler Operator, der aussagt,
dass es schließlich - also nach endlich vielen Schritten -
einen Leader gibt.

Wir sehen also, dass es Modelle gibt, wo wir einen Leader
bekommen. 

Nebenbei: Alloy wird immer einen Ausführungspfad zuerst 
anzeigen, bei dem die wenigsten Schritte benötigt werden,
um die Bedingung für eventually zu erreichen.

Aber:
Es könnte sein, dass unsere Spezifikation jedoch auch Fehler
enthält, die wir so nie sehen könnten, weil wir ja nur jene
Modell zu sehen bekommen, bei denen es einen Leader gibt.

Für die Verifikation unseres Algorithmus werden wir also anders
vorgehen müssen.

Doch bevor wir das tun, werden wir im nächsten Skript 
die Spezifikation vereinfachen - dynam05.als
*/
           






