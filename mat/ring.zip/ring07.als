/*
Spezifikation von Dynamik in Alloy, Teil 07

Die Darstellung basiert auf

Julien Brunel, David Chemouil, Alcino Cunha, Nuno Macedo:
Practical Alloy
Abschnitt Protocol design with Alloy
*/

/* 
Wir wollen Elected durch eine Funktion ersetzen:
*/

open util/ordering[Node]

sig Node {
	succ: one Node,
	var inbox: set Node,
}

fact Ring {
	all n: Node | Node in n.^succ
}

fact NotEmpty {
	some Node
}

fun Elected: set Node {
	{ n: Node | n not in n.inbox and once (n in n.inbox) }
}
/* 
Was passiert da?

Die Funktion Elected ermittelt eine Menge von Knoten und zwar
die Konten, die 
- nicht sich selbst in ihrem Posteingang haben und
- sich selbst aber irgendwann mal vorher dort hatten (once).

Der Knoten mit der höchsten Id ist der einzige, der seine
eigene Id geschickt bekommt. Wenn er sie erhalten hat, dann
ist er gewählt, hat sie aber nicht mehr im Posteingang
*/

/* 
Ausgangszustand:
*/
pred init {
	no inbox   // Posteingang leer
}

/*
Initialisierung:

Da wir nun keine outbox mehr haben, müssen wir als
guard spezifizieren, dass unser Knoten noch nichts
an seinen Nachfolger geschickt hatte.
*/

pred initiate[n: Node] {
	historically n not in n.succ.inbox             // guard
	inbox' = inbox ++ n.succ -> (n.succ.inbox + n) // effect
}

pred stutter {
	inbox' = inbox
}

pred process[n: Node, i: Node] {
	// guard
	i in n.inbox
	// effects and frame condition
	let inbox" = inbox - n->i {
		gt[i, n] implies inbox' = inbox" + n.succ->i
    	          else inbox' = inbox"
	}
}

/*
Nun können wir die Effekte der Spezifikation inspizieren
*/

pred trans {
	init
	always (
		stutter or
		some n: Node | initiate[n] or
		some n, i: Node | process[n, i]
	)
} 

run {
	trans
}

run example {
	trans
	eventually some Elected
} for exactly 4 Node

/*
Wir werden diese Spezifikation verwenden,
um Eigenschaften des Systems zu verifizieren.

Weiter mit verif01.als
*/
             






