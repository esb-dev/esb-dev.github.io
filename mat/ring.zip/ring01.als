/*
Der Ring-Leader-Algorithmus, Teil 01

Die Darstellung basiert auf

Julien Brunel, David Chemouil, Alcino Cunha, Nuno Macedo:
Practical Alloy
Abschnitt Protocol design with Alloy
*/

/* 
Beispiel eines verteilten
Algorithmus, der Wahl eines Leaders, den Ringalgorithmus:

In einem verteilten System von Prozessen, die als Ring organisiert 
sind, geht es darum einen Prozess zu ermitteln, der eine dezidierte
Aufgabe = Leader hat. 

In der angelsächsischen Literatur wird das als _leader election_
bezeichnet.  

Dabei sollen alle Prozesse eine eindeutige Id haben und es geht darum,
dass alle in einem Ring organisierten Prozesse am Ende den Prozess 
mit der höchsten Id kennen.

Der Algorithmus geht so:
Jeder Knoten sendet seine Id in Uhrzeigerrichtung. Ein Knoten,
der eine Id erhält, sendet sie nur weiter, wenn sie größer ist
als seine eigene. Ein Knoten, der seine eigene Id zurückbekommt,
ist der Leader. Er sendet dann seine Id an alle anderen Knoten.
(Diesen letzten Schritt werden wir nicht spezifizieren, es reicht
uns die vorherigen Schritte zu spezifizieren und zu verifizieren,
dass wir einen und genau einen Leader finden.)

Wir beginnen mit der statischen Struktur:
*/

sig Node {
	succ: one Node
}

/* 
Dies ergibt natürlich noch keinen Ring. Zwar hat jeder Knoten
genau einen Nachfolger, das könnte er aber selbst sein. Bei
mehr als einem Knoten ergäbe das dann keinen Ring.

Also müssen wir sicherstellen, dass wir wirklich einen
Ring bekommen:
*/

fact Ring {
	all n: Node | Node in n.^succ
}

/*
Außerdem wollen wir sicherstellen, dass es mindestens
einen Prozess = Knoten gibt:
*/

fact NotEmpty {
	some Node
}


/*
Jetzt schauen wir uns mal die zu unserer bisherigen
Spezifikation generierten Modelle an:
*/

run {} for 4 Node

/*
Wir bekommen genau vier Ringe
*/

/*
Die Prozesse sollen Ids haben. Dies machen wir
im nächsten Skript ring02.als.
*/
