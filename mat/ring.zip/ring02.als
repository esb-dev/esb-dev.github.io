/*
Der Ring-Leader-Algorithmus, Teil 02

Die Darstellung basiert auf

Julien Brunel, David Chemouil, Alcino Cunha, Nuno Macedo:
Practical Alloy
Abschnitt Protocol design with Alloy
*/

/* 
Wir wollen nun die Ids einführen. Sie sollen eine
totale Ordnung haben.

Dazu verwenden wir Modul util/ordering - und zwar so:
*/

open util/ordering[Id]

sig Id {}

sig Node {
	succ: one Node,
	id: one Id
}

fact Ring {
	all n: Node | Node in n.^succ
}

fact NotEmpty {
	some Node
}

fact IdsUnique {
	id in Node one -> one Id
	/*
	all i: Id | lone id.i
	#Node = #Id
	*/
}


run {}

/*
Es wird ein Ring mit 3 Knoten und 3 Ids generiert.

Warum nicht auch einer mit 2 Knoten und 2 Ids?
Das Modul util/ordering wird intern im Analyzer
speziell behandelt. So werden zum Beispiel immer die
gesamte Anzahl (hier also 3) von geordneten Objekten
erzeugt, wir haben also hier immer 3 Ids. Die
Bedingung #Node = #Id führt folglich dazu, dass wir auch
genau 3 Knoten bekommen.

In util/ordering ist auch die Relation next definiert,
die in der Visualisierung nicht angezeigt wird. Auch dies ist
Sonderbehandlung: die Ordnung ergibt sich aus der Nummerierung
der Ids. Wir können das im Evaluator nachsehen:

ordering/next
ordering/prev
ordering/next = ~ordering/prev
first
last
lt[Id$0, Id$1]
gt[Id$0, Id$1]
 
*/

/* 
Im Folgenden wollen wir nun die Eigenschaften hinzufügen,
deren Konstellation sich von Zustand zu Zustand ändern
kann. Dies beginnen wir in ring03.als.
*/
