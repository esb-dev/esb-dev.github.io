/*
Spezifikation von Dynamik in Alloy, Teil 03

Die Darstellung basiert auf

Julien Brunel, David Chemouil, Alcino Cunha, Nuno Macedo:
Practical Alloy
Abschnitt Protocol design with Alloy
*/

/* 
Wir erweitern die Signatur Node um Felder, deren
Konfiguration sich von Zustand zu Zustand ändern kann.
*/

open util/ordering[Id]

sig Id {}

/*
Posteingang und Postausgang verwenden wir zur
Kommunikation zwischen den Knoten. 

(Anders als etwa PROMELA, die Sprache von SPIN, die
das Konzept von Channels zur Kommunikation von Prozessen
hat, gibt es in Alloy kein vordefiniertes Konzept für die
Kommunikation.)
*/

sig Node {
	succ: one Node,
	id: one Id,
	var inbox: set Id,
	var outbox: set Id
}

/*
Außerdem wollen wir eine Teilmenge von Node einführen,
die später den (oder die) Leader enthalten soll:
*/

var sig Elected in Node {}


fact Ring {
	all n: Node | Node in n.^succ
}

fact NotEmpty {
	some Node
}

fact IdsUnique {
	all i: Id | lone id.i
}


run {} 

/* 
In der Visualisierung sehen wir nun einen möglichen
Ausführungspfad (Trace) und die beiden ersten Zustände
darunter.

Wir passen die Einstellungen der Visualisierung an: Theme
- id, inbox, outbox als Attribute
- Ids nicht als Objekte
- Elected grün

Wir speichern das Thema als dynam.thm
*/

/*
Wenn wir die konstruierten Modelle inspizieren, sehen wir,
dass zum Beispiel im Anfangszustand bereits Nachrichten
in der inbox oder outbox sind und dass bereits ein Knoten 
in Elected ist.

Das kann natürlich nicht sein. Deshalb:
*/

pred init {
	no inbox   // alle Posteingänge leer
	no outbox  // alle Postausgänge leer
	no Elected // Kein Knoten bislang gewählt
}

run {
	init
}

/* 
Nun erhalten wir einen Ausführungspfad, bei dem
immerzu der Initialzustand erhalten bleibt.

Wenn wir New Fork drücken passiert etwas, denn
durch das Prädikat init haben wir nur den ersten
Zustand festgelegt, nicht alle folgenden. Das bedeutet,
dass im folgenden Zustand irgendwas passieren kann.

Anders wäre das bei folgendem run:
*/

run Nop {
	always init
}

/* 
Jetzt gibt es nur einen einzigen möglichen Ausführungspfad,
der der Spezifikation entspricht, nämlich der bei dem immer
der Initialzustand erhalten bleibt.
*/

/*
Wir müssen also spezifizieren, wie sich ein Folgezustand
von seinem vorherigen Zustand unterscheiden kann.

Das tun wir im Skript dynam04.als
*/




