/*
Der Ring-Leader-Algorithmus, Teil 05

Die Darstellung basiert auf

Julien Brunel, David Chemouil, Alcino Cunha, Nuno Macedo:
Practical Alloy
Abschnitt Protocol design with Alloy
*/

/* 
Bisher haben wir die Id eines Prozesses als Feld der
Signatur Node vorgesehen. Dies ist aber für die
Spezifikation gar nicht nötig:

Wir können doch die Id mit dem Prozess selbst identifizieren.

Tun wir das:
*/

open util/ordering[Node]

sig Node {
	succ: one Node,
	var inbox: set Node,
	var outbox: set Node
}

var sig Elected in Node {}

fact Ring {
	all n: Node | Node in n.^succ
}

fact NotEmpty {
	some Node
}

/* 
Ausgangszustand:
*/
pred init {
	no inbox   // Posteingang leer
	no outbox  // Postausgang leer
	no Elected // Kein Knoten bislang gewählt
}

/*
Initialisierung:
*/

pred initiate[n: Node] { 
	historically n not in n.outbox         // guard
	outbox' = outbox + n -> n              // effect
	inbox' = inbox and Elected' = Elected  // frame condition
}

pred stutter {
	inbox' = inbox
	outbox' = outbox
	Elected' = Elected
}

pred send[n: Node, i: Node] {
	i in n.outbox	               // guard
	outbox' = outbox - n->i      // effect
	inbox'  = inbox  + n.succ->i // effect
	Elected' = Elected           // frame condition
}

pred process[n: Node, i: Node] {
	i in n.inbox                              // guard
	inbox' = inbox - n->i                     // effect
	gt[i, n] implies outbox' = outbox + n->i
              else outbox' = outbox         // effect
	i = n implies Elected' = Elected + n
           else Elected' = Elected          // effect
}

/*
Nun können wir die Effekte der Spezifikation inspizieren
*/

pred trans {
	init
	always (
		stutter or
		some n: Node | initiate[n] or
		some n, i: Node | send[n, i] or
		some n, i: Node | process[n, i]
	)
} 

run {
	trans
}

run example {
	trans
	eventually some Elected
} for exactly 3 Node

/*
Wir können noch mehr vereinfachen:

Bisher haben wir inbox und outbox, aber wir könnten
uns doch den Schritt mit der outbox sparen.

Dies tun wir in ring06.als
*/
             






