/*
Kommandos in Alloy, Teil 02

Die Darstellung basiert auf

Julien Brunel, David Chemouil, Alcino Cunha, Nuno Macedo:
Practical Alloy
Abschnitt Commands in detail
*/

/* 
Hier die Spezifikation des Dateisystems:
*/

module filesystem

abstract sig Object {}

sig Dir extends Object {
  entries : set Entry
}

sig File extends Object {}

one sig Root extends Dir {}

sig Entry {
  object : one Object,
  name   : one Name
}

sig Name {}

fact unique_names {
  all d : Dir, n : Name | lone (d.entries & name.n)
}

fact no_shared_dirs {
  all d : Dir | lone object.d
}

fact no_dangling_objects {
  Entry.object = Object - Root
}

fact one_directory_per_entry {
  all e : Entry | one entries.e
}

fun descendants [o : Object] : set Object {
  o.^(entries.object)
}

pred reachable [o : Object] {
  o in Root + descendants[Root]
}

fact no_indirect_containment {
  all d : Dir | d not in descendants[d]
}

pred depth2 {
  some Root.entries.object.entries.object
}

/*
Wir wollen sehen, wie wir in Alloy den Scope einstellen können:
*/


// Modelle mit Scope 3 = bis zu 3 Elemente pro Top-Signatur
run {}

// Exakt 3 Object und 3 Entry
run scope_4_3 {} for 4 but exactly 3 Object, exactly 3 Entry

// aber höchstens 2 Name
run names_2 {} for 3 but 2 Name

// Scope of 3, aber höchstens 3 Verzeichnisse and 3 Dateien
// Ergibt maximal 6 Objekte
run files_3_dirs_3 {} for 3 but 3 Dir, 3 File

// Es soll mindestens ein File geben und 3 Verzeichnisse 
run dirs_3 { some File } for 3 but exactly 3 Dir
// Warum wird kein Modell gerunden?
run dirs_4 { some File } for 4 but exactly 3 Dir


/*
Wir können auch angeben, welches Ergebnis wir erwarten:
*/
pred no_self_containment {
   all d : Dir | d not in d.entries.object
}

pred no_indirect_containment {
  all d : Dir | d not in descendants[d]
}

pred no_partitions {
  all o : Object | reachable[o]
}

// hier erwarten wir ein Gegenbeispiel
check bad_containment {
  no_self_containment implies no_partitions
} for 6 expect 1

// hier erwarten wir, dass es kein Gegenbeispiel gibt
check good_containment {
  no_indirect_containment implies no_partitions
} for 6 expect 0
