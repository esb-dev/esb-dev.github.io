/*
Kommandos in Alloy, Teil 03

Die Darstellung basiert auf

Julien Brunel, David Chemouil, Alcino Cunha, Nuno Macedo:
Practical Alloy
Abschnitt Commands in detail
*/

/* 
Hier die Spezifikation des Dateisystems:
*/

module filesystem

abstract sig Object {}

sig Dir extends Object {
  entries : set Entry
}

sig File extends Object {}

one sig Root extends Dir {}

sig Entry {
  object : one Object,
  name   : one Name
}

sig Name {}

fact unique_names {
  all d : Dir, n : Name | lone (d.entries & name.n)
}

fact no_shared_dirs {
  all d : Dir | lone object.d
}

fact no_dangling_objects {
  Entry.object = Object - Root
}

fact one_directory_per_entry {
  all e : Entry | one entries.e
}

fun descendants [o : Object] : set Object {
  o.^(entries.object)
}

pred reachable [o : Object] {
  o in Root + descendants[Root]
}

/*
Wir können auch angeben, welches Ergebnis wir erwarten:
*/
pred no_self_containment {
   all d : Dir | d not in d.entries.object
}

pred no_indirect_containment {
  all d : Dir | d not in descendants[d]
}

pred no_partitions {
  all o : Object | reachable[o]
}

// hier erwarten wir ein Gegenbeispiel
check bad_containment {
  no_self_containment implies no_partitions
} for 6 expect 1

// hier erwarten wir, dass es kein Gegenbeispiel gibt
check good_containment {
  no_indirect_containment implies no_partitions
} for 6 expect 0
