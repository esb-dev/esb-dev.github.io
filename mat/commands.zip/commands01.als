/*
Kommandos in Alloy, Teil 01

Die Darstellung basiert auf

Julien Brunel, David Chemouil, Alcino Cunha, Nuno Macedo:
Practical Alloy
Abschnitt Commands in detail
*/

/* 
Hier die Spezifikation des Dateisystems:
*/

module filesystem

abstract sig Object {}

sig Dir extends Object {
  entries : set Entry
}

sig File extends Object {}

one sig Root extends Dir {}

sig Entry {
  object : one Object,
  name   : one Name
}

sig Name {}

fact unique_names {
  all d : Dir, n : Name | lone (d.entries & name.n)
}

fact no_shared_dirs {
  all d : Dir | lone object.d
}

fact no_dangling_objects {
  Entry.object = Object - Root
}

fact one_directory_per_entry {
  all e : Entry | one entries.e
}

fun descendants [o : Object] : set Object {
  o.^(entries.object)
}

pred reachable [o : Object] {
  o in Root + descendants[Root]
}

fact no_indirect_containment {
  all d : Dir | d not in descendants[d]
}

pred depth2 {
  some Root.entries.object.entries.object
}

/*
run erzeugt Modelle, die der Spezifikation entsprechen:
*/

// Modelle mit bis zu 3 Elementen der Top-Signaturen
run example {}
// Modelle mit bis zu 4 Elementen der Top-Signaturen
run example {} for 4
// Modelle mit bis zu 4 Elementen der Top-Signaturen, aber keine Files
run example {} for 4 but 0 File

/*
Wir können run auch für bestimmte Prädikate aufrufen:
*/

// Modelle mit Tiefe 2
run depth2 for 4 but 0 File

run depth2 for 4 but 1 File

run depth2 for 4 but 2 File

pred empty_dir [d : Dir] {
  no d.entries
}

// Modelle mit einem leeren Verzeichnis
run empty_dir for 3

/*
check versucht Gegenbeispiele zu finden

Wir haben schon Beispiele gesehen, bei denen wir zunächst
eine assertion formuliert haben und dann check verwenmdet haben
*/
assert ObjectsAreReachable {
	Object - Root in Root.^(entries.object)
}

check ObjectsAreReachable 
check ObjectsAreReachable for 6

/*
Wir können aber auch beim check direkt eine Aussage angeben
wie bei run:
*/

check no_partitions {
  all o : Object | reachable[o]
} for 6
